<?php
require_once 'include/class.user.php';
$user = new USER();
if (empty($_GET['id']) && empty($_GET['code']))
{
  $user->redirect('login.php');
}
if (isset($_GET['id']) && isset($_GET['code'])) 
{
  $id = base64_decode($_GET['id']);
  $code = $_GET['code'];
  
  $statusY = "Y";
  $statusN = "N";
  
  $stmt = $user->runQuery("SELECT userID,userEstado FROM usuarios WHERE userID=:uID AND codeAct=:code LIMIT 1");
  $stmt->execute(array(":uID"=>$id,":code"=>$code));
  $row=$stmt->fetch(PDO::FETCH_ASSOC);
  if($stmt->rowCount() > 0)
  {
    if($row['userEstado']==$statusN)
    {
      $stmt = $user->runQuery("UPDATE usuarios SET userEstado=:status WHERE userID=:uID");
      $stmt->bindparam(":status",$statusY);
      $stmt->bindparam(":uID",$id);
      $stmt->execute(); 
      
      $msg = "
            <div class='alert alert-success'>
                  <span class='fa fa-smile-o fa-2x'></span><strong> ¡Bien!</strong> Su cuenta ya está activada. <a href='login.php'>Inicie sesión aquí</a>
              </div>
             "; 
    }
    else
    {
      $msg = "
            <div class='alert alert-danger'>
                <span class='fa fa-frown-o fa-2x'></span><strong> Su cuenta no esta activada, revise el enlace de activación que se envío a su correo.</strong> <a href='index.php'>Volver al inicio</a>
            </div>
             ";
    }
  }
  else
  {
    $msg = "
          <div class='alert alert-warning'>
              <span class='fa fa-meh-o fa-2x'></span><strong> Este correo electrónico no esta registrado.</strong> <a href='login.php'>Registrate aquí.</a>
          </div>
         ";
  } 
}
?>
<?php include 'inc/header.php'; ?>  
  <div class="container">
      <section class="main"> 
          <div class="row">
                <div class="content-box-large">
                  <div class="panel-heading">
                  </div>
                  <div class="panel-body">
                  <?php if(isset($msg)) { echo $msg; } ?>
                    <img src="app/images/4avisos.png" class="center-block">
                  </div>
                </div>
          </div>
      </section>
  </div>
<?php include 'inc/footer.php'; ?>
