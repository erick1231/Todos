<?php
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('login.php');
}
$stmt = $user_ads->runQuery("SELECT * FROM usuarios WHERE userID=:id LIMIT 1");
$stmt->execute(array(":id"=>$_SESSION['userSession']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
$superid=$row["userID"];
?>

<?php 
if (isset($_POST['btn_nueva_publicidad']))
{	

	//header("location:" . $_SERVER['PHP_SELF']);

	$var_visible = 'no';
	$posicion = '1';

	$id_usuario = $_POST['txtiduser'];
	$id_ciudad = $_POST['txtidciudad'];
	$eDescripcion = $user_ads->limpiarDatos($_POST['txtdesc']);

	$imgFoto = $_FILES['foto_image']['name'];
	$tmp_dir = $_FILES['foto_image']['tmp_name'];
	$imgSize = $_FILES['foto_image']['size'];

	$duracion = $_POST['txtduracion'];
	$visible = $var_visible;
	$posicion = $posicion;

	$eFecha_pub = date('Y-m-d H:i:s');
	
	if (empty($id_ciudad && $eDescripcion && $imgFoto && $duracion)) {
		$errorMSG = "Olvidaste un dato, no se pudo publicar tu aviso";
    }
    else{

	$upload_dir = 'media/images_pub/'; //ubicacion de fotos
	$imgExt = strtolower(pathinfo($imgFoto,PATHINFO_EXTENSION));
	$imgFoto = rand(1000,100000000000).".".$imgExt; //renombra la foto 12 numeros
	move_uploaded_file($tmp_dir,$upload_dir.$imgFoto); //sube la foto

	$stmt = $user_ads->runQuery("SELECT * FROM publicidad WHERE descripcion=:eDescripcion");
	 
    $stmt->execute(array(":eDescripcion"=>$eDescripcion));
    $rowpublicidad = $stmt->fetch(PDO::FETCH_ASSOC);


	    if($stmt->rowCount() > 0)
	    {
	        $msg_accion = "
	            <div class='alert alert-danger'>
	                <button class='close' data-dismiss='alert'>&times;</button>
	                <strong>La descripción de tu publicidad es similar a la anterior.</strong>
	            </div>";
	            //unset($user_ads);
	    }
	    else{

	    	  if($user_ads->subir_publicidad($id_usuario,$id_ciudad,$eDescripcion,$imgFoto,$duracion,$visible,$posicion,$eFecha_pub))
			{

				//$msg_accion = "<div class='alert alert-success'>
		        //  				<button class='close' data-dismiss='alert'>&times;</button>
		        //    			<span class='fa fa-smile-o fa-2x'></span> <strong>Tu publicidad</strong> se envió correctamente, en unos minutos podras visualizarlo en la página principal.
		        //  				</div>";
		             	header("location:publicitar-en-california.php?mensaje");exit();


			}
		  else
		  	{
		  		$msg_accion = "<div class='alert alert-danger'>
		                <button class='close' data-dismiss='alert'>&times;</button>
		                 <span class='fa fa-frown-o fa-2x'></span><strong> Ups!</strong> hubo un problema al enviar tus datos.
		             	</div>";
		  	}
	    }
	}
}
?>

<?php include 'inc/header.php'; ?>
<div class="container">
    <div class="row">
        <div class="col-md-9 ">
        	<div class="bs-call bs-call-green">
        		<h4>Sigue las instrucciones para <strong>publicitar</strong></h4>
        	</div>

            <div class="bs-call bs-call-green">
            	<?php if(isset($msg_accion)){echo $msg_accion;}?>
            	<?php if(isset($_GET['mensaje']))
		             	{
		             		echo "<div class='alert alert-success'>
					                <button class='close' data-dismiss='alert'>&times;</button>
					                <span class='fa fa-smile-o fa-2x'></span> <strong>Tu publicidad</strong> se envió correctamente, en unos minutos podras visualizarlo en la página principal.
					             	</div>";
		             		
		             	} ?>
				<div class="panel-group" id="accordion1"> 
					<div class="panel panel-primary"> 
						<div class="panel-heading"> 
							<h4 class="panel-title"> 
							<a role="button" data-toggle="collapse" data-parent="#accordion1" href="#collapse1"> 
							<i class="fa fa-newspaper-o fa-2x"></i> Publicidad por semana </a> 
							</h4> 
						</div>
						<div id="collapse1" class="panel-collapse collapse in"> 
							<div class="panel-body">
							<div class="alert2 alert-dismissible alert-info">
							  	<strong>Publicita durante las semanas que necesites</strong> 
							  	<br>
							  		<p>El precio para publicitar durante una semana es de $40.</p>
							  		<p>Antes de publicitar debes ingresar el código de activación,
							  		 para obtener el código debes realizar el pago tomando en cuenta la duración de tu publicidad (desde 1 a 4 semanas).</p>

									<p>Una vez que ingreses el código podrás subir los datos de tu publicidad como ser la descripción y la imagen.
									</p>
							</div>
							<form id="codigo" method="post" class="form-horizontal" name="formu_e"
							autocomplete="off">
								<div class="form-group">
									<div class="col-md-6">
										<input type="text" id="input_off" placeholder="Ingrese código de activación" name="txtcodigo" class="form-control"/>
										<script type="text/javascript">
											document.formu_e.input_off.maxLength = 40;
										</script>
										<button type="submit" id="btn_off" class="btn btn-success btn-block"
										name="btn_verificar">Comprobar</button>
									</div>
								</div>
							</form>

				<?php  
					if(isset($_POST['btn_verificar']))
					{
						$codigo = trim($_POST['txtcodigo']);

						$stmt4 = $user_ads->runQuery('SELECT * FROM codigos WHERE codigo_semana=:codigo LIMIT 1');
						$stmt4->execute(array(":codigo"=>$codigo));
						$row4=$stmt4->fetch(PDO::FETCH_ASSOC);

							if ($row4['codigo_semana'] == $codigo) 
							{

								echo 	"<form method='post' enctype='multipart/form-data' name='form_in'>

											<div class='form-group' hidden>
												<div class='col-md-12'>
													<input type='text' id='myinput' name='txtiduser' 
													value='$superid' class='form-control' />
												</div>
												<script type='text/javascript'>
													document.form_in.myinput.style.display='none';
												</script>
											</div>

											<div class='form-group'>
										      	<label for='select' class='col-md-3'>Ciudad</label>
										      	<div class='col-md-8'>
											        <select class='form-control' id='select' name='txtidciudad'>
											          <option>San Francisco</option>
											          <option>Los Ángeles</option>
											          <option>San josé</option>
											          <option>Long Beach</option>
											          <option>Pasadena</option>
											          <option>Fresno</option>
											          <option>San Diego</option>
											          <option>Sacramento</option>
											          <option>Mountain View</option>
											        </select>
										        </div>
										    </div> 

					                		<div class='form-group'>
												<label class='col-md-3 control-label'>Descripción</label>
												<div class='col-md-8'>
													<input type='text' name='txtdesc' class='form-control' />
													<script type='text/javascript'>
														document.formu.inputmax.maxLength = 40;
													</script>
												</div>
											</div>

											<div class='form-group'>
									    	<label class='col-md-3 control-label'>Subir imagen</label>
									    	<div class='col-md-8'>
								                <div class='imageupload'>
								                    <div class='file-tab'>
								                        <label class='btn btn-default btn-file'>
								                            <span>Buscar..</span>
								                            <input class='input-group' type='file' name='foto_image' accept='image/*'>
								                        </label>
								                        <button type='button' class='btn btn-default'>Borrar</button>
								                    	</div>
								                	</div>
								            	</div>
									    	</div>

									    	<div class='form-group'>
										      	<label for='select' class='col-lg-3 control-label'>Duración</label>
										      	<div class='col-lg-8'>
											        <select class='form-control' id='select' name='txtduracion'>
											          <option selected='selected'>1 semana</option>
											          <option>2 semanas</option>
											          <option>3 semanas</option>
											          <option>4 semanas</option>
											        </select>
										        </div>
										    </div> 

										    <div class='form-group'>
					              		        <div class='col-md-6'>
					                            <button type='submit' class='btn btn-success btn-block' name='btn_nueva_publicidad'><span class='fa fa-check'></span> Publicar</button>
					                            </div>
					                             <div class='col-md-6'>
					                                <a href='publicitar-en-california.php' class='btn btn-danger btn-block'><span class='fa fa-stop'></span> Cancelar</a>
					                            </div>
					                        </div>
										</form>";

								echo 	"<script type='text/javascript'>
										document.formu_e.input_off.style.display='none';
									 	</script>";

								echo 	"<script type='text/javascript'>
										document.formu_e.btn_off.style.display='none';
									 	</script>";
								
							}
							else
							{
								$msg_sem = "<div class='alert alert-danger'>
						                	<button class='close' data-dismiss='alert'>&times;</button>
						                	<span class='fa fa-close fa-2x'></span>
						                	<strong> Este código no es valido, por favor 
						                	solicite un código para publicitar.</strong>
						            	</div>";
							}

					}
				?> 
						<?php if(isset($msg_sem)){echo $msg_sem;}?>
							</div> 
						</div>
					</div> 
				</div>

				<!-- mes -->
				<div class="panel-group" id="accordion2"> 
					<div class="panel panel-primary"> 
						<div class="panel-heading"> 
							<h4 class="panel-title"> 
							<a role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapse2"> 
							<i class="fa fa-newspaper-o fa-2x"></i> Publicidad por mes </a> 
							</h4> 
						</div>
						<div id="collapse2" class="panel-collapse collapse in"> 
							<div class="panel-body">
							<div class="alert2 alert-dismissible alert-info">
							  	<strong>Publicita durante los meses que necesites</strong> 
							  	<br>
							  		<p>El precio para publicitar durante una mes es de $100.</p>
							  		<p>Antes de publicitar debes ingresar el código de activación, para obtener el código debes realizar el pago tomando en cuenta la duración de tu publicidad.</p>
							  		<p>
									Una vez que ingreses el código podrás subir los datos de tu publicidad como ser la descripción y la imagen.
									</p>
							</div>
							<form id="codigo" method="post" class="form-horizontal" name="formu_mes"
							autocomplete="off">
								<div class="form-group">
									<div class="col-md-6">
										<input type="text" id="input_off" placeholder="Ingrese código de activación" name="txtcodigo" class="form-control"/>
										<script type="text/javascript">
											document.formu_mes.input_off.maxLength = 40;
										</script>
										<button type="submit" id="btn_off" class="btn btn-success btn-block"
										name="btn_verificar_mes">Comprobar</button>
									</div>
								</div>
							</form>

				<?php  
					if(isset($_POST['btn_verificar_mes']))
					{
						$codigo = trim($_POST['txtcodigo']);

						$stmt4 = $user_ads->runQuery('SELECT * FROM codigos WHERE codigo_mes=:codigo LIMIT 1');
						$stmt4->execute(array(":codigo"=>$codigo));
						$row4=$stmt4->fetch(PDO::FETCH_ASSOC);

							if ($row4['codigo_mes'] == $codigo) 
							{
	
								echo 	"<form method='post' enctype='multipart/form-data' name='form_in'>

											<div class='form-group' hidden>
												<div class='col-md-12'>
													<input type='text' id='myinput' name='txtiduser' 
													value='$superid' class='form-control' />
												</div>
												<script type='text/javascript'>
													document.form_in.myinput.style.display='none';
												</script>
											</div>

											<div class='form-group'>
										      	<label for='select' class='col-md-3'>Ciudad</label>
										      	<div class='col-md-8'>
											        <select class='form-control' id='select' name='txtidciudad'>
											          <option>San Francisco</option>
											          <option>Los Ángeles</option>
											          <option>San josé</option>
											          <option>Long Beach</option>
											          <option>Pasadena</option>
											          <option>Fresno</option>
											          <option>San Diego</option>
											          <option>Sacramento</option>
											          <option>Mountain View</option>
											        </select>
										        </div>
										    </div> 

					                		<div class='form-group'>
												<label class='col-md-3 control-label'>Descripción</label>
												<div class='col-md-8'>
													<input type='text' name='txtdesc' class='form-control' />
													<script type='text/javascript'>
														document.formu.inputmax.maxLength = 40;
													</script>
												</div>
											</div>

											<div class='form-group'>
									    	<label class='col-md-3 control-label'>Subir imagen</label>
									    	<div class='col-md-8'>
								                <div class='imageupload'>
								                    <div class='file-tab'>
								                        <label class='btn btn-default btn-file'>
								                            <span>Buscar..</span>
								                            <input class='input-group' type='file' name='foto_image' accept='image/*'>
								                        </label>
								                        <button type='button' class='btn btn-default'>Borrar</button>
								                    	</div>
								                	</div>
								            	</div>
									    	</div>

									    	<div class='form-group'>
										      	<label for='select' class='col-lg-3 control-label'>Duración</label>
										      	<div class='col-lg-8'>
											        <select class='form-control' id='select' name='txtduracion'>
											          <option selected='selected'>1 mes</option>
											          <option>2 meses</option>
											          <option>3 meses</option>
											        </select>
										        </div>
										    </div> 

										    <div class='form-group'>
					              		        <div class='col-md-6'>
					                            <button type='submit' class='btn btn-success btn-block' name='btn_nueva_publicidad'><span class='fa fa-check'></span> Publicar</button>
					                            </div>
					                             <div class='col-md-6'>
					                                <a href='publicitar-en-california.php' class='btn btn-danger btn-block'><span class='fa fa-stop'></span> Cancelar</a>
					                            </div>
					                        </div>
										</form>";

								echo 	"<script type='text/javascript'>
										document.formu_mes.input_off.style.display='none';
									 	</script>";

								echo 	"<script type='text/javascript'>
										document.formu_mes.btn_off.style.display='none';
									 	</script>";
							}
							else
							{
								$msg_m = "<div class='alert alert-danger'>
						                	<button class='close' data-dismiss='alert'>&times;</button>
						                	<span class='fa fa-close fa-2x'></span>
						                	<strong> Este código no es valido, por favor 
						                	solicite un código para publicitar.</strong>
						            	</div>";
							}

					}
				?> 
						<?php if(isset($msg_m)){echo $msg_m;}?>
							</div> 
						</div>
					</div> 
				</div>
            </div>
    	</div>
    	<div class="col-md-3 text-justify">
	    	<div class="panel panel-default">
	    		<div class="panel-body">
	    			<h5>Pasos para publicitar</h5>
	    				
		    				<strong>1.-</strong> Antes de elegir el tiempo de su publicidad, ejemplo:
							<ul>
				    			<li class="text-primary">* Una semana tiene un costo de $40.</li>
				    			<li class="text-warning">* Un mes tiene un costo de $100.</li>
							</ul>
					

						<p>
							Debe realizar su pago a través de tigo money al siguiente número:
							<img src="app/images/4avisos-tigo-money.png" width="250px">,
							Y por último solicitar el código de activación para habilitar el formulario de envió.
						</p>

						<p>
							<strong>2.-</strong> Debe ingresar el código y se habilitara el formulario de envío, los datos que debe llenar son los siguientes:

							<p class="text-primary">* <strong>Ciudad</strong> donde vive.</p>
							<p class="text-success">* <strong>Descripción</strong> de la publicidad, este dato no se mostrará en su publicidad, es para dar una idea de que trata su publicidad.
							</p>

							<p class="text-primary">* <strong>Imagen</strong> de tu publicidad, en esta imagen debe ir toda la información, ejemplo: número telefónico, dirección, promociones y otros datos para que contacten contigo, recuerda que la imagen debe tener un tamaño de 960x195px (máximo tres imágenes), si no cuentas con una imagen podemos diseñar uno para ti simplemente contáctanos a la página de Facebook.</p>


							<p class="text-success">* <strong>Duración,</strong> debe elegir el tiempo que se visualizará su publicidad, en ese tiempo el espacio que usted hace uso es solo para usted, una vez que finalice su tiempo su publicidad no se visualizará a menos que vuelva a adquirir ese espacio.</p>
						</p>

						<p>
							Una vez que completo el formulario debe hacer clic en el botón <strong>“Publicar”</strong>, y le saldrá un mensaje de confirmación.  
						</p>
						<p>
							Una vez que haya enviado su publicidad nosotros revisaremos el contenido y en unos minutos estará disponible en toda la página de 4avisos.
						</p>

	    		</div>
	    	</div>  
    	</div>
    </div>
</div>

<?php include 'inc/footer.php' ?>
