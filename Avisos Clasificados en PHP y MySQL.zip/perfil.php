<?php
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('login.php');
}
//extract($_SESSION);
$stmt = $user_ads->runQuery("SELECT * FROM usuarios WHERE userID=:id LIMIT 1");
$stmt->execute(array(":id"=>$_SESSION['userSession']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
extract($row);

if (isset($_POST['btn-update'])) 
{
	$id = $_POST['userID'];
	$Unombre = $user_ads->limpiarDatos($_POST['userNombre']);
	$Uapellido = $user_ads->limpiarDatos($_POST['userApell']);
	$Utelefono = $_POST['userTele'];

	if (empty($Unombre && $Uapellido && $Utelefono)) {
		$msgDato =  "<div class='alert alert-danger'>
						Olvidaste un dato
					</div>";
    }
    else{

	if($user_ads->update($id,$Unombre,$Uapellido,$Utelefono))
		{
		$msgPerfil = "<div class='alert alert-success'>
					<button type='button' class='close' data-dismiss='alert'>&times;</button>
					<i class='fa fa-smile-o fa-2x'></i><strong> Tus datos se actualizaron correctamente.</strong>
					</div>";
		}
	else
		{
		$msgPass =  "<div class='alert alert-danger'>
					<i class='fa fa-frown-o fa-2x'></i><strong> Error</strong> al actualizar los datos, intente mas tarde.
				</div>";
		}
	}

}
if(isset($_POST['userID']))
{
	$id = $_POST['userID'];
	extract($user_ads->getID($id));	
}
?>
<?php include 'inc/header.php';?>
<section class="main container">
	<div class="row">
		<section class="col-md-4">
			<div class="panel panel-info">
				<div class="panel-heading">
					<h3 class="panel-title">Mis datos</h3>
				</div>

				<div class="panel-body">
					<form role="form" id="validaperfil" method="post"  class="form-horizontal mitad"> 
					<?php if(isset($msgPerfil)){
						echo $msgPerfil;
					}elseif(isset($msgPass)){
						echo $msgPass;
					}elseif(isset($msgDato)){
						echo $msgDato;
					}
					?>

						<div class="form-group" hidden>
							<label class="col-md-4 control-label">id</label>
								<div class="col-md-8">
									<input type="" name="userID" class="form-control" maxlength="50" value="<?php echo $userID; ?>" />
								</div>
						</div>
										
						<div class="form-group">
							<label class="col-md-4 control-label">Nombres</label>
								<div class="col-md-8">
									<input type="" name="userNombre" class="form-control" maxlength="50" value="<?php echo $userNombre; ?>" />
								</div>
						</div>

						<div class="form-group">    
				            <label class="col-md-4 control-label">Apellidos</label>    
				                <div class="col-md-8">
				                    <input type="text" class="form-control" name="userApell" maxlength="50" value="<?php echo $userApell; ?>" />    
				        		</div>  
				        </div>

						<div class="form-group">    
				            <label class="col-md-4 control-label">Teléfono</label>    
				                <div class="col-md-8">
				                    <input type="text" class="form-control" name="userTele" maxlength="10" value="<?php echo $userTele; ?>"" />    
				        		</div>  
				        </div>

				        <div class="form-group">
					        <div class="col-md-12">
					        <button type="submit" name="btn-update" class="btn btn-primary btn-block">Actualizar datos</button>
					        </div>
				        </div>
					</form>
				</div>
		</div>

			<div class="panel panel-info">
				<div class="panel-heading">
					<h3 class="panel-title">Mi contraseña</h3>
				</div>

				<?php

					if(isset($_POST['btn-pass']))
					{
						$id = $_POST['userID'];
						$upassword = $_POST['txtcontra'];
						if ($user_ads->uppass($id,$upassword))
						{
							$msg = "<div class='alert alert-success'>
										<button type='button' class='close' data-dismiss='alert'>&times;</button>
										<i class='fa fa-smile-o fa-2x'></i>
										<strong> Tu contraseña se actualizó correctamente.</strong>
									</div>";
						}
						else
						{
						$msg =  "<div class='alert alert-danger'>
									<i class='fa fa-frown-o fa-2x'></i><strong> Error</strong> al actualizar la contraseña, intente mas tarde.
									</div>";
						}

					 }
				?>
				<div class="panel-body">
					<form role="form" id="registrationForm" method="post" class="form-horizontal mitad" ><?php
						if(isset($msg))
						{
						echo $msg;
						}
						?>
					 			<?php
		                        if (isset($_GET['error'])) 
		                        {
		                        ?>
		                        <div class='alert alert-danger'>
		                            <button class='close' data-dismiss='alert'>&times;</button>
		                            <strong>Datos incorrectos</strong>    
		                        </div>
		            <?php    
		            }
		            ?>
						<div class="form-group" hidden>
							<label class="col-md-4 control-label">id</label>
								<div class="col-md-8">
									<input type="" name="userID" class="form-control" maxlength="50" value="<?php echo $userID; ?>" />
								</div>
						</div>
						<div class="form-group">
							<label class="col-md-4 control-label">Contraseña</label>
							<div class="col-md-8">
								<input type="text" name="txtcontra"  class="form-control" maxlength="50">
							</div>	
						</div>
						<div class="form-group">
							<label class="col-md-4 control-label">Confirmar contraseña</label>
							<div class="col-md-8">
								<input type="text" name="txtconfirmar" class="form-control" maxlength="50">
							</div>	
						</div>
						<div class="form-group">
							<div class="col-md-12">
								<button type="submit" class="btn btn-primary btn-block" name="btn-pass">Actualizar contraseña</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</section>

	<section class="col-md-4">
		<div class="panel panel-info">
			<div class="panel-heading">
				<h3 class="panel-title">Mis avisos clasificados</h3>
			</div>
			<div class="panel-body">
			<?php
	            $stmt = $user_ads->runQuery("SELECT COUNT(*) FROM aviso_empleo
												INNER JOIN usuarios
												ON aviso_empleo.id_usuario=usuarios.userID 
												WHERE userID = :uid ");

	           	$stmt->execute(array(":uid"=>$_SESSION['userSession']));
	            $row=$stmt->fetch(PDO::FETCH_ASSOC);
	            $contar_empleo = $row['COUNT(*)'];
	        ?>
	        <?php
	            $stmt = $user_ads->runQuery("SELECT COUNT(*) FROM aviso_venta
												INNER JOIN usuarios
												ON aviso_venta.id_usuario=usuarios.userID 
												WHERE userID = :uid ");

	           	$stmt->execute(array(":uid"=>$_SESSION['userSession']));
	            $row=$stmt->fetch(PDO::FETCH_ASSOC);
	            $contar_venta = $row['COUNT(*)'];
	        ?>
	        <?php
	            $stmt = $user_ads->runQuery("SELECT COUNT(*) FROM aviso_compra
												INNER JOIN usuarios
												ON aviso_compra.id_usuario=usuarios.userID 
												WHERE userID = :uid ");

	           	$stmt->execute(array(":uid"=>$_SESSION['userSession']));
	            $row=$stmt->fetch(PDO::FETCH_ASSOC);
	            $contar_compra = $row['COUNT(*)'];
	        ?>
	        <?php
	            $stmt = $user_ads->runQuery("SELECT COUNT(*) FROM aviso_servicio
												INNER JOIN usuarios
												ON aviso_servicio.id_usuario=usuarios.userID 
												WHERE userID = :uid ");

	           	$stmt->execute(array(":uid"=>$_SESSION['userSession']));
	            $row=$stmt->fetch(PDO::FETCH_ASSOC);
	            $contar_servicio = $row['COUNT(*)'];
	        ?>
				<ul class="list-group">
					<li class="list-group-item">
						<span class="badge"><?php echo $contar_empleo; ?></span>Empleo
					</li>
					<li class="list-group-item">
						<span class="badge"><?php echo $contar_venta; ?></span>Venta
					</li>
					<li class="list-group-item">
						<span class="badge"><?php echo $contar_compra; ?></span>Compra
					</li>
					<li class="list-group-item">
						<span class="badge"><?php echo $contar_servicio; ?></span>Servicios
					</li>
				</ul>

				 <?php
		            $stmt = $user_ads->runQuery("SELECT * FROM mensaje LIMIT 1");
		           	$stmt->execute();
		            $row=$stmt->fetch(PDO::FETCH_ASSOC);
	        	?>
	        	<?php if (isset($row['mensaje'])) {
	        		echo "<div class='alert2 alert-dismissible alert-info'>
							<i class='fa fa-bell-o'></i><strong> Mensaje:</strong>
							<p> ".$row['mensaje']." </p>
						</div>";
	        	}
	        	?>
			</div>
		</div>
	</section>

	<section class="col-md-4">

	</section>
</div>
</section>
<?php include 'inc/footer.php'; ?>
