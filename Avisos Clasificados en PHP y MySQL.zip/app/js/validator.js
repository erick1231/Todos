/*  $('#log').bootstrapValidator({
         feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
         },
         fields: {
             txtcorreo: {    
                 validators: { 
                     notEmpty: {
                         message: 'Debes introducir un correo electrónico'
                     },
                     emailAddress: {
                         message: 'El correo electronico no es valido'
                     }
                 }
             },
             txtcontra: {
                 validators: {
                     notEmpty: {
                         message: 'Este dato es requerido'
                     }

                 }
             } 
         }
    });*/
     
    $('#registrationForm').bootstrapValidator({
         feedbackIcons: {
             valid: 'glyphicon glyphicon-ok',
             invalid: 'glyphicon glyphicon-remove',
             validating: 'glyphicon glyphicon-refresh'
         },

         fields: {

             txtnombre: {
                 validators: {
                     notEmpty: {
                         message: 'El nombre es requerido'
                     },
                     regexp: {
                            regexp: /^[A-Z-a-ñ-z\s]+$/,
                            message:'El nombre debe contener texto'
                     }
                 }
             },

             txtapellido: {
                 validators: {
                     notEmpty: {
                         message: 'El apellido es requerido'
                     },
                     regexp: {
                            regexp: /^[A-Z-a-ñ-z\s]+$/,
                            message:'El nombre debe contener texto'
                     }
                 }
             },
     
             txtcorreo: {    
                 validators: { 
                     notEmpty: {
                         message: 'El correo es requerido'
                     },
                     emailAddress: {
                         message: 'El correo electronico no es valido'
                     }
                 }
             },
     
            /* txtcontra: {
     
                 validators: {
     
                     notEmpty: {
     
                         message: 'La contraseña es requerido y no puede ser vacio.'
     
                     },
     
                     stringLength: {
     
                         min: 8,
     
                         message: 'La contraseña debe contener al menos 8 caracteres'
     
                     }
     
                 }
     
             },
     */
             /*datetimepicker: {
                 validators: {
                     notEmpty: {
                         message: 'La fecha de nacimiento es requerida y no puede ser vacia'
                     },
                     date: {
                         format: 'YYYY-MM-DD',
                         message: 'La fecha de nacimiento no es valida'
                     }
                 }
             },*/

             terminos: {
                 validators: {
                     notEmpty: {
                         message: 'Debes aceptar los terminos para crear la cuenta'
                     }
                 }
             },
     
             txttelefono: {
                 message: 'El teléfono no es valido',
                 validators: {
                     notEmpty: {
                         message: 'El teléfono es requerido'
                     },
                     regexp: {
                         regexp: /^[0-9]+$/,
                         message: 'El teléfono debe contener números'
                     }
                 }
             },
     
             telefono_cel: {
                 message: 'El teléfono no es valido',
                 validators: {
                     regexp: {
                         regexp: /^[0-9]+$/,
                         message: 'El teléfono debe contener números'
                     }
                 }
             },



             txtcontra: {
                validators: {
                    notEmpty: {
                        message: 'la contraseña es obligatoria y no vacia'
                    },
                    identical: {
                        field: 'txtconfirmar',
                        message: 'La contraseña y su confirmacion no son la misma'
                    },

                }
            },

            txtconfirmar: {
                validators: {
                    notEmpty: {
                        message: 'la contraseña es obligatoria y no vacia'
                    },
                    identical: {
                        field: 'txtcontra',
                        message: 'La contraseña y su confirmacion no son la misma'
                    }
                }
            },

         }

    });

/*validacion de contraseña de perfil*/
 $('#validaperfil').bootstrapValidator({

    feedbackIcons: {
             valid: 'glyphicon glyphicon-ok',
             invalid: 'glyphicon glyphicon-remove',
     
             validating: 'glyphicon glyphicon-refresh'
         },

         fields: {

             userNombre: {
                 validators: {
                     notEmpty: {
                         message: 'El nombre es requerido'
                     },
                     regexp: {
                            regexp: /^[A-Z-a-ñ-z\s]+$/,
                            message:'El nombre debe contener texto'
                     }
                 }
             },

            userApell: {
                 validators: {
                     notEmpty: {
                         message: 'El apellido es requerido'
                     },
                     regexp: {
                            regexp: /^[A-Z-a-ñ-z\s]+$/,
                            message:'El nombre debe contener texto'
                     }
                 }
             },

            userTele: {
                 message: 'El teléfono no es valido',
                 validators: {
                     notEmpty: {
                         message: 'El teléfono es requerido'
                     },
                     regexp: {
                         regexp: /^[0-9]+$/,
                         message: 'El teléfono debe contener números'
                     }
                 }
             },
        }     
 });
/*end*/

/*validacion de contraseña de perfil*/
 $('#val_pub_emp').bootstrapValidator({

    feedbackIcons: {
             valid: 'glyphicon glyphicon-ok',
             invalid: 'glyphicon glyphicon-remove',
     
             validating: 'glyphicon glyphicon-refresh'
         },

         fields: {

             txttitulo: {
                 validators: {
                     notEmpty: {
                         message: 'Este dato es requerido'
                     }
                 }
             },
             txtdesc: {
                 validators: {
                     notEmpty: {
                         message: 'Este dato es requerido'
                     }

                 }
             },
            

             txtidciudad: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione una opción'
                    }
                }
            },
            txtidcat: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione una opción'
                    }
                }
            },
            fecha_vigen: {
                validators: {
                    notEmpty: {
                        message: 'La fecha es requerida'
                    },
                    date: {
                        format: 'YYYY-MM-DD',

                    }
                }
            }
        }     
 });
/*end*/
/*******/
 $('#val_pub_vent').bootstrapValidator({

    feedbackIcons: {
             valid: 'glyphicon glyphicon-ok',
             invalid: 'glyphicon glyphicon-remove',
             validating: 'glyphicon glyphicon-refresh'
         },

         fields: {
             txtidciudad: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione una opción'
                    }
                }
            },
            txtidcat: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione una opción'
                    }
                }
            },
            txttitulo: {
                 validators: {
                     notEmpty: {
                         message: 'Este dato es requerido'
                     }
                 }
             },
             txtdesc: {
                 validators: {
                     notEmpty: {
                         message: 'Este dato es requerido'
                     }

                 }
             },
             foto_imageee: {
                validators: {
                    notEmpty: {
                         message: 'Eliga una foto'
                     },
                    file: {
                        extension: 'jpg',
                        type: 'image/jpeg',
                        maxSize: 2024*2024,
                        message: 'eliga una foto como máximo 2Mb.'
                    }
                }
             },
            /* txtprecio: {
                 validators: {
                     notEmpty: {
                         message: 'Este dato es requerido'
                     }
                 }
             },*/

            fecha_vigen: {
                validators: {
                    notEmpty: {
                        message: 'La fecha es requerida, si la fecha no es aceptada vuelva a ingresar todo de nuevo '
                    },
                    date: {
                        format: 'YYYY-MM-DD',

                    }
                }
            }
        }     
 });

/*val_serv*/
 $('#val_pub_serv').bootstrapValidator({

    feedbackIcons: {
             valid: 'glyphicon glyphicon-ok',
             invalid: 'glyphicon glyphicon-remove',
             validating: 'glyphicon glyphicon-refresh'
         },

         fields: {
             txtidciudad: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione una opción'
                    }
                }
            },
            txtidcat: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione una opción'
                    }
                }
            },
              txttitulo: {
                 validators: {
                     notEmpty: {
                         message: 'Este dato es requerido'
                     },
                 }
             },
             txtdesc: {
                 validators: {
                     notEmpty: {
                         message: 'Este dato es requerido'
                     }

                 }
             }
        }     
 });
 /*val_com*/
 $('#val_pub_com').bootstrapValidator({

    feedbackIcons: {
             valid: 'glyphicon glyphicon-ok',
             invalid: 'glyphicon glyphicon-remove',
             validating: 'glyphicon glyphicon-refresh'
         },

         fields: {
             txtidciudad: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione una opción'
                    }
                }
            },
            txtidcat: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione una opción'
                    }
                }
            },
              txttitulo: {
                 validators: {
                     notEmpty: {
                         message: 'Este dato es requerido'
                     },
                 }
             },
             txtdesc: {
                 validators: {
                     notEmpty: {
                         message: 'Este dato es requerido'
                     }

                 }
             }
        }     
 });

$('#editar_empleo2323').bootstrapValidator({
         message: 'Este valor no es valido',
        feedbackIcons: {
         valid: 'glyphicon glyphicon-ok',
         invalid: 'glyphicon glyphicon-remove',
         validating: 'glyphicon glyphicon-refresh'
     },
        fields: {
             titulo: {
                 validators: {
                     notEmpty: {
                         message: 'Este dato es requerido'
                     }
                 }
             },
             descripcion: {
                  validators: {
                     notEmpty: {
                         message: 'Este dato es requerido'
                     }
                 }
             }
        }     
 });


  $('#codigo').bootstrapValidator({
     
         message: 'Este valor no es valido',
         feedbackIcons: {
             valid: 'glyphicon glyphicon-ok',
             invalid: 'glyphicon glyphicon-remove',
             validating: 'glyphicon glyphicon-refresh'
         },
         fields: {
             txtcodigo: {    
                 validators: { 
                     notEmpty: {
                         message: 'El nombre de usuario es requerido'
                     }
                 }
             },
         }
     
    });


  $('#eee').bootstrapValidator({
     
         message: 'Este valor no es valido',
         feedbackIcons: {
             valid: 'glyphicon glyphicon-ok',
             invalid: 'glyphicon glyphicon-remove',
             validating: 'glyphicon glyphicon-refresh'
         },
         fields: {
             titulo: {    
                 validators: { 
                     notEmpty: {
                         message: 'El nombre de usuario es requerido'
                     }
                 }
             },
         }
     
    });

  $('#contacto').bootstrapValidator({

    feedbackIcons: {
             valid: 'glyphicon glyphicon-ok',
             invalid: 'glyphicon glyphicon-remove',
             validating: 'glyphicon glyphicon-refresh'
         },

         fields: {

             nombre: {
                 validators: {
                     notEmpty: {
                         message: 'El nombre es requerido'
                     },
                     regexp: {
                            regexp: /^[A-Z-a-ñ-z\s]+$/,
                            message:'El nombre debe contener texto'
                     }
                 }
             },
             asunto: {    
                 validators: { 
                     notEmpty: {
                         message: 'El asunto es requerido'
                     }
                 }
             },
            correo: {    
                 validators: { 
                     notEmpty: {
                         message: 'El correo es requerido'
                     },
                     emailAddress: {
                         message: 'El correo electronico no es valido'
                     }
                 }
             },
             mensaje: {    
                 validators: { 
                     notEmpty: {
                         message: 'El mensaje es requerido'
                     }
                 }
             },
        }     
 });
     
