<?php  
session_start();
require_once 'include/class.user.php';
$user_empleo = new USER();
if(!$user_empleo->is_logged_in())
{
  $user_empleo->redirect('index.php');
}

$stmt = $user_empleo->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSession']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);				
?>
<?php 
	if(isset($_POST['btn-borrar-empleo']))
	{
		$idcat_empleo=$_GET['deletee_id'];
		$user_empleo->delete_empleo($id);
		 $msg="<div class='alert alert-success'>
	    	 	<strong><span class='icon-ok-sign'></span></strong> Datos eliminados 
				</div>";
		header("refresh:2;usuarios.php");
	}
?>
<?php include 'inc/header.php'; ?>
<div class="container">
	<?php
	 if(isset($_GET['deletee_id']))
	 {
		?>
        <?php 
		$stmt = $user_empleo->runQuery("SELECT * FROM cat_empleo WHERE idcat_empleo=:id");
		$stmt->execute(array(":id"=>$_GET['deletee_id']));
		$stmt->execute();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);	
		/*while($row=$stmt->fetch(PDO::FETCH_ASSOC))*/
		?>
		<?php
     }
        ?>
		<?php
		if(isset($_GET['deletee_id']))
			{
		?>
    <div class="row">
    	<div class="col-md-4 col-md-offset-4 ">
       		<div class="login-panel panel panel-warning">
            	<div class="panel-heading">
                <h3 class="panel-title"><span class="icon-exclamation-sign icon-2x"></span> ¿Estas seguro en eliminar este empleo?</h3>
            	</div>
        		<div class="panel-body">  
        		<?php if(isset($msg)){echo $msg;}
				?>
				<form role="form" id="registrationForm" method="post" class="form-horizontal mitad">

					<div class="form-group" hidden>
                        <div class="col-sm-8">
						<input type="hidden" name="idcat_empleo" value="<?php echo $row['idcat_empleo']; ?>" />
						</div>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Nombre</label>
                        <div class="col-sm-8">
                            <input type="text" value='<?php echo $row['nombre']; ?>' class="form-control" maxlength="50" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Posición</label>
                        <div class="col-sm-8">
                            <input type="text" value='<?php echo $row['posicion']; ?>' class="form-control" maxlength="50" disabled>
                        </div>
                    </div>
                    <div class="form-group">
					      <label class="col-md-2 control-label">Visible</label>
					      <div class="col-md-10">
					        <div class="radio">
					          <label>
					            <input name="radiovisible" value="1" checked="checked" type="radio">
					            Si
					          </label>
					        </div>
					        <div class="radio">
					          <label>
					            <input name="radiovisible" value="0" type="radio">
					            No
					          </label>
					        </div>
					      </div>
					</div>

      				<div class="form-group">
      		            <div class="col-sm-6">
                        <button  type="submit" class="btn btn-danger btn-block" name="btn-borrar-empleo"><i class="icon-remove-circle"></i> Eliminar</button>
                        </div>
                        <div class="col-sm-6">
                        <a href="usuarios.php" class="btn btn-success btn-block" ><i class="icon-stop"></i> Cancelar</a>
                        </div>
                    </div>
			    </form>
			        <?php
					}
					else
					{
						?>
					  		 <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; Back222 to index</a>
					    <?php
					}
					?>
                     <hr>
                </div>
            </div>
		</div>
  	</div>    
</div>
<?php include 'inc/footer.php'; ?>
