<?php
session_start();
require_once 'include/class.user.php';
$user_publicar = new USER();

if(!$user_publicar->is_logged_in())
{
  $user_publicar->redirect('login.php');
}
$stmt = $user_publicar->runQuery("SELECT * FROM usuarios WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSession']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
$superid=$row["userID"];
?>
<!-- empleo -->
<?php 
if (isset($_POST['btn_nuevo_aviso']))
{	
	$var_visible = 'si';
	$id_usuario = $_POST['txtiduser'];
	$id_ciudad = $_POST['txtidciudad'];
	$id_categoria = $_POST['txtidcat'];
	$eTitulo = $user_publicar->limpiarDatos($_POST['txttitulo']);
	$eDescripcion = $user_publicar->limpiarDatos($_POST['txtdesc']);
	$eFecha_pub = date('Y-m-d H:i:s');
	$eFecha_vigencia = $_POST['fecha_vigen'];
	$visible = $var_visible;

//valida datos vacios con php (se valida con js y php )
	if (empty($id_ciudad && $id_categoria && $eTitulo && $eDescripcion)) {
		$errorMSG = "Olvidaste un dato, no se pudo publicar tu aviso";
    }
    else{

	$stmt = $user_publicar->runQuery("SELECT * FROM aviso_empleo WHERE descripcion=:eDescripcion");
    $stmt->execute(array(":eDescripcion"=>$eDescripcion));
    $rowempleo = $stmt->fetch(PDO::FETCH_ASSOC);


	    if($stmt->rowCount() > 0)
	    {
	        $msg = "
	            <div class='alert alert-danger'>
	                <button class='close' data-dismiss='alert'>&times;</button>
	                <strong>Este aviso clasificado ya existe.</strong>
	            </div>";
	    }
	    else{

    	  if($user_publicar->publicar_aviso_empleo($id_usuario,$id_ciudad,$id_categoria,$eTitulo,$eDescripcion,$eFecha_pub,$eFecha_vigencia,$visible))
			{
				$msg = "<div class='alert alert-success'>
		                <button class='close' data-dismiss='alert'>&times;</button>
		                <span class='fa fa-smile-o fa-2x'></span> Tu aviso de <strong>empleo</strong> se publicó correctamente.
		             	</div>";
			}
	  		else
	  		{
	  		$msg="<div class='alert alert-danger'>
                <button class='close' data-dismiss='alert'>&times;</button>
                 <span class='fa fa-frown-o fa-2x'></span><strong> Ups!</strong> hubo un problema al publicar tu aviso, intentalo mas tarde.
             	</div>";
	  		}
    	}
	}
}
?>

<!-- venta -->
<?php 
if (isset($_POST['btn_nuevo_venta']))
{	
	$var_visible = 'no';
	$id_usuario = $_POST['txtiduser'];
	$id_ciudad = $_POST['txtidciudad'];
	$id_cat_venta = $_POST['txtidcat'];
	$eTitulo = $user_publicar->limpiarDatos($_POST['txttitulo']);
	$eDescripcion = $user_publicar->limpiarDatos($_POST['txtdesc']);
	$ePrecio = $_POST['txtprecio'];
	$eFecha_pub = date('Y-m-d H:i:s');
	$imgFoto = $_FILES['foto_image']['name'];
	$tmp_dir = $_FILES['foto_image']['tmp_name'];
	$imgSize = $_FILES['foto_image']['size'];
	$visible = $var_visible;

	if (empty($id_ciudad && $id_cat_venta && $eTitulo && $eDescripcion && $ePrecio)) {
		$errorMSG = "Olvidaste un dato, no se pudo publicar tu aviso";
    }
    else{

	$upload_dir = 'media/fotos_images4/'; //ubicacion de fotos
	$imgExt = strtolower(pathinfo($imgFoto,PATHINFO_EXTENSION));
	$imgFoto = rand(1000,100000000000).".".$imgExt; //renombra la foto 12 numeros
	move_uploaded_file($tmp_dir,$upload_dir.$imgFoto); //sube la foto

	 $stmt = $user_publicar->runQuery("SELECT * FROM aviso_venta WHERE descripcion=:eDescripcion");
	 
    $stmt->execute(array(":eDescripcion"=>$eDescripcion));
    $rowventa = $stmt->fetch(PDO::FETCH_ASSOC);


	    if($stmt->rowCount() > 0)
	    {
	        $msg = "
	            <div class='alert alert-danger'>
	                <button class='close' data-dismiss='alert'>&times;</button>
	                <strong>Este aviso clasificado ya existe.</strong>
	            </div>";
	    }
	    else{

	    	  if($user_publicar->publicar_aviso_venta($id_usuario,$id_ciudad,$id_cat_venta,$eTitulo,$eDescripcion,$imgFoto,$ePrecio,$eFecha_pub,$visible))
			{
				//$msg="<div class='alert alert-success'>
	             //  <button class='close' data-dismiss='alert'>&times;</button>
	             //   <span class='fa fa-smile-o fa-2x'></span> Tu aviso de <strong>venta</strong> se publicará en unos minutos.
	             //	</div>";
					header("location:publicar-aviso.php?mensaje");exit();
			}
		  else
		  	{
		  		$msg="<div class='alert alert-danger'>
	                <button class='close' data-dismiss='alert'>&times;</button>
	                 <span class='fa fa-frown-o fa-2x'></span><strong> ups!</strong> hubo un problema al publicar tu aviso, intentalo mas tarde.
	             	</div>";
		  	}
	    }
	}
}
?>

<!-- servicios -->
<?php 
if (isset($_POST['btn_nuevo_serv']))
{	
	$var_visible = 'no';
	$id_usuario = $_POST['txtiduser'];
	$id_ciudad = $_POST['txtidciudad'];
	$id_categoria = $_POST['txtidcat'];
	$eTitulo = $user_publicar->limpiarDatos($_POST['txttitulo']);
	$eDescripcion = $user_publicar->limpiarDatos($_POST['txtdesc']);
	$eFecha_pub = date('Y-m-d H:i:s');
	$visible = $var_visible;

	if (empty($id_ciudad && $id_categoria && $eTitulo && $eDescripcion)) {
		$errorMSG = "Olvidaste un dato, no se pudo publicar tu aviso";
    }
    else{

	$stmt = $user_publicar->runQuery("SELECT * FROM aviso_servicio WHERE descripcion=:eDescripcion");
    $stmt->execute(array(":eDescripcion"=>$eDescripcion));
    $rowserv = $stmt->fetch(PDO::FETCH_ASSOC);

    if($stmt->rowCount() > 0)
    {
        $msg = "
            <div class='alert alert-danger'>
                <button class='close' data-dismiss='alert'>&times;</button>
                <strong>Este aviso clasificado ya existe.</strong>
            </div>";
    }
    else{

		if($user_publicar->publicar_aviso_servicio($id_usuario,$id_ciudad,$id_categoria,$eTitulo,$eDescripcion,$eFecha_pub,$visible))
			{
				$msg="<div class='alert alert-success'>
		            <button class='close' data-dismiss='alert'>&times;</button>
		            <span class='fa fa-smile-o fa-2x'></span> Tu aviso de <strong>servicio</strong> se publicará en unos minutos.
		         	</div>";
			}
			  else
			{
			  	$msg="<div class='alert alert-danger'>
			        <button class='close' data-dismiss='alert'>&times;</button>
			            <span class='fa fa-frown-o fa-2x'></span><strong> Ups!</strong> hubo un problema al publicar tu aviso, intentalo mas tarde.
			        </div>";
			}
		}
	}	
}
?>
<!-- compra -->
 <?php 
if (isset($_POST['btn_nuevo_compra']))
{	
	$var_visible = 'no';
	$id_usuario = $_POST['txtiduser'];
	$id_ciudad = $_POST['txtidciudad'];
	$id_categoria = $_POST['txtidcat'];
	$eTitulo = $user_publicar->limpiarDatos($_POST['txttitulo']);
	$eDescripcion = $user_publicar->limpiarDatos($_POST['txtdesc']);
	$eFecha_pub = date('Y-m-d H:i:s');
	$visible = $var_visible;

	if (empty($id_ciudad && $id_categoria && $eTitulo && $eDescripcion)) {
		$errorMSG = "Olvidaste un dato, no se pudo publicar tu aviso";
    }
    else{

	$stmt = $user_publicar->runQuery("SELECT * FROM aviso_compra WHERE descripcion=:eDescripcion");
    $stmt->execute(array(":eDescripcion"=>$eDescripcion));
    $rowserv = $stmt->fetch(PDO::FETCH_ASSOC);

    if($stmt->rowCount() > 0)
    {
        $msg = "
            <div class='alert alert-danger'>
                <button class='close' data-dismiss='alert'>&times;</button>
                <strong>Este aviso clasificado ya existe.</strong>
            </div>";
    }
    else{

		if($user_publicar->publicar_aviso_compra($id_usuario,$id_ciudad,$id_categoria,$eTitulo,$eDescripcion,$eFecha_pub,$visible))
			{
				$msg="<div class='alert alert-success'>
		            <button class='close' data-dismiss='alert'>&times;</button>
		            <span class='fa fa-smile-o fa-2x'></span> Tu aviso de <strong>compra</strong> se publicará en unos minutos.
		         	</div>";
			}
			  else
			{
			  	$msg="<div class='alert alert-danger'>
			        <button class='close' data-dismiss='alert'>&times;</button>
			            <span class='fa fa-frown-o fa-2x'></span><strong> Ups!</strong> hubo un problema al publicar tu aviso, intentalo mas tarde.
			        </div>";
			}
		}
	}	
}
?>

<?php include 'inc/header.php'; ?>
<section class="main container">
	<div class="row">
		<section class="col-md-9">
			<div class="bs-callout"> 
			<h1>Elige el aviso que quieres publicar</h1>
			</div>
			<!-- publicidad -->
			<div class="panel panel-default">
			  	<div class="panel-body">
			  	<?php if(isset($msg)){
			 		echo $msg;  		
			  	} 
			  	elseif (isset($errorMSG)){
			  	echo "<div class='alert alert-danger'>
			  	<button class='close' data-dismiss='alert'>&times;</button>
				<strong> $errorMSG </strong></div>";
			  	}elseif (isset($_GET['mensaje']))
		             	{
		             		echo "<div class='alert alert-success'>
					              <button class='close' data-dismiss='alert'>&times;</button>
					                <span class='fa fa-smile-o fa-2x'></span> Tu aviso de <strong>venta</strong> se publicará en unos minutos.
					             </div>"; 
					         }
			  	?>

			  	
				    <ul class="nav nav-tabs">
					  <li class="active">
						  <a href="#home" data-toggle="tab" aria-expanded="true">Elige una opción 
						  <span class="fa fa-arrow-right"></span></a>
					  </li>
					  <li class="">
						  <a href="#empleo" data-toggle="tab" aria-expanded="false">
						  <span class="fa fa-briefcase"></span> Empleo</a>
					  </li>
					  <li class="">
						  <a href="#venta" data-toggle="tab" aria-expanded="false">
						  <span class="fa fa-thumb-tack"></span> Venta</a>
					  </li>
					  <li class="">
						  <a href="#servicios" data-toggle="tab" aria-expanded="false">
						  <span class="fa fa-bullhorn"></span> Servicios</a>
					  </li>
					  <li class="">
						  <a href="#compra" data-toggle="tab" aria-expanded="false">
						  <span class="fa fa-cart-arrow-down"></span> Compra</a>
					  </li>
					  <li class="">
						  <a href="#ayuda" data-toggle="tab" aria-expanded="false">
						  <span class="fa fa-question-circle"></span> Ayuda
					  </a>
					</ul>
					<div id="myTabContent" class="tab-content"><br>
						<div class="tab-pane fade active in" id="home">
						  	<div class="well well-large well-transparent clearfix">
						        <i style="color:#5CB85C;" class="fa fa-briefcase fa-2x pull-left fa-border"></i>
						       	<strong style="color:#5CB85C;">Aviso Empleo.</strong> ¿Estás en busca de trabajo o requieres personal para tu empresa? Un aviso de empleo es lo que buscas.
      						</div>			
						  	<div class="well well-large well-transparent clearfix">
						        <i style="color:#425F9B;" class="fa fa-handshake-o fa-2x pull-left fa-border"></i>
						        <strong style="color:#425F9B;">Aviso venta.</strong>
						         Estas pensando en vender eso que ya no usas o simplemente quieres venderlo, anímate, sube un aviso de venta, recuerda que antes debes contar con una  foto de lo que deseas vender.
      						</div>
						  	
						  	<div class="well well-large well-transparent clearfix">
						        <i style="color:#E98D23;" class="fa fa-bullhorn fa-2x pull-left fa-border"></i>
						        <strong style="color:#E98D23;">Aviso servicio.</strong>
						         ¿Eres un profesional en busca de trabajo? Un aviso de servicio te puede ayudar, puedes publicar un aviso de servicio para darte a conocer.
      						</div>
      						<div class="well well-large well-transparent clearfix">
						        <i style="color:#D9534F;" class="fa fa-cart-arrow-down fa-2x pull-left fa-border"></i>
						        <strong style="color:#D9534F;">Aviso compra.</strong>
						         ¿No pudiste encontrar eso que buscas en los avisos de venta? Intenta con un aviso de compra para que contacten directamente contigo.
      						</div>
      					</div>

		<div class="tab-pane fade" id="empleo">
		  	<div class="bs-callout bs-callout-success">
		  	<h4>Estas creando un aviso de empleo</h4>
		  	</div>
		    <div class="bs-callout bs-callout-success">
		    <div class="panel-body">
		    
				<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" role="form" id="val_pub_emp" method="post"  class="form-horizontal mitad" name="formu_e" >
					<div class="form-group" hidden="">
						<div class="col-md-1">
							<input type="text" id="myinput" value="<?php echo $superid; ?>" name="txtiduser" class="form-control" />
						</div>
						<script type="text/javascript">
							document.formu_e.myinput.style.display="none";
						</script>
					</div>
				
					<div class="form-group">
					    <label for="select" class="col-md-3 control-label">Ciudad</label>
					    <div class="col-md-4">
					        <select class="form-control" id="ciudad" name="txtidciudad">
					        <option value="">Selecciona tu ciudad</option>
				          <?php
					        $stmt = $user_publicar->runQuery('SELECT * FROM cat_ciudad');
					        $stmt->execute();
					        while($row=$stmt->fetch(PDO::FETCH_ASSOC))
					        {
					        extract($row);
					        ?>
						    <option value="<?php echo $row['idCiudad']; ?>">
						    <?php echo $ciudad; ?>
						 <!-- <tambien php echo $row['ciudad']; ?> -->
						    </option>
						        <?php
						        }
						        ?>
					        </select>
					      </div>
   					 </div>
					
					<div class="form-group">
					    <label for="select" class="col-md-3 control-label">Empleo</label>
					    <div class="col-md-6">
					        <select class="form-control" id="select" name="txtidcat">
					        <option value="">Seleccione un empleo</option>
					          <?php
						        $stmt = $user_publicar->runQuery('SELECT * FROM cat_empleo WHERE visible=1');
						        $stmt->execute();
						        while($row=$stmt->fetch(PDO::FETCH_ASSOC))
						        {
						            extract($row);
						            ?>
						    	<option value="<?php echo $idcat_empleo; ?>">
						            <?php echo $nombre; ?>
						            <!-- <tambien php echo $row['ciudad']; ?> -->
						      	</option>
						        <?php
						        }
						        ?>
					        </select>
					      </div>
   					 </div>

					<div class="form-group">
						<label class="col-md-3 control-label">título</label>
						<div class="col-md-8">
							<input type="text" id="inputmax" name="txttitulo" class="form-control"/>
							<script type="text/javascript">
								document.formu_e.inputmax.maxLength = 40;
							</script>
						</div>
					</div>
					<div class="form-group">
				      <label for="textArea" class="col-md-3 control-label">Descripción</label>
				      <div class="col-md-8">
				        <textarea id="inputmax2" class="form-control" rows="3" name="txtdesc" ></textarea>
				        <script type="text/javascript">
							document.formu_e.inputmax2.maxLength = 500;
						</script>
				        <span class="help-block">Ingresa un dato de referencia para que puedan contactarse contigo (max. 500 caracteres)</span>
				      </div>
				    </div>

					<div class="form-group">
						<label class="col-md-3 control-label">Fecha de vigencia</label>
						<div class="col-md-4">
							<div class='input-group date' id='divMiCalendario'>
		                      <input type='text' name="fecha_vigen" class="form-control" 
		                      value="<?php echo date('Y-m-d') ?>" />
		                      <span class="input-group-addon"><span class="fa fa-calendar"></span>
		                      </span>
		                  </div>
						</div>
					</div>

					<div class="form-group">
          		        <div class="col-md-6">
                        <button type="submit" class="btn btn-success btn-block" name="btn_nuevo_aviso"><span class="fa fa-check"></span> Publicar</button>
                        </div>
                         <div class="col-md-6">
                            <a href="publicar-aviso.php" class="btn btn-danger btn-block" ><span class="fa fa-stop"></span> Cancelar</a>
                        </div>
                    </div>

                    <div class="alert2 alert-dismissible alert-info">
					    <strong>Recuerda</strong> que puedes editar o eliminar tus avisos desde tu cuenta en la opción <a href="#" class="alert-link">"mis avisos"</a>
					</div>
					</form>
				</div>
			</div>
		</div>
	<!-- end tab empleo -->

	<!-- tab venta -->
	    <div class="tab-pane fade" id="venta">
		    <div class="bs-callout bs-callout-blue">
			  	<h4>Estas creando un aviso de venta</h4>
			</div>
			    <div class="bs-callout bs-callout-blue">
			    <div class="panel-body">
			    
					<form id="val_pub_vent" enctype="multipart/form-data" method="post"  class="form-horizontal mitad" name="formu">
						<div class="form-group" hidden>
							<div class="col-md-1">
								<input type="text" id="myinput" value="<?php echo $superid; ?>" name="txtiduser" class="form-control" />
							</div>
							<script type="text/javascript">
								document.formu.myinput.style.display="none";
							</script>
						</div>

						<div class="form-group">
						    <label for="select" class="col-md-3 control-label">Ciudad</label>
						    <div class="col-md-4">
						        <select class="form-control" name="txtidciudad">
						        <option value="">Selecciona tu ciudad</option>
					          <?php
						        $stmt = $user_publicar->runQuery('SELECT * FROM cat_ciudad');
						        $stmt->execute();
						        while($row=$stmt->fetch(PDO::FETCH_ASSOC))
						        {
						        extract($row);
						        ?>
							    <option value="<?php echo $row['idCiudad']; ?>">
							    <?php echo $ciudad; ?>
							    </option>
							        <?php
							        }
							        ?>
						        </select>
						      </div>
	   					 </div>
						
						<div class="form-group">
						    <label for="select" class="col-md-3 control-label">Venta de</label>
						    <div class="col-md-6">
						        <select class="form-control" name="txtidcat">
						        <option value="">Seleccione una opción</option>
						          <?php
							        $stmt = $user_publicar->runQuery('SELECT * FROM cat_venta WHERE visible=1');
							        $stmt->execute();
							        while($row=$stmt->fetch(PDO::FETCH_ASSOC))
							        {
							            extract($row);
							            ?>
							    	<option value="<?php echo $idcat_venta; ?>">
							            <?php echo $nombre; ?>
							      	</option>
							        <?php
							        }
							        ?>
						        </select>
						      </div>
	   					 </div>

						<div class="form-group">
							<label class="col-md-3 control-label">título</label>
							<div class="col-md-8">
								<input type="text" name="txttitulo" class="form-control" />
								<script type="text/javascript">
									document.formu.inputmax.maxLength = 40;
								</script>
							</div>
						</div>
						<div class="form-group">
					      <label for="textArea" class="col-md-3 control-label">Descripción</label>
					      <div class="col-md-8">
					        <textarea id="inputmax2" class="form-control" rows="3" name="txtdesc" ></textarea>
					        <script type="text/javascript">
								document.formu.inputmax2.maxLength = 500;
							</script>
					         <span class="help-block">Ingresa un dato de referencia para que puedan contactarse contigo (max. 500 caracteres)</span>
					      </div>
					    </div>
					    <div class="form-group">
					    	<label class="col-md-3 control-label">Subir foto</label>
					    	<div class="col-md-5">
				                <div class="imageupload">
				                    <div class="file-tab">
				                        <label class="btn btn-default btn-file">
				                            <span>Buscar..</span>
				                            <input class="input-group" type="file" name="foto_image" accept="image/*">
				                        </label>
				                        <button type="button" class="btn btn-default">Borrar</button>
				                    </div>
				                </div>
				            </div>
					    </div>
						
						<div class="form-group">
							<label class="col-md-3 control-label">precio</label>
							<div class="col-md-3">
								<input id="inputmax3" type="text" name="txtprecio" class="form-control" value="$ ">
								<span class="help-block">El precio debe estar en ($)</span>
								<script type="text/javascript">
									document.formu.inputmax3.maxLength = 10;
								</script>					
							</div>
						</div>

						<div class="form-group">
              		        <div class="col-md-6">
                            	<button type="submit" class="btn btn-success btn-block" name="btn_nuevo_venta"><span class="fa fa-check"></span> Publicar</button>
                            </div>
                             <div class="col-md-6">
                                <a href="publicar-aviso.php" class="btn btn-danger btn-block" ><span class="fa fa-stop"></span> Cancelar</a>
                            </div>
                        </div>

                        <div class="alert2 alert-dismissible alert-info">
						  	<strong>Recuerda</strong> que puedes editar o eliminar tus avisos desde tu cuenta en la opción <a href="mis-avisos.php" class="alert-link">"Mis avisos"</a>
						</div>
						</form>
					</div>
				</div>
		</div>
	<!-- end tab venta -->

	<!-- star servicios -->
		<div class="tab-pane fade" id="servicios">
			<div class="bs-callout bs-callout-orange">
				<h4>Estas creando un aviso de Servicio</h4>
			</div>
		    <div class="bs-callout bs-callout-orange">
			    <div class="panel-body">	    
					<form role="form" id="val_pub_serv" method="post"  class="form-horizontal mitad" name="formu_serv">
						<div class="form-group" hidden="">
							<div class="col-md-1">
								<input type="text" id="myinput" value="<?php echo $superid; ?>" name="txtiduser" class="form-control" />
							</div>
							<script type="text/javascript">
								document.formu_serv.myinput.style.display="none";
							</script>
						</div>
						
						<div class="form-group">
						    <label for="select" class="col-md-3 control-label">Ciudad</label>
						    <div class="col-md-4">
						        <select class="form-control" id="ciudad" name="txtidciudad">
						        <option value="">Selecciona tu ciudad</option>
					          <?php
						        $stmt = $user_publicar->runQuery('SELECT * FROM cat_ciudad');
						        $stmt->execute();
						        while($row=$stmt->fetch(PDO::FETCH_ASSOC))
						        {
						        extract($row);
						        ?>
							    <option value="<?php echo $row['idCiudad']; ?>">
							    <?php echo $ciudad; ?>
							    </option>
							        <?php
							        }
							        ?>
						        </select>
						      </div>
	   					 </div>
						
						<div class="form-group">
						    <label for="select" class="col-md-3 control-label">Servicio</label>
						    <div class="col-md-6">
						        <select class="form-control" id="select" name="txtidcat">
						        <option value="">Seleccione una opción</option>
						          <?php
							        $stmt = $user_publicar->runQuery('SELECT * FROM cat_servicio WHERE visible=1');
							        $stmt->execute();
							        while($row=$stmt->fetch(PDO::FETCH_ASSOC))
							        {
							            extract($row);
							            ?>
							    	<option value="<?php echo $idcat_servicio; ?>">
							            <?php echo $nombre; ?>
							      	</option>
							        <?php
							        }
							        ?>
						        </select>
						      </div>
	   					 </div>

						<div class="form-group">
							<label class="col-md-3 control-label">título</label>
							<div class="col-md-8">
								<input type="text" name="txttitulo" class="form-control"/>
								<script type="text/javascript">
									document.formu_serv.inputmax.maxLength = 40;
								</script>
							</div>
						</div>
						<div class="form-group">
					      <label for="textArea" class="col-md-3 control-label">Descripción</label>
					      <div class="col-md-8">
					        <textarea id="inputmax2" class="form-control" rows="3" name="txtdesc"></textarea>
					        <script type="text/javascript">
								document.formu_serv.inputmax2.maxLength = 500;
							</script>
					         <span class="help-block">Ingresa un dato de referencia para que puedan contactarse contigo (max. 500 caracteres)</span>
					      </div>
					    </div>

						<div class="form-group">
	          		        <div class="col-md-6">
	                        <button type="submit" class="btn btn-success btn-block" name="btn_nuevo_serv"><span class="fa fa-check"></span> Publicar</button>
	                        </div>
	                         <div class="col-md-6">
	                            <a href="publicar-aviso.php" class="btn btn-danger btn-block" ><span class="fa fa-stop"></span> Cancelar</a>
	                        </div>
	                    </div>
	                    <div class="alert2 alert-dismissible alert-info">
						  	<strong>Recuerda</strong> que puedes editar o eliminar tus avisos desde tu cuenta en la opción <a href="mis-avisos.php" class="alert-link">"Mis avisos"</a>
						</div>
					</form>
				</div>
			</div>		  
		</div>

	<!--star compra -->
		<div class="tab-pane fade" id="compra">
			<div class="bs-callout bs-callout-red">
				<h4>Estas creando un aviso de Compra</h4>
			</div>
		    <div class="bs-callout bs-callout-red">
			    <div class="panel-body">	    
					<form role="form" id="val_pub_com" method="post"  class="form-horizontal mitad" name="formu_com">
						<div class="form-group" hidden="">
							<div class="col-md-1">
								<input type="text" id="myinput" value="<?php echo $superid; ?>" name="txtiduser" class="form-control" />
							</div>
							<script type="text/javascript">
								document.formu_com.myinput.style.display="none";
							</script>
						</div>
						
						<div class="form-group">
						    <label for="select" class="col-md-3 control-label">Ciudad</label>
						    <div class="col-md-4">
						        <select class="form-control" id="ciudad" name="txtidciudad">
						        <option value="">Selecciona tu ciudad</option>
					          <?php
						        $stmt = $user_publicar->runQuery('SELECT * FROM cat_ciudad');
						        $stmt->execute();
						        while($row=$stmt->fetch(PDO::FETCH_ASSOC))
						        {
						        extract($row);
						        ?>
							    <option value="<?php echo $row['idCiudad']; ?>">
							    <?php echo $ciudad; ?>
							    </option>
							        <?php
							        }
							        ?>
						        </select>
						      </div>
	   					 </div>
						
						<div class="form-group">
						    <label for="select" class="col-md-3 control-label">Compra</label>
						    <div class="col-md-6">
						        <select class="form-control" id="select" name="txtidcat">
						        <option value="">Seleccione una opción</option>
						          <?php
							        $stmt = $user_publicar->runQuery('SELECT * FROM cat_compra WHERE visible=1');
							        $stmt->execute();
							        while($row=$stmt->fetch(PDO::FETCH_ASSOC))
							        {
							            extract($row);
							            ?>
							    	<option value="<?php echo $idcat_compra; ?>">
							            <?php echo $nombre; ?>
							      	</option>
							        <?php
							        }
							        ?>
						        </select>
						      </div>
	   					 </div>

						<div class="form-group">
							<label class="col-md-3 control-label">título</label>
							<div class="col-md-8">
								<input type="text" name="txttitulo" class="form-control"/>
								<script type="text/javascript">
									document.formu_com.inputmax.maxLength = 40;
								</script>
							</div>
						</div>
						<div class="form-group">
					      <label for="textArea" class="col-md-3 control-label">Descripción</label>
					      <div class="col-md-8">
					        <textarea id="inputmax2" class="form-control" rows="3" name="txtdesc"></textarea>
					        <script type="text/javascript">
								document.formu_com.inputmax2.maxLength = 500;
							</script>
					         <span class="help-block">Ingresa un dato de referencia para que puedan contactarse contigo (max. 500 caracteres)</span>
					      </div>
					    </div>

						<div class="form-group">
	          		        <div class="col-md-6">
	                        <button type="submit" class="btn btn-success btn-block" name="btn_nuevo_compra"><span class="fa fa-check"></span> Publicar</button>
	                        </div>
	                         <div class="col-md-6">
	                            <a href="publicar-aviso.php" class="btn btn-danger btn-block" ><span class="fa fa-stop"></span> Cancelar</a>
	                        </div>
	                    </div>
	                    <div class="alert2 alert-dismissible alert-info">
						  	<strong>Recuerda</strong> que puedes editar o eliminar tus avisos desde tu cuenta en la opción <a href="mis-avisos.php" class="alert-link">"Mis avisos"</a>
						</div>
					</form>
				</div>
			</div>		  
		</div>

					<div class="tab-pane fade" id="ayuda">
					<strong>Para publicar cualquiera de los cuatro avisos debes seguir estos pasos:</strong>
						<div class="alert2 alert-dismissible alert-info">
						  <ol>
							<li><strong>1.</strong> Seleccionar la ciudad donde se visualizará tu aviso.</li>
							<li><strong>2.</strong> Seleccionar la categoría a la que pertenece tu aviso, si la categoría que buscas no se encuentra allí puedes ubicarlo en la categoría “otros”.</li>
							<li><strong>3.</strong> Escribir un título para tu aviso, este debe ser una síntesis del contenido de tu aviso.</li>
							<li><strong>4.</strong> En la descripción debes poner los datos  de referencia como ser número telefónico y/o dirección, además la descripción debe  ser clara y especifica.</li>
							<li><strong>5.</strong> En caso de ser un aviso de empleo debes dar una fecha de vigencia. (Solo para avisos de empleo)</li>
							<li><strong>6.</strong> Para los avisos de venta se debe seguir todos los parámetros anteriores además de subir una foto de lo que se desea vender.</li>
							<li>* Recuerda que puedes editar y borrar tus avisos desde tu cuenta en la opción <a href="mis-avisos.php" class="alert-link">“Mis avisos”.</a></li>
							<li>* Todos los avisos cuentan con una descripción máxima de 500 caracteres (más espacios)</li>
							<li>* Los avisos que incumplan con las reglas y/o términos y condiciones serán bloqueados.</li>
						</ol>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
</section>
<?php include 'inc/footer.php'; ?>