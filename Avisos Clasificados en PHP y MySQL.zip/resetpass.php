<?php
require_once 'include/class.user.php';
$user = new USER();

if(empty($_GET['id']) && empty($_GET['code']))
{
    $user->redirect('login.php');
}

if(isset($_GET['id']) && isset($_GET['code']))
{
    $id = base64_decode($_GET['id']);
    $code = $_GET['code'];

    $stmt = $user->runQuery("SELECT * FROM usuarios WHERE userID=:uid AND codeAct=:code");
    $stmt->execute(array(":uid"=>$id,":code"=>$code));
    $rows = $stmt->fetch(PDO::FETCH_ASSOC);

    if($stmt->rowCount() == 1)
    {
        if(isset($_POST['btn-reset-pass']))
        {
            $pass = $_POST['contra'];
            $cpass = $_POST['confirm'];

            if($cpass!==$pass)
            {
                $msg = "<div class='alert alert-danger'>
                        <button class='close' data-dismiss='alert'>&times;</button>
                        <strong>Disculpe</strong> la contraseña no coincide.
                        </div>";
            }
            else
            {
                $pass_cifrado = password_hash($cpass, PASSWORD_DEFAULT);
                $password = $pass_cifrado;
                $stmt = $user->runQuery("UPDATE usuarios SET userContra=:upass WHERE userID=:uid");
                $stmt->execute(array(":upass"=>$password,":uid"=>$rows['userID']));

                $msg = "<div class='alert alert-success'>
                        <button class='close' data-dismiss='alert'>&times;</button>
                        La <strong>contraseña</strong> se actualizó correctamente.
                        </div>";
                header("refresh:5;login.php");
            }
        }
    }
    else
    {
        $msg = "<div class='alert alert-success'>
                <button class='close' data-dismiss='alert'>&times;</button>
                No se encontró ninguna cuenta, inténtalo mas tarde.
                </div>";
    }
}
?>
 <?php include 'inc/header.php'; ?>
	<div class="container">
		<div class="row">
			<div class="col-md-4  col-md-offset-4 ">
                <div class="alert alert-info">
                    Hola <strong><?php echo $rows['userNombre'] ?>,</strong>
                    Ahora puedes cambiar tu contraseña.
                </div>

				<div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Cambiar contraseña</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post" autocomplete="off">
                            <?php if(isset($msg))
                                {
                                    echo $msg;
                                }
                            ?>
                              <div class="form-group">
                                    <div class="form-group has-feedback">
    	                                <input class="form-control" placeholder="Nueva contraseña" name="contra" type="password" required>
                                        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                                    </div>
                               </div>

                              <div class="form-group">
                                    <div class="form-group has-feedback">
                                        <input class="form-control" placeholder="Confirmar contraseña" name="confirm" type="password" required>
                                        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                                    </div>
                               </div>

                                <button  type="submit" class="btn btn-success btn-block" name="btn-reset-pass"> <i class="fa fa-repeat"></i> Actualizar contraseña
                                </button>
                                <br>
                        </form>
                    </div>
                </div>
			</div>
		</div>
	</div>
<?php include 'inc/footer.php'; ?>

