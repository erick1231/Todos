<?php require_once 'include/class.user.php'; ?>
<?php require ('admin/config/core.php'); ?>
<!DOCTYPE html>
<html lang="es">
<head>
<title>
Avisos clasificados en California - 4avisos
</title>
    <meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="En 4avisos podrás publicar tus avisos clasificados gratis, además podrás encontrar empleo, vender, comprar y ofrecer tus servicios en las ciudades de California, encuentra eso que más buscas en 4avisos">
    <meta name="keywords" content="avisos clasificados California, avisos, anuncios, trabajo en California">
    <title>clasificados</title>
    <link href="app/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="app/css/bootstrap-lightbox.css">
    <link href="app/css/font.glyphicon.css" type="text/css" rel="stylesheet">
    <link href="app/css/font-awesome.min.css" type="text/css" rel="stylesheet" >
	<link href="app/css/responsive.css" rel="stylesheet">
	<link href="app/css/panel.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="app/css/bootstrap-social.css">
	<link rel="stylesheet" type="text/css" href="app/css/up-button.css">
	<!-- upload -->
	<link rel="stylesheet" type="text/css" href="app/css/uploadimage/bootstrap-imageupload.min.css">
	<!-- webcodeqr -->
	<link rel="stylesheet" type="text/css" href="app/css/webcam.css">
	<link rel="stylesheet" type="text/css" href="app/css/carousel.css">
	<link rel="stylesheet" type="text/css" href="app/css/bootstrapValidator.min.css">  
	<link rel="stylesheet" type="text/css" href="app/css/date/bootstrap-datetimepicker.css">
	<link rel="stylesheet" type="text/css" href="app/css/video/youtube.css">
	<link rel="shortcut icon" href="app/images/logo_4avisos.ico">
	<!-- css de list -->
	<link rel="stylesheet" type="text/css" href="app/css/list/jplist.demo-pages.min.css">
	<link rel="stylesheet" type="text/css" href="app/css/list/jplist.core.min.css">
	<link rel="stylesheet" type="text/css" href="app/css/list/jplist.pagination-bundle.min.css">
	<link rel="stylesheet" type="text/css" href="app/css/list/jplist.textbox-filter.min.css">
	<link rel="stylesheet" type="text/css" href="app/css/list/jplist.history-bundle.min.css">
	<link rel="stylesheet" type="text/css" href="app/css/list/jplist.start-rating-control.min.css">
	<link rel="stylesheet" type="text/css" href="app/css/list/style.list.css">
	<link rel="stylesheet" type="text/css" href="app/css/carousel/owl.carousel.css">
	<link rel="stylesheet" type="text/css" href="app/css/carousel/style.css">
	<link rel="stylesheet" type="text/css" href="app/css/carousel/owl.theme.css">
</head>
<body>
<header>
	<nav class="navbar navbar-default navbar-static-top">
		<div class="container">
			<div class="navbar-header">	
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<div class="logo">
					<a href="index.php">
						<img src="app/images/4avisos-california-principal.png" alt="avisos clasificados California" />
					</a>
				</div>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav navbar-right">
					<li><a href="index.php"><i class="fa fa-home"></i> Inicio</a></li>
					<li class="dropdown">
					    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
					    	<span class="fa fa-map-marker"> </span> Clasificados en California
					    	<span class="caret"></span></a>
					    <ul class="dropdown-menu" role="menu">
					    	<li><a href="avisos-clasificados-california.php">En toda California</a></li>
					    	<li><a href="clasificados-los-angeles.php">Los Ángeles</a></li>
					        <li><a href="clasificados-san-francisco.php">San Francisco</a></li>
					        <li><a href="clasificados-san-diego.php">San Diego</a></li>
					        <li><a href="clasificados-sacramento.php">Sacramento</a></li>
					        <li><a href="clasificados-mountain-view.php">Mountain View</a></li>
					        <li><a href="clasificados-long-beach.php">Long Beach</a></li>
					        <li><a href="clasificados-san-jose.php">San josé</a></li>
					        <li><a href="clasificados-fresno.php">Fresno</a></li>
					        <li><a href="clasificados-pasadena.php">Pasadena</a></li>
					    </ul>
					</li>
					<li><a href="clima-en-california.php"><i class="fa fa-cloud"></i> El clima</a></li>
					<li><a href="ayuda.php"><i class="fa fa-question-circle-o"></i> Ayuda</a></li>
					<li><a href="contacto.php"><i class="fa fa-envelope"></i> Contacto</a></li>
					<?php
					 	if(!isset($_SESSION['userSession']))
						{
					?>
					<li><a href="registrate.php"><i class="fa fa-pencil"></i> Registrarse</a></li>
					<li><a href="login.php"><i class="fa fa-lock"></i> Acceder</a></li>
					<?php
						}
						else
					{
						echo '<li><a href="mis-avisos.php"><i class="fa fa-book"></i> Mis avisos</a></li>';
						echo '<li><a href="publicar-aviso.php"><i class="fa fa-send"></i> Publicar</a></li>';
					?>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class=" fa fa-envelope-o"></span>
						 <?php echo $row['userEmail']; ?><span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<li><a href="mis-avisos.php"><i class="fa fa-list-alt"></i> Mis avisos</a></li>
							<li><a href="perfil.php"><i class="fa fa-user"></i> Perfil</a></li>
							<li role="separator" class="divider"></li>
							<li><a href="logout.php"><i class="fa fa-chevron-right"></i> Salir</a></li>
						</ul>
					</li>
					<?php
						}
					?>
				</ul>
		     </div>	
		</div>
	</nav>
</header>
