<span class="ir-arriba fa fa-chevron-up"></span>
<br>
<footer id="footer">
	<div class="footer-widget">
		<div class="container">
		<br>
			<div class="row">
				<div class="col-md-3 col-sm-6 col-xs-6">
					<div class="footer-one">
						<ul class="list1">
							<h4 class="redesinfo">Siguenos en</h4>
            				<a type="button" target="_blank" href="<?php echo RED_SOCIAL; ?>" class="btn btn-primary" aria-label="Left Align">
						  		<span class="fa fa-facebook" aria-hidden="true"></span>
							</a>
							<a type="button" target="_blank" href="<?php echo YOUTUBE; ?>" class="btn btn-danger" aria-label="Left Align">
						  		<span class="fa fa-youtube" aria-hidden="true"></span>
							</a>
							<!-- <li><a href="#">Terms of Use</a></li>
							<li><a href="#">Terms of Use</a></li> -->
						</ul>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-6">
					<div class="footer-two">
						<ul class="list2">
							<h4>Servicios</h4>
							<li><a href="registrate.php">Regístrate</a></li>
							<li><a href="publicar-aviso.php">Publicar aviso</a></li>
							<li><a href="login.php">Acceder</a></li>
							<li><a href="avisos-clasificados-california.php">Avisos clasificados</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-6">
					<div class="footer-tree">
						<ul class="list3">
							<h4>Información</h4>
							<li><a href="ayuda.php#acerca">Acerca de 4avisos</a></li>
							<li><a href="ayuda.php#terminos">Términos  y condiciones</a></li>
							<li><a href="#">Consejos de seguridad</a></li>
							<li><a href="contacto.php">Contacto</a></li>
						</ul>
					</div>
				</div>

				<div class="col-md-3 col-sm-6 col-xs-6">
					<div class="footer-four">
						<ul class="list4">
							<h4>Aplicaciones</h4>
							<li><a href="clima-en-california.php">El clima en California</a></li>
							<li><a href="ayuda.php">Ayuda</a></li>

						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footer-down">
		<div class="container">
			<div class="row">
				<p class="pull-left"><?php echo APP_COPY; ?></p>
				<p class="pull-right">Designed by <span><a href="https://anthoncode.com" target="_blank">Anthon Code</a></span></p>
			</div>
		</div>
	</div>
</footer>

	<script src="app/js/jquery.js"></script>
  	<script src="app/js/bootstrap.min.js"></script>
  	<script src="app/js/bootstrap-lightbox.min.js"></script>
  	<script src="app/js/bootstrapValidator.js"></script>
  	<script src="app/js/validator.js"></script>   
  
  	<script src="app/js/up-button.js"></script>
  	<!-- webcamqr JS -->
	<!-- <script type="text/javascript" src="app/js/qrcodelib.js"></script>
	<script type="text/javascript" src="app/js/WebCodeCam.js"></script>
	<script type="text/javascript" src="app/js/main.js"></script> -->
	<!-- carousel -->
	<script type="text/javascript" src="app/js/jquery.openCarousel.js"></script>
	<!-- upload -->
	<script type="text/javascript" src="app/js/uploadimage/bootstrap-imageupload.min.js"></script>
	<script>
        var $imageupload = $('.imageupload');
        $imageupload.imageupload();
    </script>	
	<script type="text/javascript" src="app/js/date/moment.min.js"></script>
	<script type="text/javascript" src="app/js/date/bootstrap-datetimepicker.js"></script>
	<script type="text/javascript" src="app/js/date/es.js"></script>
	<!-- <script type="text/javascript" src="app/js/bootstrap-datetimepicker.es.js"></script> -->
	<script type="text/javascript">
     $('#divMiCalendario').datetimepicker({
          format: 'YYYY-MM-DD',
          locale: 'es'
          /*dia por defecto de hoy*/

         /* inline: true,*/
               /* sideBySide: true*/
       /*format: 'YYYY-MM-DD HH:mm'   */
      });
     $('#divMiCalendarioV').datetimepicker({
          format: 'YYYY-MM-DD', 
          locale: 'es'      /*format: 'YYYY-MM-DD HH:mm'   */
      });
     $('#MiCalendarioAds').datetimepicker({
          format: 'YYYY-MM-DD', 
          locale: 'es'      /*format: 'YYYY-MM-DD HH:mm'   */
      });
      /*$('#divMiCalendario').data("DateTimePicker").show();*/
   </script>
	<script src="app/js/list/jplist.core.min.js"></script>	
	<script src="app/js/list/jplist.sort-bundle.min.js"></script>
	<script src="app/js/list/jplist.pagination-bundle.min.js"></script>
	<script src="app/js/list/jplist.textbox-filter.min.js"></script>
	<script src="app/js/list/jplist.history-bundle.min.js"></script>
	<script src="app/js/list/jplist.start-rating-control.min.js"></script>
	<script>
		$('document').ready(function(){	
				
			$('#demo').jplist({				
				itemsBox: '.list' 
				,itemPath: '.list-item' 
				,panelPath: '.jplist-panel'	
			});
		});
		</script>
	<script src="app/js/carousel/owl.carousel.min.js"></script>	
	<script src="app/js/carousel/slider.js"></script>
	<script>
    $(document).ready(function() {
     
      /*Sort random function*/
      function random(owlSelector){
        owlSelector.children().sort(function(){
            return Math.round(Math.random()) - 0.5;
        }).each(function(){
          $(this).appendTo(owlSelector);
        });
      }
     
      $("#owl-demo").owlCarousel({
      	autoPlay: 3000, //Set AutoPlay to 3 seconds
        items : 4,
        navigation: true,
        navigationText: [
          "<i class='fa fa-chevron-left fa-white'></i>",
          "<i class='fa fa-chevron-right fa-white'></i>"
          ],
        beforeInit : function(elem){
          /*Parameter elem pointing to $("#owl-demo")*/
          random(elem);
        }
      });
    });
</script>

<script>
    $(document).ready(function() {
 
  $("#owl-demo-publi").owlCarousel({
 	  autoPlay: 7000,
      navigation : true, // Show next and prev buttons
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem:true,
      itemsDesktopSmall : true,
      navigationText: [
          "<i class='fa fa-chevron-left fa-white'></i>",
          "<i class='fa fa-chevron-right fa-white'></i>"
          ],

  });
 
});
</script>	
<!-- tiempo de alert -->
<script type="text/javascript">
	window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(200, function(){
        $(this).remove(); 
    });
}, 4000);
</script>

<script src="app/js/video/youtube.js"></script>
</body>
</html>
