<?php 
	session_start();
	require_once 'include/class.user.php';
	$uaviso_empleo = new USER();

	if($uaviso_empleo->is_logged_in()){

	$stmt = $uaviso_empleo->runQuery("SELECT * FROM usuarios WHERE userID=:uid");
	$stmt->execute(array(":uid"=>$_SESSION['userSession']));    
	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	}
?>
 <?php
	if(isset($_GET['empleo-pasadena']))
	{
		$stmt = $uaviso_empleo->runQuery("SELECT * FROM cat_empleo WHERE idcat_empleo = :id");
		$stmt->execute(array(":id"=>$_GET['empleo-pasadena']));
		$row_empleo=$stmt->fetch(PDO::FETCH_ASSOC);
	}
	elseif(isset($_GET['venta-pasadena'])){
			$stmt = $uaviso_empleo->runQuery("SELECT * FROM cat_venta WHERE idcat_venta = :id");
			$stmt->execute(array(":id"=>$_GET['venta-pasadena']));
			$row_venta=$stmt->fetch(PDO::FETCH_ASSOC);
		}elseif(isset($_GET['servicios-pasadena'])){
					$stmt = $uaviso_empleo->runQuery("SELECT * FROM cat_servicio
													 WHERE idcat_servicio = :id");
					$stmt->execute(array(":id"=>$_GET['servicios-pasadena']));
					$row_servicios=$stmt->fetch(PDO::FETCH_ASSOC);
				}elseif(isset($_GET['compras-pasadena'])){
					$stmt = $uaviso_empleo->runQuery("SELECT * FROM cat_compra
													 WHERE idcat_compra = :id");
					$stmt->execute(array(":id"=>$_GET['compras-pasadena']));
					$row_compra=$stmt->fetch(PDO::FETCH_ASSOC);
				}

?>

<?php include 'inc/header.php'; ?>
<section class="main container">
		<div class="col-md-8">
			<div class="row">
			<?php if(isset($row_empleo['nombre']))
			{
				echo "<div class='bs-call bs-call-green'>";
				echo "<h1>Empleo de <strong>";
			 	echo $row_empleo["nombre"]; 
				echo "</strong>";
				echo " en la ciudad de <strong>Pasadena</strong></h1>";
				echo "</div>";
			} 
			elseif(isset($row_venta['nombre'])){
				echo "<div class='bs-call bs-call-blue'>";
				echo "<h1>Venta de <strong>";
			 	echo $row_venta["nombre"]; 
				echo "</strong>";
				echo " en la ciudad de <strong>Pasadena</strong></h1>";
				echo "</div>"; 
			}elseif(isset($row_servicios['nombre'])){
				echo "<div class='bs-call bs-call-orange'>";
				echo "<h1>Servicio de <strong>";
			 	echo $row_servicios["nombre"]; 
				echo "</strong>";
				echo " en la ciudad de <strong>Pasadena</strong></h1>";
				echo "</div>";
			}
			elseif (isset($row_compra['nombre'])) {
				echo "<div class='bs-call bs-call-red'>";
				echo "<h1>Compra de <strong>";
			 	echo $row_compra["nombre"]; 
				echo "</strong>";
				echo " en la ciudad de <strong>Pasadena</strong></h1>";
				echo "</div>";
			}
			?>
			</div>
			<div class="row">		
				<div id="demo" class="box jplist" style="margin: 20px 0 50px 0">
					<!-- ios button: show/hide panel -->
					<div class="jplist-ios-button">
						<i class="fa fa-hand-pointer-o"></i>
						Más opciones
					</div>
						<!-- panel -->
							<div class="jplist-panel box panel-top">						
								<!-- back button button -->
								<button 
									type="button" 
									data-control-type="back-button" 
									data-control-name="back-button" 
									data-control-action="back-button">
									<i class="fa fa-arrow-left"></i> Atras
								</button>
								<!-- reset button -->
								<button 
									type="button" 
									class="jplist-reset-btn"
									data-control-type="reset" 
									data-control-name="reset" 
									data-control-action="reset">
									Inicio &nbsp;<i class="fa fa-home"></i>
								</button>					
								<!-- items per page dropdown -->
								<div 
								   class="jplist-drop-down" 
								   data-control-type="items-per-page-drop-down" 
								   data-control-name="paging" 
								   data-control-action="paging">
								   <ul>
									 <li><span data-number="3"> Ver en 3 páginas </span></li>
									 <li><span data-number="5"> Ver en 5 páginas </span></li>
									 <li><span data-number="10" data-default="true"> Ver en 10 páginas </span></li>
									 <li><span data-number="all"> Ver todo </span></li>
								   </ul>
								</div>
								<!-- sort dropdown -->
								<div 
									class="jplist-drop-down" 
									data-control-type="sort-drop-down" 
									data-control-name="sort" 
									data-control-action="sort"
									data-datetime-format="{month}/{day}/{year}">
									<ul>
										<li><span data-type="number" data-order="desc" data-path=".jplist-reviews-number" data-default="true">Más reciente</span></li>
										<!-- <li><span data-type="number" data-order="desc" data-path=".jplist-star-rating-percent">Top Rated</span></li> -->
										<li><span data-path=".title" data-order="asc" data-type="text">Título de la A-Z</span></li>
										<li><span data-path=".title" data-order="desc" data-type="text">Título de la Z-A</span></li>
										<li><span data-path=".desc" data-order="asc" data-type="text">Descripción de A-Z</span></li>
										<li><span data-path=".desc" data-order="desc" data-type="text">Descripción de Z-A</span></li>
									</ul>
								</div>
								<!-- filter by title -->
								<div class="text-filter-box">						
									<i class="fa fa-search  jplist-icon"></i>			
									<!--[if lt IE 10]>
									<div class="jplist-label">Filter by Title:</div>
									<![endif]-->					
									<input 
										data-path=".title" 
										type="text" 
										value="" 
										placeholder="Filtrar por título" 
										data-control-type="textbox" 
										data-control-name="title-filter" 
										data-control-action="filter"
									/>
								</div>				
								<!-- filter by description -->
								<div class="text-filter-box">										
									<i class="fa fa-search  jplist-icon"></i>				
									<!--[if lt IE 10]>
									<div class="jplist-label">Filter by Description:</div>
									<![endif]-->													
									<input 
										data-path=".desc" 
										type="text" 
										value="" 
										placeholder="Filtrar por descripción" 
										data-control-type="textbox" 
										data-control-name="desc-filter" 
										data-control-action="filter"
									/>	
								</div>	
								<!-- pagination results -->
								<div 
								   class="jplist-label" 
								   data-type="Página {current} de {pages}" 
								   data-control-type="pagination-info" 
								   data-control-name="paging" 
								   data-control-action="paging">
								</div>			
								<!-- pagination control -->
								<div 
								   class="jplist-pagination" 
								   data-control-type="pagination" 
								   data-control-name="paging" 
								   data-control-action="paging">
								</div>
								
							</div>						
					<div class="list box text-shadow">

						<?php
				 			if(isset($_GET['empleo-pasadena'])){
							$stmt = $uaviso_empleo->runQuery("SELECT idaviso_empleo, usuarios.userID ,
																usuarios.userNombre , cat_ciudad.ciudad, 
																cat_empleo.idcat_empleo
																,cat_empleo.nombre ,
																titulo , descripcion , 
																fecha_pub , fecha_vigen,
																aviso_empleo.visible
																FROM aviso_empleo

																INNER JOIN usuarios
																ON aviso_empleo.id_usuario=usuarios.userID
																INNER JOIN cat_ciudad
																ON aviso_empleo.id_ciudad=cat_ciudad.idCiudad
																INNER JOIN cat_empleo
																ON aviso_empleo.id_categoria=cat_empleo.idcat_empleo 
																WHERE idCiudad = 8
																AND idcat_empleo = :id 
																AND aviso_empleo.visible = 'si' 

																ORDER BY idaviso_empleo DESC");

							$stmt->execute(array(":id"=>$_GET['empleo-pasadena']));
							while($row=$stmt->fetch(PDO::FETCH_ASSOC))
							{
						?>
						<div class="list-item box">	
							<div class="block right">
								<p class="date"><span class="fa fa-clock-o"></span> <?php $date = $row['fecha_pub'];?>
									<?php echo "Publicado hace: ". $uaviso_empleo->TimeAgo($date, date("Y-m-d H:i:s")); ?>
									</p>
								<p class="title"><?php echo $row['titulo']; ?></p>
								<p>
									<small>
										<span class="fa fa-map-marker"></span>
										<?php echo $row['ciudad']; ?>
									</small> 
									
								 </p>	
								 <p>
								 	<small>
										 <span class="fa fa-calendar-check-o"></span> Aviso vigente hasta:  
										<label class="text-primary">
										<?php $fecha_estandar = $row['fecha_vigen']; ?>
										<?php echo $uaviso_empleo->normaliza_date($fecha_estandar, date("Y-m-d")); ?></label>
									</small>
								 </p>		
									<!-- <h5 class="pull-right"><php echo $row['ciudad']; ?></h5> -->		
								<p class="desc">
									<?php echo $row['descripcion']; ?>
								</p>

								<div class="codigo">
								<p class="text-right">
									<small>4ABG75<?php echo $row['idaviso_empleo']; ?></small>
								</p>
								</div>

								<div class="text-right">
								<a href="reportar-aviso-empleo.php?reporte=<?php print($row["idaviso_empleo"]); ?>">
								<span class="label label-warning">Reportar</span></a>
								</div>	

								<div 
									data-control-type="star-rating" 
									class="jplist-star-rating"
									data-rating="4"
									data-total="1">
								</div>
							</div>
						</div>
						<!-- de no ser haci: -->
						<?php
							}
				     		}
				     		elseif(isset($_GET['venta-pasadena'])){
				
							$stmt = $uaviso_empleo->runQuery("SELECT idaviso_venta, usuarios.userID ,
														usuarios.userNombre , cat_ciudad.ciudad, 
														cat_venta.idcat_venta
														,cat_venta.nombre ,
														titulo , descripcion , foto, precio, 
														fecha_pub ,
														aviso_venta.visible
														FROM aviso_venta

														INNER JOIN usuarios
														ON aviso_venta.id_usuario=usuarios.userID
														INNER JOIN cat_ciudad
														ON aviso_venta.id_ciudad=cat_ciudad.idCiudad
														INNER JOIN cat_venta
														ON aviso_venta.id_cat_venta=cat_venta.idcat_venta 
														WHERE idCiudad = 8
														AND idcat_venta = :id 
														AND aviso_venta.visible = 'si'  
														ORDER BY idaviso_venta DESC");

							$stmt->execute(array(":id"=>$_GET['venta-pasadena']));
							while($row=$stmt->fetch(PDO::FETCH_ASSOC))
							{
						?>
						<div class="list-item box">	
							<div class="example">
							<a data-toggle="lightbox" href="#<?php echo $row['idaviso_venta']; ?>" >
								<div class="img">
									<img src="media/fotos_images4/<?php echo $row['foto']; ?>" class="thumbnail" alt="Click para ver la imagen">
								</div>
							</a>
							<div id="<?php echo $row['idaviso_venta']; ?>" class="lightbox fade"  tabindex="-1" role="dialog" aria-hidden="true">
							<div class='lightbox-dialog'>
								<div class='lightbox-content'>
									<img src="media/fotos_images4/<?php echo $row['foto']; ?>">
								<div class="lightbox-caption"><h4><?php echo $row['titulo']; ?></h4></div>
								</div>
							</div>
							</div>
							</div>
							<div class="new-block">
							<div class="block right">
								<p class="date"><span class="fa fa-clock-o"></span> <?php $date = $row['fecha_pub'];?>
									<?php echo "Publicado hace: ". $uaviso_empleo->TimeAgo($date, date("Y-m-d H:i:s")); ?>
									</p>
								<p class="title"><?php echo $row['titulo']; ?></p>
								<p>
									<small>
										<span class="fa fa-map-marker"></span>
										<?php echo $row['ciudad']; ?>
									</small> 
								 </p>
								<!--  <p>
								 	<small>
										 <span class="fa fa-calendar-check-o"></span> Aviso vigente hasta:  
										<label class="text-primary">
										<?php $fecha_estandar = $row['fecha_vigen']; ?>
										<?php echo $uaviso_empleo->normaliza_date($fecha_estandar, date("Y-m-d")); ?></label> 
									</small>
								 </p> -->
								 <p>
								 <small class="title" style="font-size: 85%; color: #505050; font-weight:normal;">
								 
										<span class="fa fa-money"></span>
										Precio: <?php echo $row['precio']; ?>
									
								 </small>
								 </p>
								<p class="desc">
									<?php echo $row['descripcion']; ?>
								</p>
								<div class="codigo">
								<p class="text-right">
									<small>4ABG75<?php echo $row['idaviso_venta']; ?></small>
								</p>
								</div>

								<div class="text-right">
								<a href="reportar-aviso-venta.php?reporte=<?php print($row["idaviso_venta"]); ?>">
								<span class="label label-warning">Reportar</span></a>
								</div>	

								<div 
									data-control-type="star-rating" 
									class="jplist-star-rating"
									data-rating="4"
									data-total="1">
								</div>
							</div>
							</div>

						</div>	
			      				       
						<?php 
						}
						}/**/
						elseif (isset($_GET['servicios-pasadena'])) {
						$stmt = $uaviso_empleo->runQuery("SELECT idaviso_servicio, usuarios.userID ,
														usuarios.userNombre , cat_ciudad.ciudad, 
														cat_servicio.idcat_servicio
														,cat_servicio.nombre ,
														titulo , descripcion , 
														fecha_pub,
														aviso_servicio.visible
														FROM aviso_servicio

														INNER JOIN usuarios
														ON aviso_servicio.id_usuario=usuarios.userID
														INNER JOIN cat_ciudad
														ON aviso_servicio.id_ciudad=cat_ciudad.idCiudad
														INNER JOIN cat_servicio
														ON aviso_servicio.id_cat_serv=cat_servicio.idcat_servicio 
														WHERE idCiudad = 8
														AND id_cat_serv = :id 
														AND aviso_servicio.visible = 'si'  
														ORDER BY idaviso_servicio DESC");

							$stmt->execute(array(":id"=>$_GET['servicios-pasadena']));
							while($row=$stmt->fetch(PDO::FETCH_ASSOC))
							{
						?>
						<div class="list-item box">	

						<div class="block right">
								<p class="date"><span class="fa fa-clock-o"></span> <?php $date = $row['fecha_pub'];?>
									<?php echo "Publicado hace: ". $uaviso_empleo->TimeAgo($date, date("Y-m-d H:i:s")); ?>
									</p>
								<p class="title"><?php echo $row['titulo']; ?></p>
								<p>
									<small>
										<span class="fa fa-map-marker"></span>
										<?php echo $row['ciudad']; ?>
									</small> 
									
								 </p>	
		
								<p class="desc">
									<?php echo $row['descripcion']; ?>
								</p>

								<div class="codigo">
								<p class="text-right">
									<small>4ABG75<?php echo $row['idaviso_servicio']; ?></small>
								</p>
								</div>	

								<div class="text-right">
								<a href="reportar-aviso-servicio.php?reporte=<?php print($row["idaviso_servicio"]); ?>">
								<span class="label label-warning">Reportar</span></a>
								</div>	

								<div 
									data-control-type="star-rating" 
									class="jplist-star-rating"
									data-rating="4"
									data-total="1">
								</div>
							</div>
						</div> 
						<?php  
							}
							}
							elseif (isset($_GET['compras-pasadena'])) {

							
						$stmt = $uaviso_empleo->runQuery("SELECT idaviso_compra, usuarios.userID ,
														usuarios.userNombre , cat_ciudad.ciudad, 
														cat_compra.idcat_compra
														,cat_compra.nombre ,
														titulo , descripcion ,
														fecha_pub,
														aviso_compra.visible 
														FROM aviso_compra

														INNER JOIN usuarios
														ON aviso_compra.id_usuario=usuarios.userID
														INNER JOIN cat_ciudad
														ON aviso_compra.id_ciudad=cat_ciudad.idCiudad
														INNER JOIN cat_compra
														ON aviso_compra.id_cat_compra=cat_compra.idcat_compra 
														WHERE idCiudad = 8
														AND idcat_compra = :id 
														AND aviso_compra.visible = 'si'  
														ORDER BY idaviso_compra DESC");
							$stmt->execute(array(":id"=>$_GET['compras-pasadena']));
							while($row=$stmt->fetch(PDO::FETCH_ASSOC))
							{
						?>
						<div class="list-item box">	

						<div class="block right">
								<p class="date"><span class="fa fa-clock-o"></span> <?php $date = $row['fecha_pub'];?>
									<?php echo "Publicado hace: ". $uaviso_empleo->TimeAgo($date, date("Y-m-d H:i:s")); ?>
									</p>
								<p class="title"><?php echo $row['titulo']; ?></p>
								<p>
									<small>
										<span class="fa fa-map-marker"></span>
										<?php echo $row['ciudad']; ?>
									</small> 
									
								 </p>	
		
								<p class="desc">
									<?php echo $row['descripcion']; ?>
								</p>

								<div class="codigo">
								<p class="text-right">
									<small>4ABG75<?php echo $row['idaviso_compra']; ?></small>
								</p>
								</div>	

								<div class="text-right">
								<a href="reportar-aviso-compra.php?reporte=<?php print($row["idaviso_compra"]); ?>">
								<span class="label label-warning">Reportar</span></a>
								</div>

								<div 
									data-control-type="star-rating" 
									class="jplist-star-rating"
									data-rating="4"
									data-total="1">
								</div>
							</div>
						</div> 

						<?php  
							}
							}
						?> 					  	
					</div><!-- end list item -->			
					<div class="box jplist-no-results text-shadow align-center">
					<br>
						<div class="alert alert-dismissible alert-success">
							<h3>No se encontraron <strong>resultados</strong>
							<span class="fa fa-frown-o fa-2x"></span></h3>
						</div>
					</div>
					<!-- ios button: show/hide panel -->
					<div class="jplist-ios-button">
						<i class="fa fa-hand-pointer-o"></i>
						Más opciones
					</div>
					<!-- panel -->
					<div class="jplist-panel box panel-bottom">						
						<div 
							class="jplist-drop-down left" 
							data-control-type="items-per-page-drop-down" 
							data-control-name="paging" 
							data-control-action="paging"
							data-control-animate-to-top="true">			
							<ul>
								<li><span data-number="3"> Ver en 3 páginas </span></li>
								<li><span data-number="5"> Ver en 5 páginas </span></li>
								<li><span data-number="10" data-default="true"> Ver en 10 páginas</span></li>
								<li><span data-number="all"> Ver todo </span></li>
							</ul>
						</div>
						<div 
							class="jplist-drop-down left" 
							data-control-type="sort-drop-down" 
							data-control-name="sort" 
							data-control-action="sort"
							data-control-animate-to-top="true">				
							<ul>
								<li><span data-type="number" data-order="desc" data-path=".jplist-reviews-number" data-default="true">Más reciente</span></li>
								<li><span data-path=".title" data-order="asc" data-type="text">Título de la A-Z</span></li>
								<li><span data-path=".title" data-order="desc" data-type="text">Título de la Z-A</span></li>
								<li><span data-path=".desc" data-order="asc" data-type="text">Descripción de A-Z</span></li>
								<li><span data-path=".desc" data-order="desc" data-type="text">Descripción de Z-A</span></li>
							</ul>
						</div>
						<div 
							class="jplist-label" 
							data-type="{start} - {end} de {all}" 
							data-control-type="pagination-info" 
							data-control-name="paging" 
							data-control-action="paging">
						</div>			
						<!-- pagination -->
						<div 
							class="jplist-pagination" 
							data-control-type="pagination" 
							data-control-name="paging" 
							data-control-action="paging"
							data-control-animate-to-top="true">
						</div>			
					</div>		
				</div>			
			</div>		
		</div>
	<aside class="col-md-4">
	    <a href="#" class="thumbnail">
	      	<img data-src="holder.js/800x180/text:hello" alt="hello" src="media/images/gif/adsense.jpg" style="width:300px; height: 600px;">
	    </a>        
    </aside>
</section>
<?php include 'inc/footer.php'; ?>