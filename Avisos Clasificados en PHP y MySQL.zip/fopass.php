<?php
session_start();
require_once 'include/class.user.php';
$user = new USER();
if($user->is_logged_in()!="")
{
	$user->redirect('index.php');
}
?>
<?php include 'inc/header.php'; ?>	
<?php  
if (isset($_POST['btn-fopass']))
{
	$email = $_POST['txtcorreo'];

	$stmt = $user->runQuery("SELECT userID FROM usuarios WHERE userEmail=:email LIMIT 1");
	$stmt->execute(array(":email"=>$email));
	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	if ($stmt->rowCount() == 1)
	{
		$id = base64_encode($row['userID']);
		$code = md5(uniqid(rand()));

		$stmt = $user->runQuery("UPDATE usuarios SET codeAct=:code WHERE userEmail=:email");
		$stmt->execute(array(":code"=>$code,"email"=>$email));
		$message= "
		<body>
            <style type='text/css'>
                body {
                font-family: Raleway; 
                font-size:14.4px;
                border: 1px dashed grey; 
                height: 0; 
                width: 100%;
                }
                </style>
            <p>
					Se envio un correo a: $email
					<br /><br />
					Nos han solicitado restablecer su contraseña, si realmente fue usted por favor haga 
					clic en el siguiente enlace:
					<br /><br />
					<a href='".HTML_DIR."/resetpass.php?id=$id&code=$code'> Clic aquí para cambiar tu contraseña.</a>
				   <br /><br />
				   Si usted no solicitó restablecer su contraseña ignore este mensaje.";
					$subjetc = "Restablece tu contraseña de ".APP_TITTLE_EMAIL."

			</p>
		</body>";


		$user->send_mail($email,$message,$subjetc);
		$msg = "<div class='alert alert-success'>
					<button class='close' data-dismiss='alert'>&times;</button>
					<i class='fa fa-envelope fa-2x'></i><strong> Enviamos un mensaje a su correo electrónico para restablecer una nueva contraseña.</strong>
				</div>";							
	}
	else
	{
		$msg = "<div class='alert alert-danger'>
					<button class='close' data-dismiss='alert'>&times;</button>
				<i class='fa fa-hand-stop-o fa-2x'></i><strong> Este correo no esta registrado.</strong>
				</div>";
	}		
}
?>
	<div class="container">
		<div class="row">
			<div class="col-md-4  col-md-offset-4 ">
				<div class="login-panel panel panel-default">
	                <div class="panel-heading">
	                   <h3 class="panel-title"><i class="fa fa-key"></i> Recuperar contraseña</h3>
	                </div>
	                <div class="panel-body">
	                    <form role="form" method="post" autocomplete="off">
	                <?php if(isset($msg)){echo $msg;}
		                else
		                {
	                	?>
		                	<div class='alert2 alert-info'>
		                	<button class="close" data-dismiss="alert">&times;</button>
		                	<strong>Por favor ingrese su correo para obtener una nueva contraseña.</strong>
		                	</div>
		            <?php 
		                }
		            ?>
	                      	<div class="form-group">
	                            <div class="form-group has-feedback">
	                                <input class="form-control" placeholder="Correo electronico" name="txtcorreo" type="email" required>
	                                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
	                            </div>
	                       	</div>
	                        <button  type="submit" name="btn-fopass" class="btn btn-primary btn-block">Recuperar contraseña</button>
	                    </form>
	                </div>
	            </div>
			</div>
		</div>
	</div>
<?php include 'inc/footer.php'; ?>
