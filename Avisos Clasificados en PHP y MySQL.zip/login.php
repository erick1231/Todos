<?php
session_start();
require_once 'include/class.user.php';
$user_login = new USER();
if($user_login->is_logged_in()!="")
{
    $user_login->redirect('publicar-aviso.php');
}

if(isset($_POST['btn-login']))
{
    $email = $user_login->limpiarCorreo($_POST['txtcorreo']);
    $contra = trim($_POST['txtcontra']);

    if (empty($email)) {
        $msg = "<div class='alert alert-danger'>
                    <button class='close' data-dismiss='alert'>&times;</button>
                    <strong>Ingrese un correo</strong>    
                </div>";

    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = "<div class='alert alert-danger'>
                    <button class='close' data-dismiss='alert'>&times;</button>
                    <strong>Ingrese un correo valido</strong>    
                </div>";
    }elseif (empty($contra)) {
        $msg = "<div class='alert alert-danger'>
                    <button class='close' data-dismiss='alert'>&times;</button>
                    <strong>Ingrese una contraseña</strong>    
                </div>";
    }else
    {
        if ($user_login->login($email,$contra)) 
        {
          $user_login->redirect('publicar-aviso.php');
        }
    }
}
?>
<?php include 'inc/header.php'; ?>
	<div class="container">
        <div class="row">
			<div class="col-md-4  col-md-offset-4 ">
				<div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-lock"></i> Inicio de sesión</h3>
                    </div>
                    <div class="panel-body">

                        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" autocomplete="off">
                        <?php if(isset($msg)) echo $msg; ?>
                        <?php
                        if (isset($_GET['error'])) 
                        {
                        ?>
                        <div class='alert alert-danger'>
                            <button class='close' data-dismiss='alert'>&times;</button>
                            <i class="fa fa-times fa-2x"></i><strong> Datos incorrectos</strong>    
                        </div>
                        <?php    
                        }
                        ?>
                        <?php
                             if(isset($_GET['inactive']))
                            {
                        ?>
                        <div class='alert alert-warning'>
                            <button class='close' data-dismiss='alert'>&times;</button>
                            <i class="fa fa-meh-o fa-2x"></i><strong> Esta cuenta no esta activada, revisa el enlace.</strong>
                        </div>
                        <?php
                        }
                        ?>

                        <?php
                             if(isset($_GET['accesodenegado']))
                            {
                        ?>

                        <div class='alert alert-danger'>
                            <button class='close' data-dismiss='alert'>&times;</button>
                            <i class="fa fa-frown-o fa-2x"></i><strong> Su cuenta esta bloqueada.</strong>
                        </div>
                        <?php
                        }
                        ?>
                        <div class="form-group">
                            <div class="form-group has-feedback">
                                <input class="form-control" placeholder="Correo electronico" name="txtcorreo" type="" required>
                                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="form-group has-feedback">
                                <input class="form-control" placeholder="Contraseña" name="txtcontra" type="password" required>
                                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                            </div> 
                        </div>

                        <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block" name="btn-login"><span class="fa fa-check"></span> Entrar</button>
                        </div>
                        <div class="form-group">
                            <a href="fopass.php" class="pull-left">¿Olvidaste tu contraseña?</a>
                            <a href="registrate.php" class="pull-right">Crear una cuenta</a>
                        </div>
                        </form>
                    </div>
                </div>
			</div>
		</div>
	</div>
<br>	
<?php include 'inc/footer.php'; ?>
