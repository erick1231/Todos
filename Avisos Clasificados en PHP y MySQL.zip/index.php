<?php 
session_start();
require_once 'include/class.user.php';
$user_home = new USER();
if($user_home->is_logged_in()){
$stmt = $user_home->runQuery("SELECT * FROM usuarios WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSession']));    
$row = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<?php include 'inc/header.php'; ?>	   
<div class="container">
    <section class="main row"> 
        <article class="col-md-9">
            <div class="bs-callout ">
                <div class="row"> 
                    <div class="col-md-8">
                      <h1>Encuentra lo que buscas en 4avisos</h1>
                    </div>
                    <div class="col-lg-4">
                      <a href="login.php"><button class="btn btn-warning btn-block pull-right "><span class="fa fa-send"></span> Crear aviso clasificado</button></a>
                    </div>
                </div>
            </div>

          	<div id="owl-demo-publi" class="owl-carousel owl-theme">
          	<?php 
                $stmt = $user_home->runQuery("SELECT * FROM publicidad WHERE visible='si' ORDER BY posicion ASC");
                $stmt->execute();
                while($row=$stmt->fetch(PDO::FETCH_ASSOC))
                    {
            ?>
		  		<div class="item"><img src="media/images_pub/<?php echo $row['imagen']; ?>" alt="<?php echo $row['descripcion']; ?>" title="Publicidad"></div>
		  	<?php 
                    }
            ?>
			</div><br>

            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="col-md-12">
                        <a href="avisos-clasificados-california.php" class="btn btn-success btn-block"><i class="fa fa-th-list"></i> En toda California</a>
                    </div>
                    <div class="col-md-4">
                      <a href="clasificados-los-angeles.php" class="btn btn-primary btn-block">Los Ángeles</a>
                      <a href ="clasificados-san-francisco.php" class="btn btn-primary btn-block">San Francisco</a>
                      <a href="clasificados-san-diego.php" class="btn btn-primary btn-block">San Diego</a>
                    </div>
                    <div class="col-md-4">
                      <a href="clasificados-sacramento.php" class="btn btn-primary btn-block">Sacramento</a>
                      <a href="clasificados-mountain-view.php" class="btn btn-primary btn-block">Mountain View</a>
                      <a href="clasificados-long-beach.php" class="btn btn-primary btn-block">Long Beach</a>
                    </div>
                    <div class="col-md-4">
                      <a href="clasificados-san-jose.php" class="btn btn-primary btn-block">San josé</a>
                      <a href="clasificados-fresno.php" class="btn btn-primary btn-block">Fresno</a>
                      <a href="clasificados-pasadena.php" class="btn btn-primary btn-block">Pasadena</a>
                    </div>
                </div>
            </div>

            <div class="bs-callout bs-callout-success">
                <h1>Avisos clasificados disponibles en toda <strong>California</strong></h1>
            </div>
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><span class="fa fa-briefcase fa-2x"></span> Empleos
                                    </h3>
                                </div>
                                <div class="panel-body">
                                          <?php /*en vez de: idcat_empleo puede ir idaviso-empleo */
                                            $stmt = $user_home->runQuery("SELECT idcat_empleo, 
                                                                    cat_empleo.nombre, COUNT(*)
                                                              FROM aviso_empleo

                                                              INNER JOIN cat_ciudad
                                                              ON aviso_empleo.id_ciudad=cat_ciudad.idCiudad
                                                              INNER JOIN cat_empleo
                                                              ON aviso_empleo.id_categoria=cat_empleo.idcat_empleo 
                                                              WHERE idcat_empleo
                                                              GROUP BY id_categoria 
                                                              ORDER BY posicion 
                                                              ASC");
                                                              $stmt->execute();
                                                              while($row=$stmt->fetch(PDO::FETCH_ASSOC))  
                                           {
                                               $contar = $row['COUNT(*)'];
                                             ?>
                                            <ul class="list-group">
                                                <a href="clasificados-en-california.php?empleos=<?php print($row['idcat_empleo']); ?>">
                                              <!-- otra opcion:  print($row['idaviso_empleo'])-->
                                                  <li class="list-group-item">
                                                      <span class="fa fa-caret-square-o-right"></span>
                                                      <?php echo $row['nombre']; ?>  
                                                      <span class="badge"><?php echo $contar; ?></span>
                                                  </li>
                                                </a>
                                                <?php 
                                                }
                                                 ?>
                                            </ul>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><span class="fa fa-handshake-o fa-2x"></span> Venta</h3>
                                </div>
                                <div class="panel-body">
                                      <?php
                                          $stmt = $user_home->runQuery("SELECT idcat_venta, cat_venta.nombre, COUNT(*)
                                                                  FROM aviso_venta

                                                                  INNER JOIN cat_ciudad
                                                                  ON aviso_venta.id_ciudad=cat_ciudad.idCiudad
                                                                  INNER JOIN cat_venta
                                                                  ON aviso_venta.id_cat_venta=cat_venta.idcat_venta
                                                                  WHERE idcat_venta
                                                                  GROUP BY id_cat_venta ORDER BY posicion ASC");
                                      $stmt->execute();
                                      while($row=$stmt->fetch(PDO::FETCH_ASSOC))  
                                          {
                                       $contar = $row['COUNT(*)'];
                                     ?>
                                    <ul class="list-group">
                                          <a href="clasificados-en-california.php?ventas=<?php print($row['idcat_venta']); ?>">
                                          <li class="list-group-item">
                                              <span class="fa fa-caret-square-o-right"></span>
                                              <?php echo $row['nombre']; ?>
                                              <span class="badge"><?php echo $contar; ?></span>
                                          </li> 
                                          </a>
                                      
                                      <?php 
                                          }
                                      ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><span class="fa fa-bullhorn fa-2x"></span> Servicios</h3>
                                </div>
                                <div class="panel-body">
                                  <?php
                                      $stmt = $user_home->runQuery("SELECT idcat_servicio, cat_servicio.nombre, 
                                                                      COUNT(*)
                                                                      FROM aviso_servicio

                                                                      INNER JOIN cat_ciudad
                                                                      ON aviso_servicio.id_ciudad=cat_ciudad.idCiudad
                                                                      INNER JOIN cat_servicio
                                                                      ON aviso_servicio.id_cat_serv=cat_servicio.idcat_servicio 
                                                                      WHERE idcat_servicio
                                                                      GROUP BY id_cat_serv ORDER BY posicion ASC");
                                      $stmt->execute();
                                      while($row=$stmt->fetch(PDO::FETCH_ASSOC))  
                                          {
                                       $contar = $row['COUNT(*)'];
                                     ?>
                                    <ul class="list-group">
                                        <a href="clasificados-en-california.php?servicios=<?php print($row['idcat_servicio']); ?>">
                                        <li class="list-group-item">
                                              <span class="fa fa-caret-square-o-right"></span>
                                              <?php echo $row['nombre']; ?>
                                              <span class="badge"><?php echo $contar; ?></span> 
                                        </li>
                                        </a>
                                      
                                      <?php 
                                          }
                                      ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><span class="fa fa-cart-arrow-down fa-2x"></span> Compra</h3>
                                </div>
                                <div class="panel-body">
                                      <?php
                                          $stmt = $user_home->runQuery("SELECT idcat_compra,
                                                                 cat_compra.nombre, COUNT(*)
                                                                FROM aviso_compra

                                                                INNER JOIN cat_ciudad
                                                                ON aviso_compra.id_ciudad=cat_ciudad.idCiudad
                                                                INNER JOIN cat_compra
                                                                ON aviso_compra.id_cat_compra=cat_compra.idcat_compra 
                                                                WHERE idcat_compra
                                                                GROUP BY id_cat_compra 
                                                                ORDER BY posicion ASC");
                                          $stmt->execute();
                                          while($row=$stmt->fetch(PDO::FETCH_ASSOC))  
                                          {
                                          $contar = $row['COUNT(*)'];
                                     ?>
                                    <ul class="list-group">
                                        <a href="clasificados-en-california.php?compras=<?php print($row['idcat_compra']); ?>">
                                        <li class="list-group-item">
                                              <span class="fa fa-caret-square-o-right"></span>
                                              <?php echo $row['nombre']; ?>
                                              <span class="badge"><?php echo $contar; ?></span>
                                        </li>
                                        </a>
                                      <?php 
                                          }
                                      ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="main">
                <div id="owl-demo"> 
                <?php 
                    $stmt = $user_home->runQuery("SELECT * FROM video_url ORDER BY idvideo_url DESC");
                    $stmt->execute();
                        while($row=$stmt->fetch(PDO::FETCH_ASSOC))  
                        {
                    ?> 
                    <div class="item">
                    <?php 
                    /*$url=$row['url'];*/
                    $videoURL = $row['url'];
                    $urlArr = explode("=",$videoURL); 
                    $urlArrNum = count($urlArr);
                    // Youtube video ID
                    $youtubeVideoId = $urlArr[$urlArrNum - 1];
                    // Genera imagen de video
                    $thumbURL = 'https://i.ytimg.com/vi/'.$youtubeVideoId.'/0.jpg';
                    // Display thumbnail image
                    echo '<a href ="'.$videoURL.'" target="_blank" >';
                    echo '<img src="'.$thumbURL.'" >';
                    echo '</a>';
                     ?>
                    </div>
                    <?php 
                        }
                     ?>
                </div>
            </div>
        </article>
    
        <aside class="col-md-3">
            <a href="#" class="thumbnail">
            <img data-src="holder.js/800x180/text:hello" alt="img" src="media/images/gif/adsense.jpg" style="width:300px; height: 600px;">
            </a>
        </aside>
    </section>
</div>
<?php include 'inc/footer.php'; ?>
