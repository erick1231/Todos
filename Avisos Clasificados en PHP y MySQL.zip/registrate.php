<?php
session_start();
require_once 'include/class.user.php';
$reg_user = new USER();

if($reg_user->is_logged_in()!="")
{
    $reg_user->redirect('index.php');
}
?>
<?php include 'inc/header.php'; ?>

<?php if (isset($_POST['btn_signup']))
{
    $unombre = $reg_user->limpiarDatos($_POST['txtnombre']);
    $apell = $reg_user->limpiarDatos($_POST['txtapellido']);
    $tele = trim($_POST['txttelefono']);
    $email = trim($_POST['txtcorreo']);
    $upass = trim($_POST['txtcontra']);
    $code = md5(uniqid(rand()));
    $fecha = date('y'.'/'.'m'.'/'.'d');

    if (empty($unombre && $apell && $tele && $email && $upass)) {
        $errorMSG = "Olvidaste un dato";
        //header("refresh:1;index.php");
    }
    else{

    $stmt = $reg_user->runQuery("SELECT * FROM usuarios WHERE userEmail=:email_id");
    $stmt->execute(array(":email_id"=>$email));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if($stmt->rowCount() > 0)
        {
            $msg = "<div class='alert alert-danger'>
                        <button class='close' data-dismiss='alert'>&times;</button>
                        <strong>Este correo electrónico ya esta registrado.</strong>
                    </div>";
               //header('refresh:2;index.php');
        }

        else
        {
            if($reg_user->register($unombre,$apell,$tele,$email,$upass,$code,$fecha))
            {
                $id = $reg_user->lasdID();
                $key = base64_encode($id);
                $id = $key;

                $message =  "
                            <body>
                            <style type='text/css'>
                                body {
                                font-family: Raleway; 
                                font-size:14.4px;
                                border: 1px dashed grey; 
                                height: 0; 
                                width: 100%;
                                }
                                </style>
                            <p>
                                Hola <strong>$unombre.</strong><br />
                                <strong>Gracias por registrarte.</strong>
                                <br /><br />
                                Se creó una cuenta en <strong>".APP_TITTLE_EMAIL."</strong> con esta dirección e-mail. <br />
                                Si no activaste una cuenta en ".APP_TITTLE_EMAIL." *NO* sigas este enlace. <br />
                                para confirmar y activar tu cuenta por favor sigue el siguiente enlace:         
                                <br /><br />
                                <a href='".HTML_DIR."/verify.php?id=$id&code=$code'>Clic aquí para activar tu cuenta :)</a>
                                <br /><br /><br />
                                Saludos el equipo de ".APP_TITTLE_EMAIL.".<br />
                                Este mensaje se envió desde una dirección e-mail que solo envia
                                notificaciones y no acepta mensaje de correo electronicos.
                                <br />
                                Por favor no responda a este mensaje.
                                <br /><br />
                                <img src='".HTML_DIR."/app/images/4avisos.png' class='center-block'>
                            </p>
                            </body>";

            $subject = "Confirme el registro de su cuenta - ".APP_TITTLE_EMAIL."";

            $reg_user->send_mail($email,$message,$subject);
            $msg = "
                    <div class='alert alert-success'>
                        <button class='close' data-dismiss='alert'>&times;</button>
                        <i class='fa fa-smile-o fa-2x'></i><strong> Su cuenta se creó correctamente, revise su bandeja de entrada o la carpeta de SPAM</strong>
                     </div>
                     ";
                }
                else
                {
                    echo "Disculpe, no se pudo realizar la operación";
                }
        }
    }
} ?>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4 ">
            <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-pencil"></i> Crear una cuenta</h3>
                    </div>
                <div class="panel-body">
                        <?php if(isset($msg)){
                            echo $msg;          
                        } 
                            elseif (isset($errorMSG)){
                            echo "<div class='alert alert-danger'>
                                    <button class='close' data-dismiss='alert'>&times;</button>
                                    <strong> $errorMSG </strong>
                                  </div>";
                        }
                        ?>
				    <form role="form" id="registrationForm" method="post" class="form-horizontal mitad" autocomplete="off">
                          <div class="form-group">
                                <label class="col-sm-4 control-label">Nombres</label>
                                    <div class="col-sm-8">
                                            <input type="text" name='txtnombre' class="form-control" maxlength="50">
                                    </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label">Apellidos</label>
                                    <div class="col-sm-8">
                                        <input type="text" name='txtapellido' class="form-control" maxlength="50">
                                    </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label">Teléfono</label>
                                    <div class="col-sm-8">
                                        <input type="" name='txttelefono' class="form-control" maxlength="10">
                                    </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label">Correo</label>
                                    <div class="col-sm-8">
                                        <input type="" name='txtcorreo' class="form-control" maxlength="60">
                                    </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label">Contraseña</label>
                                    <div class="col-sm-8">
                                        <input type="password" name='txtcontra' class="form-control" maxlength="20">  <!--required=""-->
                                    </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label">Confirmar contraseña</label>
                                    <div class="col-sm-8">
                                        <input type="password" name="txtconfirmar" class="form-control" maxlength="20">
                                    </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label"></label>
                                    <div class="col-sm-8">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox" name="terminos"> Estoy de acuerdo con los <a target="_blank" href="ayuda.php#terminos">Terminos y condiciones</a>
                                            </label>
                                        </div>
                                    </div>
                            </div>
              				<div class="form-group">
              		            <div class="col-sm-12">
                                <button  type="submit" class="btn btn-primary btn-block" name="btn_signup" value="registrar"><i class="glyphicon glyphicon-ok"></i> Crear cuenta</button>
                                </div>
                            </div>
                            <div class="alert alert-success">
                              <strong>Su cuenta se creó correctamente,</strong> revise su bandeja de entrada o SPAM
                            </div>
                        </form>
                </div>
            </div>
		</div>
  </div>
</div>
<?php include 'inc/footer.php'; ?>
