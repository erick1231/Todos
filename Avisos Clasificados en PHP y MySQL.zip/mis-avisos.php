<?php
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('login.php');
}
//extract($_SESSION);
$stmt = $user_ads->runQuery("SELECT * FROM usuarios WHERE userID=:id LIMIT 1");
$stmt->execute(array(":id"=>$_SESSION['userSession']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<?php include 'inc/header.php'; ?>
<section class="main container">
	<div class="row">
		<div class="col-sm-12 col-md-12">
			<div class="panel panel-default">
				<div class="panel-body">
				<div class="pull-left">
					<span class="fa fa-th-large fa-2x"></span> <label>Mis avisos  <label>
				</div>
				</div>

				<?php if (isset($_GET['actualizacion-correcta'])) {
					$msg = "<div class='alert alert-success'>
					<button type='button' class='close' data-dismiss='alert'>&times;</button>
					<span class='fa fa-smile-o fa-2x'></span> Tu aviso clasificado se <strong>actualizó correctamente</strong>
					</div>";
				}
				elseif (isset($_GET['error'])) {
					$msg = "<div class='alert alert-danger'>
					<button type='button' class='close' data-dismiss='alert'>&times;</button>
					<span class='fa fa-frown-o fa-2x'></span> No se pudo <strong>actualizar</strong> tu aviso intentalo mas tarde
					</div>";
				}elseif (isset($_GET['eliminar-aviso'])) {
					$msg = "<div class='alert alert-success'>
					<button type='button' class='close' data-dismiss='alert'>&times;</button>
					<span class='fa fa-smile-o fa-2x'></span> Tu aviso clasificado se <strong>eliminó correctamente</strong>
					</div>";
				}elseif (isset($_GET['datos'])) {
					$msg = "<div class='alert alert-danger'>
					<button type='button' class='close' data-dismiss='alert'>&times;</button>
					<span class='fa fa-frown-o fa-2x'></span> No se <strong>actualizó</strong> tu aviso porque olvidaste un <strong>dato,</strong> intentalo nuevamente
					</div>";
				} 
				?>
			</div>
			<?php if(isset($msg)){echo $msg;}?>
			<div class="panel panel-primary">
				<div class="panel-heading">
	    			<h3 class="panel-title"><span class="fa fa-align-justify"></span> Tus avisos clasificados de empleo</h3>
	  			</div>
			  	<div class="panel-body">
			  		<div class="table-responsive">
					   	<table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
						  	<thead>
							    <tr>
							      <th>Título</th>
							      <th>Descripción</th>
							      <th>Fecha de publicacion</th>
							      <th>Fecha de vigencia</th>
							      <th>Editar</th>
							      <th>Eliminar</th>
							    </tr>
							</thead>
							<tbody>
								  <?php 
									$stmt = $user_ads->runQuery("SELECT idaviso_empleo,idcat_empleo,
																		idCiudad,ciudad,nombre,titulo,
																		descripcion,fecha_pub,
																fecha_vigen 
																FROM aviso_empleo 

																INNER JOIN cat_ciudad
																ON aviso_empleo.id_ciudad=cat_ciudad.idCiudad

																INNER JOIN cat_empleo
																ON aviso_empleo.id_categoria=cat_empleo.idcat_empleo

																INNER JOIN usuarios
																ON aviso_empleo.id_usuario=usuarios.userID
																where userid=:uid 
																ORDER BY idaviso_empleo DESC");
									$stmt->execute(array(":uid"=>$_SESSION['userSession']));
									while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
										{
								   ?>
								    <tr>
								    <td><?php echo $row['titulo']; ?></td>
								    <td><?php echo $row['descripcion']; ?></td>
								    <td>
								    	<?php $fecha_estandar = $row['fecha_pub']; 
									 	echo $user_ads->normaliza_date_time($fecha_estandar, date("Y-m-d H:i:s"));
									 	?>
								    </td>
								    <td>
									    <?php $fecha_estandar = $row['fecha_vigen']; 
										echo $user_ads->normaliza_date($fecha_estandar, date("Y-m-d"));
										 ?>
								    </td>
								    <td align="center">
					 					<button data-toggle="modal" 
					 					data-target="#<?php echo $row['idaviso_empleo'];?>" class="btn btn-primary btn-block">
					 					<i class="fa fa-edit"></i>
					 					</button>
							      	</td>
							      	<td aling="center">
							      		<button data-toggle="modal" 
							      		data-target="#a<?php echo $row['idaviso_empleo'];?>" class="btn btn-danger btn-block" ><i class="fa fa-trash"></i></button>
							      	</td>
								    </tr>

				<!-- modal editar -->
				<div class="modal fade" id="<?php echo $row['idaviso_empleo']; ?>" 
				 tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
		          	<div class="modal-dialog modal-sm">
		            	<div class="modal-content">
		              		<div class="modal-header">
		                		<button type="button" class="close" data-dismiss="modal" 
		                		aria-label="Close"><span aria-hidden="true">&times;</span>
		                		</button>
		                		<h4 class="modal-title" id="myModalLabel">Editar aviso clasificado</h4>
		              		</div>
		              	<div class="modal-body">
						 	<form action="mis-avisos-estado.php" id="editar_empleo" method="post" name="form1" >

		           			<div class="form-group" hidden="true">
		           				<div class="col-md-1">
		                        <input class="form-control" id="myinput" name="idempleo" type="text" 
		                        value="<?php echo $row['idaviso_empleo'];?>">
		                        </div>
							</div>

		           			<label>Ciudad</label>
		           			<div class="form-group">
						        <select class="form-control" name="ciudad">
							       		<option value="<?php echo $row['idCiudad']; ?>">
							       		<?php echo $row['ciudad'];?>
							       		</option>
							          	<?php
								        $stmt2 = $user_ads->runQuery("SELECT * FROM cat_ciudad");
								        $stmt2->execute();
								        while($row2=$stmt2->fetch(PDO::FETCH_ASSOC))
								        	{
								        ?>
								    	<option value="<?php echo $row2['idCiudad']; ?>">
								    		<?php echo $row2['ciudad']; ?>
								    	</option>
								        <?php
								        	}
								        ?>
						        </select>  	
						 		</div>
		           			<label>Empleo</label>
		           			<div class="form-group">
						        <select class="form-control" name="empleo">
						        		<option value="<?php echo $row['idcat_empleo']; ?>">
						        		<?php echo $row['nombre']; ?>
						        		</option>
							           	<?php
								        $stmt3 = $user_ads->runQuery("SELECT * FROM cat_empleo");
								        $stmt3->execute();
								        while($row3=$stmt3->fetch(PDO::FETCH_ASSOC))
								        	{
								        ?>
								    	<option value="<?php echo $row3['idcat_empleo']; ?>">
								            <?php echo $row3['nombre']; ?>
								    	</option>
								        <?php
								        	}
								        ?>
						        </select>
						 		</div>
		                    <label>Título:</label>
		                    <div class="form-group">
		                        <input class="form-control" name="titulo" type="text" value="<?php  echo $row['titulo']; ?>" required maxlength="40" >
							</div>
							<label>Descripción:</label>
		                    <div class="form-group">
					        <textarea maxlength="500" class="form-control" rows="3" required name="descripcion"><?php echo $row['descripcion']; ?></textarea>

					        <span class="help-block">Máximo 500 caracteres </span>
				    		</div>
							<label>Fecha de vigencia:</label>
		                    <div class="form-group">
								<div class='input-group date' id='divMiCalendarioV'>
		                      	<input required type='text' name="fechavigencia" class="form-control" 
		                      	value="<?php echo date('Y-m-d'); ?>" />
			                      	<span class="input-group-addon"><span class="fa fa-calendar"></span>
			                      	</span>
		                  		</div>
							</div>			 
		              	</div>
	              			<div class="modal-footer">
	                			<button type="submit" class="btn btn-block btn-success btn-md" name="actualizar_aviso_empleo"><i class="fa fa-edit"></i> Editar</button>
					 			<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> Cancelar</button>
						    </form>
		              		</div>
		            	</div>
		          	</div>
		        </div>

		        <!-- modal eliminar -->
		        <div class="modal fade" id="a<?php echo $row['idaviso_empleo'];?>" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          			<div class="modal-dialog modal-sm">
            			<div class="modal-content">
              				<div class="modal-header">
                				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                				<h4 class="modal-title" id="myModalLabel">Eliminar aviso clasificado</h4>
                				
              				</div>
              			<div class="modal-body">
				 			<form method="post" action="mis-avisos-estado.php">
                   				<div class="alert alert-dismissible alert-info">
						  			<strong>Una vez eliminado tu aviso clasificado no se visualizará en la página principal</strong>
								</div>
								<div class="form-group" hidden="true">
			           				<div class="col-md-1">
							  			<input class="form-control" type="text" name="idempleo" value="<?php echo $row['idaviso_empleo'];?>">
							  		</div>
							  	</div>
              			</div>
              				<div class="modal-footer">
                				<button class="btn btn-block btn-success btn-md" name="eliminar_aviso_empleo"><i class="fa fa-check-square"></i> Si
                				</button>
				 				<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> No
				 				</button>
							</form>
              				</div>
            			</div>
          			</div>
        		</div>
								    <?php 
										}
								    ?>
							</tbody>
						</table>
					</div>
			  	</div>
			</div>
	
		<!-- aviso venta -->			
			<div class="panel panel-primary">
				<div class="panel-heading">
	    			<h3 class="panel-title"><span class="fa fa-align-justify"></span> Tus avisos clasificados de venta</h3>
	  			</div>
			  	<div class="panel-body">
			  		<div class="table-responsive">
					   	<table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
						  	<thead>
							    <tr>
							      <th>Id</th>
							      <th>Título</th>
							      <th>Descripción</th>
							      <th>Foto</th>
							      <th>Fecha de publicacion</th>
							      <th>Editar</th>
							      <th>Eliminar</th>
							    </tr>
							</thead>
							<tbody>
								  <?php 
									$stmt = $user_ads->runQuery("SELECT idaviso_venta,idcat_venta,
																		idCiudad,ciudad,ciudad,nombre,titulo,
																		descripcion,foto,fecha_pub
																FROM aviso_venta
																INNER JOIN cat_ciudad
																ON aviso_venta.id_ciudad=cat_ciudad.idCiudad
																INNER JOIN cat_venta
																ON aviso_venta.id_cat_venta=cat_venta.idcat_venta
																INNER JOIN usuarios
																ON aviso_venta.id_usuario=usuarios.userID
																where userID=:uid 
																ORDER BY idaviso_venta 
																DESC");
									$stmt->execute(array(":uid"=>$_SESSION['userSession']));
									while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
									{
								   ?>
								    <tr>
									<td><?php echo $row['idaviso_venta']; ?></td>
								    <td><?php echo $row['titulo']; ?></td>
								    <td><?php echo $row['descripcion']; ?></td>
								    <td>
									    <img src="media/fotos_images4/<?php echo $row['foto']; ?>"
									    style='width:130px; height:64px;'>
									    </td>
								    <td>
								    <?php $fecha_estandar = $row['fecha_pub']; 
									 	echo $user_ads->normaliza_date_time($fecha_estandar, date("Y-m-d H:i:s"));
									 ?>
								    </td>
								    <td align="center">
					 					<button data-toggle="modal" 
					 					data-target="#b<?php echo $row['idaviso_venta'];?>" class="btn btn-primary btn-block">
					 					<i class="fa fa-edit"></i>
					 					</button>
							      	</td>
							      	<td aling="center">
							      		<button data-toggle="modal" 
							      		data-target="#c<?php echo $row['idaviso_venta'];?>" class="btn btn-danger btn-block" ><i class="fa fa-trash"></i></button>
							      	</td>
								    </tr>

				<!-- modal editar venta -->
				<div class="modal fade" id="b<?php echo $row['idaviso_venta']; ?>" 
				 tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
		          	<div class="modal-dialog modal-sm">
		            	<div class="modal-content">
		              		<div class="modal-header">
		                		<button type="button" class="close" data-dismiss="modal" 
		                		aria-label="Close"><span aria-hidden="true">&times;</span>
		                		</button>
		                		<h4 class="modal-title" id="myModalLabel">Editar aviso clasificado</h4>
		              		</div>
			              	<div class="modal-body">
							 	<form method="post" enctype="multipart/form-data" class="form-horizontal" action="mis-avisos-estado.php">

			           			<div class="form-group" hidden="true">
			           				<div class="col-md-1">
			                        <input class="form-control" name="idventa" type="text" 
			                        value="<?php echo $row['idaviso_venta'];?>">
			                        </div>
								</div>

			           			<label>Ciudad</label>
			           			<div class="form-group">
							        <select class="form-control" name="ciudad">
								       		<option value="<?php echo $row['idCiudad']; ?>">
								       		<?php echo $row['ciudad']; ?>
								       		</option>
								          	<?php
									        $stmt2 = $user_ads->runQuery("SELECT * FROM cat_ciudad");
									        $stmt2->execute();
									        while($row2=$stmt2->fetch(PDO::FETCH_ASSOC))
									        	{
									        ?>
									    	<option value="<?php echo $row2['idCiudad']; ?>">
									    		<?php echo $row2['ciudad']; ?>
									    	</option>
									        <?php
									        	}
									        ?>
							        </select>  	
							 		</div>
			           			<label>Venta</label>
			           			<div class="form-group">
							        <select class="form-control" name="venta">
							        		<option value="<?php echo $row['idcat_venta']; ?>">
							        		<?php echo $row['nombre']; ?>
							        		</option>
								           	<?php
									        $stmt3 = $user_ads->runQuery("SELECT * FROM cat_venta");
									        $stmt3->execute();
									        while($row3=$stmt3->fetch(PDO::FETCH_ASSOC))
									        	{
									        ?>
									    	<option value="<?php echo $row3['idcat_venta']; ?>">
									            <?php echo $row3['nombre']; ?>
									    	</option>
									        <?php
									        	}
									        ?>
							        </select>
							 		</div>
			                    <label>Título:</label>
			                    <div class="form-group">
			                        <input class="form-control" name="titulo" type="text" value="<?php  echo $row['titulo']; ?>" required maxlength="40" >
								</div>
								<label>Descripción:</label>
			                    <div class="form-group">
							        <textarea required maxlength="500" class="form-control" rows="3" name="descripcion"><?php echo $row['descripcion']; ?></textarea>
							         <span class="help-block">Máximo 500 caracteres </span>
							        <label>Foto:</label>
							        <div class="imageupload">
						                <div class="file-tab">
						                    <label class="btn btn-default btn-file">
						                            <span>Buscar..</span>
						                            <input class="input-group" type="file" name="foto_imagen" accept="image/*">
						                    </label>
						                    <button type="button" class="btn btn-default">Borrar</button>
						                </div>
						            </div>
					    		</div>		 
			              	</div>
	              			<div class="modal-footer">
	                			<button class="btn btn-block btn-success btn-md" name="actualizar_aviso_venta"><i class="fa fa-edit"></i> Editar</button>
					 			<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> Cancelar</button>
						    </form>
		              		</div>
		            	</div>
		          	</div>
		        </div>

		        <!-- modal eliminar -->
		        <div class="modal fade" id="c<?php echo $row['idaviso_venta'];?>" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          			<div class="modal-dialog modal-sm">
            			<div class="modal-content">
              				<div class="modal-header">
                				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                				<h4 class="modal-title" id="myModalLabel">Eliminar aviso clasificado</h4>
                				
              				</div>
              			<div class="modal-body">
				 			<form enctype="multipart/form-data" method="post" action="mis-avisos-estado.php">
                   				<div class="alert alert-dismissible alert-info">
						  			<strong>Una vez eliminado tu aviso clasificado no se visualizará en la página principal</strong>
								</div>
								<div class="form-group" hidden="true">
			           				<div class="col-md-4">
							  			<input class="form-control" type="text" name="idventa" value="<?php echo $row['idaviso_venta'];?>">
							  		</div>
							  	</div>
              			</div>
              				<div class="modal-footer">
                				<button class="btn btn-block btn-success btn-md" name="eliminar_aviso_venta"><i class="fa fa-check-square"></i> Si
                				</button>
				 				<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> No
				 				</button>
							</form>
              				</div>
            			</div>
          			</div>
        		</div>

								    <?php 
									}
								    ?>
							</tbody>
						</table>
					</div>
			  	</div>
			</div>

		<!-- aviso servicio  -->
			<div class="panel panel-primary">
				<div class="panel-heading">
		    			<h3 class="panel-title"><span class="fa fa-align-justify"></span> Tus avisos clasificados de servicio</h3>
		  		</div>
			  	<div class="panel-body">
			  		<div class="table-responsive">
					   	<table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
						  	<thead>
							    <tr>
							      <th>Título</th>
							      <th>Descripción</th>
							      <th>Fecha de publicacion</th>
							      <th>Editar</th>
							      <th>Eliminar</th>
							    </tr>
							</thead>
							<tbody>
								  <?php 
									$stmt = $user_ads->runQuery("SELECT idaviso_servicio,idcat_servicio,
																		idCiudad,ciudad,
																		ciudad,nombre,titulo,
																		descripcion,fecha_pub 
																FROM aviso_servicio	
																INNER JOIN cat_ciudad
																ON aviso_servicio.id_ciudad=cat_ciudad.idCiudad
																INNER JOIN cat_servicio
																ON aviso_servicio.id_cat_serv=cat_servicio.idcat_servicio
																INNER JOIN usuarios
																ON aviso_servicio.id_usuario=usuarios.userID
																WHERE userID = :uid
																ORDER BY idaviso_servicio 
																DESC");
									$stmt->execute(array(":uid"=>$_SESSION['userSession']));
									$stmt->execute();
									while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
									{
								   ?>
								    <tr>
									<!-- <td><php echo $row['idaviso_servicio']; ?></td> -->
								    <td><?php echo $row['titulo']; ?></td>
								    <td><?php echo $row['descripcion']; ?></td>
								    <td>
								    <?php $fecha_estandar = $row['fecha_pub']; 
									 	echo $user_ads->normaliza_date_time($fecha_estandar, date("Y-m-d H:i:s"));
									 ?>
								    </td>
								    <td align="center">
					 					<button data-toggle="modal" 
					 					data-target="#e<?php echo $row['idaviso_servicio'];?>" class="btn btn-primary btn-block">
					 					<i class="fa fa-edit"></i>
					 					</button>
							      	</td>
							      	<td aling="center">
							      		<button data-toggle="modal" 
							      		data-target="#f<?php echo $row['idaviso_servicio'];?>" class="btn btn-danger btn-block" ><i class="fa fa-trash"></i></button>
							      	</td>
								    </tr>




				<!-- modal editar -->
				<div class="modal fade" id="e<?php echo $row['idaviso_servicio']; ?>" 
				 tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
		          	<div class="modal-dialog modal-sm">
		            	<div class="modal-content">
		              		<div class="modal-header">
		                		<button type="button" class="close" data-dismiss="modal" 
		                		aria-label="Close"><span aria-hidden="true">&times;</span>
		                		</button>
		                		<h4 class="modal-title" id="myModalLabel">Editar aviso clasificado</h4>
		              		</div>
		              	<div class="modal-body">
						 	<form method="post" action="mis-avisos-estado.php" >

		           			<div class="form-group" hidden="false">
		           				<div class="col-md-4">
		                        <input class="form-control" id="myinput" name="idservi" type="text" 
		                        value="<?php echo $row['idaviso_servicio'];?>">
		                        </div>
							</div>

		           			<label>Ciudad</label>
		           			<div class="form-group">
						        <select class="form-control" name="ciudad">
							       		<option value="<?php echo $row['idCiudad']; ?>">
							       		<?php echo $row['ciudad']; ?>
							       		</option>
							          	<?php
								        $stmt2 = $user_ads->runQuery("SELECT * FROM cat_ciudad");
								        $stmt2->execute();
								        while($row2=$stmt2->fetch(PDO::FETCH_ASSOC))
								        	{
								        ?>
								    	<option value="<?php echo $row2['idCiudad']; ?>">
								    		<?php echo $row2['ciudad']; ?>
								    	</option>
								        <?php
								        	}
								        ?>
						        </select>  	
						 		</div>
		           			<label>Empleo</label>
		           			<div class="form-group">
						        <select class="form-control" name="servicio">
						        		<option value="<?php echo $row['idcat_servicio']; ?>">
						        		<?php echo $row['nombre']; ?>
						        		</option>
							           	<?php
								        $stmt3 = $user_ads->runQuery("SELECT * FROM cat_servicio");
								        $stmt3->execute();
								        while($row3=$stmt3->fetch(PDO::FETCH_ASSOC))
								        	{
								        ?>
								    	<option value="<?php echo $row3['idcat_servicio']; ?>">
								            <?php echo $row3['nombre']; ?>
								    	</option>
								        <?php
								        	}
								        ?>
						        </select>
						 		</div>
		                    <label>Título:</label>
		                    <div class="form-group">
		                        <input class="form-control" name="titulo" type="text" value="<?php  echo $row['titulo']; ?>" required maxlength="40" >
							</div>
							<label>Descripción:</label>
		                    <div class="form-group">
					        <textarea required maxlength="500" class="form-control" rows="3" name="descripcion"><?php echo $row['descripcion']; ?></textarea>

					        <span class="help-block">Máximo 500 caracteres </span>
				    		</div>		 	
		              	</div>
	              			<div class="modal-footer">
	                			<button class="btn btn-block btn-success btn-md" name="actualizar_aviso_servicio"><i class="fa fa-edit"></i> Editar</button>
					 			<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> Cancelar</button>
						    </form>
		              		</div>
		            	</div>
		          	</div>
		        </div>

		        <!-- modal eliminar -->
		        <div class="modal fade" id="f<?php echo $row['idaviso_servicio'];?>" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          			<div class="modal-dialog modal-sm">
            			<div class="modal-content">
              				<div class="modal-header">
                				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                				<h4 class="modal-title" id="myModalLabel">Eliminar aviso clasificado</h4>
                				
              				</div>
              			<div class="modal-body">
				 			<form method="post" action="mis-avisos-estado.php">
                   				<div class="alert alert-dismissible alert-info">
						  			<strong>Una vez eliminado tu aviso clasificado no se visualizará en la página principal</strong>
								</div>
								<div class="form-group" hidden="true">
			           				<div class="col-md-1">
							  			<input class="form-control" type="text" name="idservi" value="<?php echo $row['idaviso_servicio'];?>">
							  		</div>
							  	</div>
              			</div>
              				<div class="modal-footer">
                				<button class="btn btn-block btn-success btn-md" name="eliminar_aviso_servicio"><i class="fa fa-check-square"></i> Si
                				</button>
				 				<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> No
				 				</button>
							</form>
              				</div>
            			</div>
          			</div>
        		</div>				    


								    <?php 
									}
								    ?>
							</tbody>
						</table>
					</div>
			  	</div>
			</div>

			<!-- aviso compra-->
			<div class="panel panel-primary">
				<div class="panel-heading">
	    			<h3 class="panel-title"><span class="fa fa-align-justify"></span> Tus avisos clasificados de compra</h3>
	  			</div>
			  	<div class="panel-body">
			  		<div class="table-responsive">
					   	<table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
						  	<thead>
							    <tr>
							    <!--   <th>Id</th> -->
							      <th>Título</th>
							      <th>Descripción</th>
							      <th>Fecha de publicacion</th>
							      <th>Editar</th>
							      <th>Eliminar</th>
							    </tr>
							</thead>
							<tbody>
								  <?php 
									$stmt = $user_ads->runQuery("SELECT idaviso_compra,idcat_compra,
																		idCiudad,ciudad,
																		nombre,titulo,descripcion,fecha_pub 
																FROM aviso_compra
																INNER JOIN cat_ciudad
																ON aviso_compra.id_ciudad=cat_ciudad.idCiudad
																INNER JOIN cat_compra
																ON aviso_compra.id_cat_compra=cat_compra.idcat_compra
																INNER JOIN usuarios
																ON aviso_compra.id_usuario=usuarios.userID
																where userID=:uid 
																ORDER BY idaviso_compra 
																DESC");
									$stmt->execute(array(":uid"=>$_SESSION['userSession']));
									while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
									{
								   ?>
								    <tr>
									<!-- <td><php echo $row['idaviso_compra']; ?></td> -->
								    <td><?php echo $row['titulo']; ?></td>
								    <td><?php echo $row['descripcion']; ?></td>
								    <td>
								    	<?php $fecha_estandar = $row['fecha_pub']; 
									 		echo $user_ads->normaliza_date_time($fecha_estandar, date("Y-m-d H:i:s"));
									 	?>
								    </td>
								  	<td align="center">
					 					<button data-toggle="modal" 
					 					data-target="#j<?php echo $row['idaviso_compra'];?>" class="btn btn-primary btn-block">
					 					<i class="fa fa-edit"></i>
					 					</button>
							      	</td>
							      	<td aling="center">
							      		<button data-toggle="modal" 
							      		data-target="#k<?php echo $row['idaviso_compra'];?>" class="btn btn-danger btn-block" ><i class="fa fa-trash"></i></button>
							      	</td>
								    </tr>

				<!-- modal editar -->
				<div class="modal fade" id="j<?php echo $row['idaviso_compra']; ?>" 
				 tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
		          	<div class="modal-dialog modal-sm">
		            	<div class="modal-content">
		              		<div class="modal-header">
		                		<button type="button" class="close" data-dismiss="modal" 
		                		aria-label="Close"><span aria-hidden="true">&times;</span>
		                		</button>
		                		<h4 class="modal-title" id="myModalLabel">Editar aviso clasificado</h4>
		              		</div>
		              	<div class="modal-body">
						 	<form method="post" action="mis-avisos-estado.php" >

		           			<div class="form-group" hidden="false">
		           				<div class="col-md-4">
		                        <input class="form-control" id="myinput" name="idcomp" type="text" 
		                        value="<?php echo $row['idaviso_compra'];?>">
		                        </div>
							</div>

		           			<label>Ciudad</label>
		           			<div class="form-group">
						        <select class="form-control" name="ciudad">
							       		<option value="<?php echo $row['idCiudad']; ?>">
							       		<?php echo $row['ciudad']; ?>
							       		</option>
							          	<?php
								        $stmt2 = $user_ads->runQuery("SELECT * FROM cat_ciudad");
								        $stmt2->execute();
								        while($row2=$stmt2->fetch(PDO::FETCH_ASSOC))
								        	{
								        ?>
								    	<option value="<?php echo $row2['idCiudad']; ?>">
								    		<?php echo $row2['ciudad']; ?>
								    	</option>
								        <?php
								        	}
								        ?>
						        </select>  	
						 		</div>
		           			<label>Empleo</label>
		           			<div class="form-group">
						        <select class="form-control" name="compra">
						        		<option value="<?php echo $row['idcat_compra']; ?>">
						        		<?php echo $row['nombre']; ?>
						        		</option>
							           	<?php
								        $stmt3 = $user_ads->runQuery("SELECT * FROM cat_compra");
								        $stmt3->execute();
								        while($row3=$stmt3->fetch(PDO::FETCH_ASSOC))
								        	{
								        ?>
								    	<option value="<?php echo $row3['idcat_compra']; ?>">
								            <?php echo $row3['nombre']; ?>
								    	</option>
								        <?php
								        	}
								        ?>
						        </select>
						 		</div>
		                    <label>Título:</label>
		                    <div class="form-group">
		                        <input class="form-control" name="titulo" type="text" value="<?php  echo $row['titulo']; ?>" required maxlength="40" >
							</div>
							<label>Descripción:</label>
		                    <div class="form-group">
					        <textarea required maxlength="500" class="form-control" rows="3" name="descripcion"><?php echo $row['descripcion']; ?></textarea>

					        <span class="help-block">Máximo 500 caracteres </span>
				    		</div>		 	
		              	</div>
	              			<div class="modal-footer">
	                			<button class="btn btn-block btn-success btn-md" name="actualizar_aviso_compra"><i class="fa fa-edit"></i> Editar</button>
					 			<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> Cancelar</button>
						    </form>
		              		</div>
		            	</div>
		          	</div>
		        </div>

		        <!-- modal eliminar -->
		        <div class="modal fade" id="k<?php echo $row['idaviso_compra'];?>" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          			<div class="modal-dialog modal-sm">
            			<div class="modal-content">
              				<div class="modal-header">
                				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                				<h4 class="modal-title" id="myModalLabel">Eliminar aviso clasificado</h4>
                				
              				</div>
              			<div class="modal-body">
				 			<form method="post" action="mis-avisos-estado.php">
                   				<div class="alert alert-dismissible alert-info">
						  			<strong>Una vez eliminado tu aviso clasificado no se visualizará en la página principal</strong>
								</div>
								<div class="form-group" hidden="true">
			           				<div class="col-md-1">
							  			<input class="form-control" type="text" name="idcomp" value="<?php echo $row['idaviso_compra'];?>">
							  		</div>
							  	</div>
              			</div>
              				<div class="modal-footer">
                				<button class="btn btn-block btn-success btn-md" name="eliminar_aviso_compra"><i class="fa fa-check-square"></i> Si
                				</button>
				 				<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> No
				 				</button>
							</form>
              				</div>
            			</div>
          			</div>
        		</div>				    
								    <?php 
									}
								    ?>
							</tbody>
						</table>
					</div>
			  	</div>
			</div>



			<div class="panel-group" id="accordion"> 
				<div class="panel panel-default"> 
					<div class="panel-heading"> 
						<h4 class="panel-title"> 
						<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne"> 
						<span class="fa fa-send"></span> Publicitar en esta página web</a> 
						</h4> 
					</div> 
					<div id="collapseOne" class="panel-collapse collapse"> 
						<div class="panel-body">
						<div class="col-md-6 text-justify">
							<div class="alert2 alert-dismissible alert-info">
							  	<strong>Pasos para publicitar.</strong>
							  	<p>
							  	Para publicitar en 4avisos.com debes elegir la duración y el precio del espacio publicitario.</p>
							  		<ol>
							  			<li>* Antes del pago debes notificarlo al siguiente <a href="<?php echo RED_SOCIAL; ?>" target="_blank" class="alert-link">enlace.</a></li>
							  			<li>* El pago lo puedes realizar atreves de (...) al siguiente numero:</li>
							  			<img src="app/images/4avisos-tigo-money.png" width="250px">
							  			<li>* Una vez realizado el pago te enviaremos un código para activar el formulario de envío, posteriormente debes ingresar los datos de tu publicidad, no olvides lo principal adjuntar tu imagen con el tamaño de <strong>960 x 195px</strong>.</li>
							  			<li>* Por ultimo revisaremos el contenido y en unos minutos lo publicaremos.</li>
							  		</ol>
							</div>
							<a href="publicitar-en-california.php" class="btn btn-primary btn-block">Publicitar ahora</a>
						</div>
						<div class="col-md-4">
							<!-- <p><img src="images/publicitar1.png"></p>
							<p><img src="images/publicitar2.png"></p> -->
						</div>
						</div> 
					</div> 
				</div> 
			</div>	
</section>
<?php include 'inc/footer.php'; ?>