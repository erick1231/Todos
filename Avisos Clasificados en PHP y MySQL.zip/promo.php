<?php
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('login.php');
}
//extract($_SESSION);
$stmt = $user_ads->runQuery("SELECT * FROM usuarios WHERE userID=:id LIMIT 1");
$stmt->execute(array(":id"=>$_SESSION['userSession']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<?php 
//insertar url de videos
if (isset($_POST['btn_promo_video']))
{
	$vis='no';
	$url_video = $_POST['txturl'];
	$descripcion = $_POST['txtdesc'];
	$visible = $vis;
	$posicion = $_POST['txtposicion'];
	$fecha_pub = date('Y-m-d H:i:s');

	$stmt = $user_ads->runQuery("SELECT * FROM video_url WHERE url=:url_video");
    $stmt->execute(array(":url_video"=>$url_video));
    $rowvideo = $stmt->fetch(PDO::FETCH_ASSOC);

    if($stmt->rowCount() > 0)
    {
        header("location:promocionar-video.php?duplicado");
    }
    else{

		if($user_ads->promocionar_video($url_video,$descripcion,$visible,$posicion,$fecha_pub))
			{
				header("location:promocionar-video.php?estado");
			}
			else
			{	
				header("location:promocionar-video.php?error");
			}
	}
}
?>