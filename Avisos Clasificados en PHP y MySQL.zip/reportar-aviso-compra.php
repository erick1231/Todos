<?php
session_start();
require_once 'include/class.user.php';
$user_publicar = new USER();

if($user_publicar->is_logged_in()){

$stmt = $user_publicar->runQuery("SELECT * FROM usuarios WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSession']));    
$row = $stmt->fetch(PDO::FETCH_ASSOC);
$superid=$row["userID"];
}
?>
<?php 
if (isset($_POST['btn_nuevo_reporte']))
	{	

	$id_usuario = $_POST['usuario'];
	$id_de_aviso = $_POST['aviso'];
	$motivo = $user_publicar->limpiarDatos($_POST['motivo']);
	$fecha_pub = date('Y-m-d H:i:s');

	//valida datos vacios con php (se valida con js y php )
	if (empty($motivo)) {
		$errorMSG = "Olvidaste un dato.";
    }
    else{

	$stmt = $user_publicar->runQuery("SELECT * FROM reportes_compra WHERE motivo=:motivo");
    $stmt->execute(array(":motivo"=>$motivo));
    $rowreporte = $stmt->fetch(PDO::FETCH_ASSOC);


	    if($stmt->rowCount() > 0)
	    {
	        $msg = "
	            <div class='alert alert-danger'>
	                <button class='close' data-dismiss='alert'>&times;</button>
	                <strong>Este reporte ya existe.</strong>
	            </div>";
	            //header('location:index.php');
	    }
	    else{

    	  if($user_publicar->reportar_aviso_compra($id_usuario,$id_de_aviso,$motivo,$fecha_pub))
			{
			$msg="<div class='alert alert-success'>
                <button class='close' data-dismiss='alert'>&times;</button>
                <span class='fa fa-smile-o fa-2x'></span> 
              		<strong>Revisaremos tu reporte.</strong>
             	</div>";
			}
	  		else
	  		{
	  		$msg="<div class='alert alert-danger'>
                <button class='close' data-dismiss='alert'>&times;</button>
                 <span class='fa fa-frown-o fa-2x'></span><strong> Ups!</strong> hubo un problema al enviar tu reporte.
             	</div>";
             	header('location:index.php');
	  		}
    	}
	}
}
?>
<?php include 'inc/header.php'; ?>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4 ">
            <div class="login-panel panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><i class="fa fa-clipboard"></i> Reportar aviso</h3>
                </div>
                <div class="panel-body">
                        <?php if(isset($msg)){
                            echo $msg;          
                        } 
                            elseif (isset($errorMSG)){
                            echo "<div class='alert alert-danger'>
                                    <button class='close' data-dismiss='alert'>&times;</button>
                                    <strong> $errorMSG </strong>
                                  </div>";
                        }
                        ?>
                        <?php 
                        //mostrar el id del aviso mediante get
                        	if (isset($_GET['reporte'])) {
                        		$var=$_GET["reporte"];		
                        	}
                        ?>
				    <form role="form" method="post" class="form-horizontal mitad" name="formu_r">
					<?php  
						if (!isset($_SESSION['userSession'])) {
							echo "<div class='alert alert-dismissible alert-danger'>
								  		<i class='fa fa-user-circle fa-2x'></i> Antes de <strong>reportar</strong> un <strong>aviso clasificado</strong> debe <strong>iniciar sesión</strong> <strong><a target='_blank' href='login.php'>aquí</a></strong>
									</div>";
							}
							else{
							?>

					   	<div class="alert2 alert-dismissible alert-info">
	  						Si el <strong>aviso incumple</strong> las reglas se procederá con la eliminación del aviso.
						</div>
						<div class="form-group" hidden>
							<div class="col-md-1">
								<input type="text" id="myinput1" value="<?php echo "$var"; ?>" name="aviso" class="form-control" />
							</div>
							<script type="text/javascript">
								document.formu_r.myinput1.style.display="none";
							</script>
						</div>
						<div class="form-group" hidden>
							<div class="col-md-1">
								<input type="text" id="myinput2" value="<?php echo $superid; ?>" name="usuario" class="form-control" />
							</div>
							<script type="text/javascript">
								document.formu_r.myinput2.style.display="none";
							</script>
						</div>

				    	<div class="form-group">
					     <label for="textArea" class="col-lg-2 control-label">Motivo</label>
					      	<div class="col-lg-10">
					        <textarea class="form-control" rows="3" id="textArea" name="motivo"></textarea>
					      	</div>
					    </div>

						<div class="form-group">
	          		        <div class="col-md-6">
	                        	<button type="submit" class="btn btn-success btn-block" name="btn_nuevo_reporte"><span class="fa fa-check"></span> Reportar</button>
	                        </div>
	                         <div class="col-md-6">
	                            <a href="publicar-aviso.php" class="btn btn-danger btn-block" ><span class="fa fa-stop"></span> Cancelar</a>
	                        </div>
                    	</div>
                    		<?php
								} 
							?>
                    </form>
                </div>
        	</div>
		</div>
	</div>
</div>
<br>
<?php include 'inc/footer.php'; ?>