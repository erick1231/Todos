<?php 
session_start();
require_once 'include/class.user.php';
$user_home = new USER();

if($user_home->is_logged_in()){

$stmt = $user_home->runQuery("SELECT * FROM usuarios WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSession']));    
$row = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<?php include 'inc/header.php';?>
  <div class="container"> 
        <div class="col-md-3"> 
            <ul class="nav nav-tabs nav-stacked" id="myNav"> 
                <li class="active"><a href="#bienvenida"><i class="fa fa-bookmark-o"></i> 
                Acerca de 4avisos </a></li> 
                <li class="active"><a href="#publicar"><i class="fa fa-bookmark-o"></i>
                 Publicar un avisos clasificado</a></li> 
                <li class="active"><a href="#publicitar"><i class="fa fa-bookmark-o"></i>
                 Publicitar</a></li> 
                <li class="active"><a href="#reportar"><i class="fa fa-bookmark-o"></i>
                 Reportar un aviso</a></li>
                <li class="active"><a href="#buscar"><i class="fa fa-bookmark-o"></i>
                 Buscar un aviso clasificado</a></li>
                <li class="active"><a href="#editar"><i class="fa fa-bookmark-o"></i>
                 Editar o borrar un aviso clasificado</a></li>
                <li class="active"><a href="#perfil"><i class="fa fa-bookmark-o"></i>
                 Editar perfil</a></li>
                <li class="active"><a href="#reglas"><i class="fa fa-bookmark-o"></i>
                 Reglas para los avisos</a></li>
                <li class="active"><a href="#prohibidos"><i class="fa fa-bookmark-o"></i>
                 Avisos prohibidos</a></li>
                <li class="active"><a href="#contenido"><i class="fa fa-bookmark-o"></i>
                 Conetido de los avisos</a></li>
                <li class="active"><a href="#terminos"><i class="fa fa-bookmark-o"></i>
                 Términos y Condiciones </a></li>
            </ul> 
        </div>

    <div class="col-md-9 text-justify"> 
        <br id="acerca">
        <div class="bs-callout">
        <h2>Acerca de 4avisos.com</h2>
        <p>Bienvenido a 4avisos.com donde podrás publicar tus avisos clasificados, este sitio web se caracteriza por contar con cuatro tipo de avisos:</p>
       
        <p><strong>Aviso de empleo,</strong> Si buscas empleo o necesitas buscar al personal para tu empresa este sitio web es el ideal para hacerlo.</p>

        <p><strong>Aviso venta,</strong> podrás vender eso que ya no usas o que simplemente quieres venderlo, antes de publicar tu aviso de venta debes contar con una foto de lo que quieras vender, la foto puede ser animada para tener un perfil de lo que deseas vender.</p>
            
        <p><strong>Aviso de servicio,</strong> eres un profesional o tienes una habilidad y quieres darte a conocer, lo ideal es subir tu aviso de servicio para que puedan contactar contigo y puedas ofrecer tus servicios.</p>
            
        <p><strong>Aviso de compra,</strong> no encontraste lo que buscas en la bandeja de venta, entonces es momento de publicar un aviso de compra para que contacten directamente contigo</p>
        <p>Recuerda que puedes ayudarnos a reportar avisos clasificados que no cumplan con los términos y condiciones de este sitio web.</p>
        </div>

        <br id="publicar">
        <div class="bs-callout">
        <h2>¿Cómo publicar un aviso clasificado?</h2>
        <p>Para publicar en 4avisos.com debes crear una cuenta en este sitio web, una vez hecho esto te enviaremos un mensaje de confirmación a tu correo electrónico, una vez que hayas confirmado tu cuenta podrás publicar cualquiera de los cuatro avisos clasificados, recuerda que para publicar cualquier aviso debes contar con la información necesaria, debes llenar los datos como ser el titulo el cual se visualizará en la parte superior del aviso, el contenido o descripción debe contar con la información necesaria como ser dirección y/o número telefónico y algunos otros datos, esto varía de acuerdo a cada aviso.</p>
        </div>

        <br id="publicitar">
        <div class="bs-callout">
        <h2>¿Cómo publicitar en 4avisos.com?</h2>
        <p>Antes de publicitar debes contar con una cuenta es este sitio web, si ya lo hiciste solo tienes que elegir el precio del espacio, más información sobre los precios haz clic <a href="publicitar-en-California.php" class="alert-link">aquí.</a></p>
        </div>
        <br id="reportar">
        <div class="bs-callout">
        <h2>¿Cómo reportar un aviso?</h2>
        <p>Para reportar un aviso clasificado debes iniciar sesión, una vez hecho esto elige el aviso que quieras reportar, en la parte inferior de cada aviso se encuentra un enlace que el nombre de “reportar” al seleccionar esta opción se desplegará un formulario donde debes llenar el motivo o causa del reporte para posteriormente enviarlo, si el aviso que reportaste incumple con las reglas de avisos o con los términos y condiciones se procederá a la eliminación de dicho aviso e incluso hasta el bloqueo del usuario.</p>
        <p>Si es que tuviste algún inconveniente al usar este sitio web por favor escríbenos al siguiente enlace.</p>
        </div>
        <br id="buscar">
        <div class="bs-callout">
        <h2>¿Cómo buscar un aviso clasificado?</h2>
        <p>Debes ingresar a la página principal de 4avisos.com si deseas buscar por ciudad lo puedes hacer buscando en el panel principal donde se encuentra el listado de las ciudades. Si deseas ver todos los avisos lo puedes hacer desde la opción “Toda California” el cual se encuentra en la parte superior de la página.
        </p>
        <p>
        Al elegir cualquiera de estas dos opciones usted podrá ver cuatro bandejas los cuales son todos los avisos disponibles, además podrá buscar el aviso por parámetros.
        </p>
        </div>
        <br  id="editar">
        <div class="bs-callout">
        <h2>¿Cómo editar o eliminar un aviso clasificado?</h2>
        <p>Debes dirigirte a la opción “Mis avisos” ubicado en tu misma cuenta allí se visualizara todos los avisos que publicaste, podrás editar y eliminar tus avisos, recuerda, si eliminas un aviso clasificado ya  no se visualizará en la página de 4avisos.com.</p>
        </div>
        <br id="perfil">
        <div class="bs-callout">
        <h2>¿Cómo cambiar datos de mi perfil?</h2>
        <p>Para editar los datos de tu perfil debes dirigirte a la opción  de “Mi Perfil”, podrás editar tus datos personales al igual que la contraseña.
        </p>
        <p>En la opción de “Mi perfil” también podrás encontrar la cantidad de avisos que publicaste en este sitio web.
        </p>
        </div>
        <br  id="reglas">
        <div class="bs-callout">
        <h2>Reglas para publicar un aviso clasificado</h2>
        <p>Si un aviso es rechazado es porque no cumple el reglamento, el usuario podrá cambiarlo, siempre y cuando se adapte a las reglas. Nos reservamos el derecho de decidir qué avisos no están de acuerdo con las reglas e incluso modificarlos para adaptarlos a ellas. Estas normas de uso están en constante revisión y pueden cambiar con el tiempo.</p>
        <p>Este sitio web se reserva el derecho a modificar o borrar avisos o partes de estos cuando se consideren incoherentes, incompletos o que no se ajusten a las reglas. </p>

        <ul class="list-unstyled"> 
            <li>• No están permitidos los avisos duplicados 
                No se permite publicar avisos con el mismo contenido o descripción en ninguno de los cuatro avisos ofrecidos, Si el usuario quiere publicar un aviso de un producto anunciado anteriormente deberá eliminar el primero antes de volver a publicar. Del mismo modo, no se permite publicar avisos con los mismos elementos o puestos de trabajo en diferentes categorías o ciudades del país.
            </li> 
            <li>• Enlaces, correos, sistemas de mensajería o redes sociales 
                No se permite publicar enlaces a otros sitios, avisos de subastas en línea, correos electrónicos, cuentas de sistemas de mensajería o redes sociales, caso contrario se eliminará el aviso clasificado.
            </li> 
            <li>• Precio 
                El precio del producto o servicio debe ser el final. No se permiten avisos con precios en cuotas, m2 o por partes. Este sitio web se reserva el derecho a modificar o borrar precios incoherentes que no tengan relación con el producto ofrecido.
            </li> 
            <li>Item 4</li> 
        </ul>
        <h4>Aviso empleo</h4>
        <p>
        Los avisos de empleo debe contar con la información necesaria, los avisos de empleo deben ser coherentes con sus necesidades, los avisos de empleo que ofrezcan poca información y grandes montos de sueldo serán eliminados de este sitio web en casos graves se bloqueara al usuario.
        </p>
        <h4>Aviso venta</h4>
        <p>Los avisos de venta debe contar con una foto si es posible el usuario hará uso de imágenes animadas del producto como si fuera un video ejemplo imágenes con formato GIF esto para tener un perfil del producto, las imágenes deben ser fidedignas.
        No se permite vender o suministrar los productos, bienes o servicios que están prohibidos por la legislación Californiana.</p>
        <h4>Aviso servicio</h4>
        <p>Los avisos de servicio deben contar con la información clara del usuario, información como a que se dedica o la profesión o especialidad, todo esto con los datos de contacto.</p>
        <h4>Aviso compra</h4>
        <p>Los avisos de compra deben tener una descripción de lo que se busca.</p>
        </div>
        <br id="prohibidos">
        <div class="bs-callout">
        <h2>Avisos prohibidos</h2>
        <p>Productos y servicios prohibidos 
        Existen restricciones para ciertos productos y servicios. Para ser más específica la prohibición de dichos avisos están en el marco de esta descripción.
        Productos que atenten en contra de la salud o bienestar de la población.
        </p>
        </div>
        <br id="contenido">
        <div class="bs-callout">
        <h2>Contenido</h2>
        <h3>Título del aviso</h3>
        <p>El Título del aviso debe describir lo siguiente,
        En caso de ser un aviso de empleo el título del empleo, 
        si es un aviso de venta el título del  producto, 
        si es un aviso de servicio el título de profesión o habilidad, 
        si es un aviso de compra el título del producto a compra. No se permiten nombres de empresas o URL (direcciones web). Ninguna persona puede ir en el título. El aviso clasificado debe ser descrito en el título del aviso. No se pueden copiar los títulos de otros anunciantes. No se pueden usar palabras incoherentes en el título, que sólo tengan el propósito de influir en los resultados de búsqueda.</p>

        <h3>Descripción del aviso </h3>
        <p>El producto o servicio debe ser descrito de la forma más clara posible, dejando claro de qué servicio se trata o qué es lo que se vende. No se pueden usar palabras incoherentes en la descripción, ya que sólo tiene el propósito de influir en los resultados de búsqueda. Así mismo, tampoco están permitidas direcciones de email ni enlaces a otras páginas web. </p>

        <h3>Imágenes</h3>
        <p>Las imágenes del aviso deben ser relevantes para el artículo o servicio anunciado. No se pueden utilizar los logotipos e imágenes de una empresa, a excepción de las categorías de Empleos y servicios. No se pueden utilizar imágenes de otros anunciantes sin permiso de los mismos. Marcas de agua y logos de empresas que ofrecen servicios similares a este sitio web.
        Caso contrario se eliminara dicho aviso.</p>

        <h3>Categorías</h3>
        <p>El aviso se debe introducir en la categoría que mejor describa el artículo o servicio (en caso contrario, el aviso puede ser rechazado o trasladado a la categoría correspondiente). Productos y servicios que no caben en la misma categoría se deben ingresar como avisos independientes. </p>

        <h3>Productos pirateados o falsificados</h3>
        <p>No se permite hacer publicidad de productos falsificados o productos piratas, tales como CDs, DVDs, programas informáticos o videojuegos. Todos los productos deben ser certificados específicamente como originales por el anunciante en la descripción del aviso. </p>

        <h3>Ubicación</h3>
        <p>4avisos.com es para toda el territorio Californiano.</p>

        <h3>Información privada</h3>
        <p>Información privada: El aviso debe contener solamente información relacionada al producto o servicio ofrecido.</p>

        <h3>Servicios</h3>
        <p>Los servicios ofrecidos deben cumplir las leyes y regulaciones aplicables a cada profesión.</p>

        <h3>Mascotas y animales</h3>
        <p>Quedan prohibidos los avisos  de venta con animales silvestres y que estén penalizados por la legislación Californiana.</p>

        <h3>Recuerda</h3>
        <p>• Sólo se puede crear un aviso por cada elemento. 
        Los avisos que tengan similitud con otros avisos serán eliminados
        Se eliminaran los avisos reportados que tengan fundamentos claros.
        No está permitido el uso de etiquetas HTML
        • No puedes publicar el mismo aviso en varios departamentos del país.
        </p>
        </div>
        <br id="terminos">
        <div class="bs-callout">
        <h2>Términos y Condiciones </h2>
        <p> A continuación se detalla los términos y condiciones generales para la correcta utilización de los servicios de 4avisos.com</p>

            <p>1.  El usuario podrá registrarse en este sitio web única y exclusivamente mediante el llenado de registro, en el cual debe ingresar datos personales como ser: nombres, apellidos, teléfono, correo y la contraseña estos dos últimos son necesarios para la creación de su cuenta, los mismos deben ser fidedignos, para la conclusión  se enviará un enlace de confirmación del cual el usuario debe confirmar su cuenta, este sitio web no se responsabiliza sobre la veracidad de los datos personales suministrados, el usuario que incurra en utilizar datos falsos será sancionado.
            El usuario podrá publicar en este sitio web con una cuenta la misma con la que se creó la cuenta, los datos que se requieren para iniciar sesión son el correo electrónico y la contraseña, en caso de que el  usuario olvido la contraseña, podrá solicitar la generación de una nueva contraseña, la cuenta en este sitio es personal por lo que queda prohibido que el usuario posea más de una cuenta.
            El usuario es responsable de todo el contenido de su cuenta, en caso de cualquier acceso no autorizado a su cuenta por terceros, el usuario se compromete a notificar a este sitio web de forma inmediata y con los datos verídicos de lo ocurrido, para posteriormente proceder con las acciones correspondientes.
            Los usuarios cuyos datos no hayan podido ser confirmados por el enlace se procederán al bloqueo de la cuenta</p>

            <p>2.  La publicación de avisos de venta y/o compra está regida de acuerdo a las siguientes condiciones.
            a)  El usuario podrá utilizar la forma de pago que sea de su preferencia, responsabilizándose por la transacción en todos los aspectos.
            b)  4avisos.com ofrece esta plataforma únicamente para interactuar entre usuarios y no  tiene relación alguna con la transacción de los usuarios.
            c)  El usuario debe respetar los avisos de acuerdo a sus categorías.
            d)  Este sitio web procederá con el borrado de avisos que incumplan las reglas de publicación o los términos y condiciones.
            e)  No es necesario ingresar el monto del producto a vender, en caso de ingresar el precio este debe ser serio.</p>

            <p>3.  La publicación de avisos de empleo y/o servicios está regida de acuerdo a las siguientes condiciones.
            a)  Este sitio web no garantiza sobre la veracidad del contenido de cada aviso, si hubiera alguna inconformidad se sugiere reportar el aviso.
            b)  Es importante los datos de referencia para los avisos de empleo.
            c)  Los avisos de servicio deben dar a conocer la profesión de habilidad de quien publica el aviso
            d)  Los avisos de empleo tienen la opción de elegir la fecha de vigencia del aviso, en caso de que los avisos de empleo hayan superado la vigencia se procederá con el borrado del mismo. </p>

            <p>4.  Las sanciones para los usuarios que no cumplan claramente las reglas de publicación o incumplan con los términos y condiciones se procederá al bloqueo de cuenta permanente.</p>

            <p>5.  Sobre la plataforma 4avisos.com no se garantiza el acceso y uso continuo, aclarar al usuario que este sitio web puede no estar disponible por fallas técnicas u otro motivo, por lo cual se realizara todo lo posible para restablecer el servicio con la mayor brevedad.</p>
            
            <p>6.  Este sitio web contiene enlaces a otros sitios web, por lo que aclaramos que no somos propietarios de esos enlaces por ese motivo no somos responsables del contenido.</p>
            
            <p>7.  4avisos.com podrá modificar sus términos y condiciones según lo considere, por lo que las actualizaciones de los términos y condiciones puede llevarse en cualquier momento, de esta forma el usuario está implicado en la aceptación de los términos y condiciones de este sitio, a la vez el usuario se compromete a estar atento a las nuevas actualizaciones, aclarando que todo usuario que no esté de acuerdo con las actualizaciones efectuadas puede solicitar la cancelación de su cuenta.</p>
            
            <p>El usuario declara que ha leído, comprendido y acepto los términos y condiciones del servicio que ofrece la plataforma 4avisos.com.</p>
        </div>
    </div>
</div>

       

<?php include 'inc/footer.php'; ?>