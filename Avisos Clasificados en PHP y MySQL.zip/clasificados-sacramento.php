<?php 
session_start();
require_once 'include/class.user.php';
$user_avisos = new USER();

if($user_avisos->is_logged_in()){

$stmt = $user_avisos->runQuery("SELECT * FROM usuarios WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSession']));    
$row = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<?php include 'inc/header.php'; ?>
<div class="container">
    <section class="main row"> 
        <article class="col-md-9">
            <div class="bs-callout"> 
            	<h1>Avisos clasificados en <strong>Sacramento</strong></h1>
            </div>
		<div id="owl-demo-publi" class="owl-carousel owl-theme">
            <?php 
                $stmt = $user_avisos->runQuery("SELECT * FROM publicidad WHERE visible='si' ORDER BY posicion ASC");
                $stmt->execute();
                while($row=$stmt->fetch(PDO::FETCH_ASSOC))
                    {
            ?>
                <div class="item"><img src="media/images_pub/<?php echo $row['imagen']; ?>" alt="<?php echo $row['descripcion']; ?>"></div>
            <?php 
                    }
            ?>
        </div>
        <div class="panel panel-default">
  			<div class="panel-body">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="panel panel-primary">
                  				<div class="panel-heading">
                  					<h3 class="panel-title"><span class="fa fa-briefcase fa-2x"></span> Empleos
                                    </h3>
                  				</div>
                  				<div class="panel-body">
                                <?php /*en vez de: idcat_empleo puede ir idaviso-empleo */
                                $stmt = $user_avisos->runQuery("SELECT idcat_empleo, cat_empleo.nombre, COUNT(*)
                                    FROM aviso_empleo

                                    INNER JOIN cat_ciudad
                                    ON aviso_empleo.id_ciudad=cat_ciudad.idCiudad
                                    INNER JOIN cat_empleo
                                    ON aviso_empleo.id_categoria=cat_empleo.idcat_empleo 
                                    WHERE idCiudad = 4
                                    AND aviso_empleo.visible = 'si' 
                                    GROUP BY id_categoria ORDER BY posicion ASC ");
                                    $stmt->execute();
                                    while($row=$stmt->fetch(PDO::FETCH_ASSOC))  
                                        {
                                        $contar = $row['COUNT(*)'];
                                   ?>
                                <ul class="list-group">
                                <a href="avisos-sacramento.php?empleo-sacramento=<?php print($row['idcat_empleo']); ?>">
                                <!-- otra opcion:  print($row['idaviso_empleo'])-->
                                    <li class="list-group-item">
                                        <span class="fa fa-caret-square-o-right"></span>
                                        <?php echo $row['nombre']; ?>  
                                        <span class="badge"><?php echo $contar; ?></span>
                                        <!-- <div class="pull-right">
                                        <span class="badge" >5000</span>
                                        </div> -->
                                    </li>
                                </a>
                                   <!--  <td>< echo "cat_empleo['nombre']"; ></td>  -->
                                   <!-- elimiar los puntos de li -->
                                  <?php 
                                  }
                                   ?>
                                   </ul>
                  				</div>
                		    </div>
                        </div>

                        <div class="col-md-6">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                  <h3 class="panel-title"><span class="fa fa-handshake-o fa-2x"></span> Venta</h3>
                                </div>
                                <div class="panel-body">
                                    <?php
                                        $stmt = $user_avisos->runQuery("SELECT idcat_venta, 
                                                                cat_venta.nombre, COUNT(*)
                                                                FROM aviso_venta
                                                                INNER JOIN cat_ciudad
                                                                ON aviso_venta.id_ciudad=cat_ciudad.idCiudad
                                                                INNER JOIN cat_venta
                                                                ON aviso_venta.id_cat_venta=cat_venta.idcat_venta 
                                                                WHERE idCiudad = 4
                                                                AND aviso_venta.visible = 'si' 
                                                                GROUP BY 
                                                                id_cat_venta 
                                                                ORDER BY posicion ASC");
                                    $stmt->execute();
                                    while($row=$stmt->fetch(PDO::FETCH_ASSOC))  
                                        {
                                     $contar = $row['COUNT(*)'];
                                   ?>
                                    <ul class="list-group">
                                        <a href="avisos-sacramento.php?venta-sacramento=<?php print($row['idcat_venta']); ?>">
                                        <li class="list-group-item">
                                            <span class="fa fa-caret-square-o-right"></span>
                                            <?php echo $row['nombre']; ?>
                                            <span class="badge"><?php echo $contar; ?></span>
                                        </li> 
                                        </a>
                                    <?php 
                                        }
                                    ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                  <h3 class="panel-title"><span class="fa fa-bullhorn fa-2x"></span> Servicios</h3>
                                </div>
                                <div class="panel-body">
                                <?php
                                    $stmt = $user_avisos->runQuery("SELECT idcat_servicio, 
                                                                    cat_servicio.nombre, COUNT(*)
                                                                    FROM aviso_servicio
                                                                    INNER JOIN cat_ciudad
                                                                    ON aviso_servicio.id_ciudad=cat_ciudad.idCiudad
                                                                    INNER JOIN cat_servicio
                                                                    ON aviso_servicio.id_cat_serv=cat_servicio.idcat_servicio 
                                                                    WHERE idCiudad = 4
                                                                    AND aviso_servicio.visible = 'si'  
                                                                    GROUP BY id_cat_serv 
                                                                    ORDER BY posicion ASC");
                                    $stmt->execute();
                                    while($row=$stmt->fetch(PDO::FETCH_ASSOC))  
                                        {
                                     $contar = $row['COUNT(*)'];
                                   ?>
                                    <ul class="list-group">
                                        <a href="avisos-sacramento.php?servicios-sacramento=<?php print($row['idcat_servicio']); ?>">
                                        <li class="list-group-item">
                                            <span class="fa fa-caret-square-o-right"></span>
                                            <?php echo $row['nombre']; ?>
                                            <span class="badge"><?php echo $contar; ?></span> 
                                        </li>
                                        </a>
                                    
                                    <?php 
                                        }
                                    ?>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                  <h3 class="panel-title"><span class="fa fa-cart-arrow-down fa-2x"></span> Compra</h3>
                                </div>
                                <div class="panel-body">
                                    <?php
                                        $stmt = $user_avisos->runQuery("SELECT idcat_compra, 
                                                                        cat_compra.nombre,COUNT(*)
                                                                        FROM aviso_compra
                                                                        INNER JOIN cat_ciudad
                                                                        ON aviso_compra.id_ciudad=cat_ciudad.idCiudad
                                                                        INNER JOIN cat_compra
                                                                        ON aviso_compra.id_cat_compra=cat_compra.idcat_compra 
                                                                        WHERE idCiudad = 4
                                                                        AND aviso_compra.visible = 'si'  
                                                                        GROUP BY id_cat_compra 
                                                                        ORDER BY posicion ASC");
                                        $stmt->execute();
                                        while($row=$stmt->fetch(PDO::FETCH_ASSOC))  
                                        {
                                            $contar = $row['COUNT(*)'];
                                   ?>
                                    <ul class="list-group">
                                        <a href="avisos-sacramento.php?compras-sacramento=<?php print($row['idcat_compra']); ?>">
                                        <li class="list-group-item">
                                            <span class="fa fa-caret-square-o-right"></span>
                                            <?php echo $row['nombre']; ?>
                                            <span class="badge"><?php echo $contar; ?></span>
                                        </li>
                                        </a>
                                    <?php 
                                        }
                                    ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                    </div>
                </div>
            </div>
        </div><br>

        </article>

        <aside class="col-md-3">
            <a href="#" class="thumbnail">
                <img data-src="holder.js/800x180/text:hello" alt="hello" src="media/images/gif/adsense.jpg" style="width:300px; height: 600px;">
            </a>       
        </aside>
    </section>
</div>
<?php include 'inc/footer.php'; ?>
