<?php 
	session_start();
	require_once 'include/class.user.php';
	$uaviso_venta = new USER();

	if($uaviso_venta->is_logged_in()){

	$stmt = $uaviso_venta->runQuery("SELECT * FROM usuarios WHERE userID=:uid");
	$stmt->execute(array(":uid"=>$_SESSION['userSession']));    
	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	}
?>
 <?php
	if(isset($_GET['venta-la-paz']))
	$stmt = $uaviso_venta->runQuery("SELECT * FROM cat_venta WHERE idcat_venta = :id");
	$stmt->execute(array(":id"=>$_GET['venta-la-paz']));
	$row_venta=$stmt->fetch(PDO::FETCH_ASSOC);
?>
<?php include 'inc/header.php'; ?>
<section class="main container">
	<aside class="col-md-3">
	     <a href="#" class="thumbnail">
	      <img data-src="holder.js/800x180/text:hello" alt="hello" src="media/images/gif/adsense.jpg" style="width:300px; height: 600px;">
	    </a> 
     </aside>
		<div class="col-md-6">
			<div class="row">
				<div class="bs-callout "><h4>Venta de: <strong><?php echo $row_venta['nombre']; ?></strong> en la ciudad de <strong>Los Ángeles</strong></h4>
				</div>
			</div>
			<div class="row">		
				<div id="demo" class="box jplist" style="margin: 20px 0 50px 0">
				
					<!-- ios button: show/hide panel -->
					<div class="jplist-ios-button">
						<i class="fa fa-sort"></i>
						jPList Actionsrerere
					</div>
					<div class="panel panel-default">
			  			<div class="panel-body">
						<!-- panel -->
							<div class="jplist-panel box panel-top">						
													
								<!-- back button button -->
								<button 
									type="button" 
									data-control-type="back-button" 
									data-control-name="back-button" 
									data-control-action="back-button">
									<i class="fa fa-arrow-left"></i> Atras
								</button>
													
								<!-- reset button -->
								<button 
									type="button" 
									class="jplist-reset-btn"
									data-control-type="reset" 
									data-control-name="reset" 
									data-control-action="reset">
									Inicio &nbsp;<i class="fa fa-share"></i>
								</button>
													
								<!-- items per page dropdown -->
								<div 
								   class="jplist-drop-down" 
								   data-control-type="items-per-page-drop-down" 
								   data-control-name="paging" 
								   data-control-action="paging">
								   
								   <ul>
									 <li><span data-number="3"> Ver en 3 páginas </span></li>
									 <li><span data-number="5"> Ver en 5 páginas </span></li>
									 <li><span data-number="10" data-default="true"> Ver en 10 páginas </span></li>
									 <li><span data-number="all"> Ver todo </span></li>
								   </ul>
								</div>
													
								<!-- sort dropdown -->
								<div 
									class="jplist-drop-down" 
									data-control-type="sort-drop-down" 
									data-control-name="sort" 
									data-control-action="sort"
									data-datetime-format="{month}/{day}/{year}"> <!-- {year}, {month}, {day}, {hour}, {min}, {sec} -->
														
									<ul>
										<li><span data-path="default">Sort by</span></li>
										<li><span data-type="number" data-order="desc" data-path=".jplist-reviews-number" data-default="true">Most Reviewed</span></li>
										<li><span data-type="number" data-order="desc" data-path=".jplist-star-rating-percent">Top Rated</span></li>
										<li><span data-path=".title" data-order="asc" data-type="text">Title A-Z</span></li>
										<li><span data-path=".title" data-order="desc" data-type="text">Title Z-A</span></li>
										<li><span data-path=".desc" data-order="asc" data-type="text">Description A-Z</span></li>
										<li><span data-path=".desc" data-order="desc" data-type="text">Description Z-A</span></li>
										<li><span data-path=".like" data-order="asc" data-type="number">Likes asc</span></li>
										<li><span data-path=".like" data-order="desc" data-type="number">Likes desc</span></li>
										<li><span data-path=".date" data-order="asc" data-type="datetime">Date asc</span></li>
										<li><span data-path=".date" data-order="desc" data-type="datetime">Date desc</span></li>
									</ul>
								</div>

								<!-- filter by title -->
								<div class="text-filter-box">
													
									<i class="fa fa-search  jplist-icon"></i>
														
									<!--[if lt IE 10]>
									<div class="jplist-label">Filter by Title:</div>
									<![endif]-->
														
									<input 
										data-path=".title" 
										type="text" 
										value="" 
										placeholder="Filtrar por título" 
										data-control-type="textbox" 
										data-control-name="title-filter" 
										data-control-action="filter"
									/>
								</div>
													
								<!-- filter by description -->
								<div class="text-filter-box">
														
									<i class="fa fa-search  jplist-icon"></i>
														
									<!--[if lt IE 10]>
									<div class="jplist-label">Filter by Description:</div>
									<![endif]-->
														
									<input 
										data-path=".desc" 
										type="text" 
										value="" 
										placeholder="Filtrar por descripción" 
										data-control-type="textbox" 
										data-control-name="desc-filter" 
										data-control-action="filter"
									/>	
								</div>
													
								<!-- pagination results -->
								<div 
								   class="jplist-label" 
								   data-type="Page {current} of {pages}" 
								   data-control-type="pagination-info" 
								   data-control-name="paging" 
								   data-control-action="paging">
								</div>
														
								<!-- pagination control -->
								<div 
								   class="jplist-pagination" 
								   data-control-type="pagination" 
								   data-control-name="paging" 
								   data-control-action="paging">
								</div>
								
							</div>	
						</div>
					</div>		
					<div class="list box text-shadow">

						<?php
				 			if(isset($_GET['venta-la-paz']))
				
							$stmt = $uaviso_venta->runQuery("SELECT idaviso_venta, usuarios.userID ,
															 usuarios.userNombre , cat_ciudad.ciudad, 
															 cat_venta.idcat_venta
															 ,cat_venta.nombre ,
															 titulo , descripcion , 
															 fecha_pub , fecha_vigen 
															 FROM aviso_venta

															INNER JOIN usuarios
															ON aviso_venta.id_usuario=usuarios.userID
															INNER JOIN cat_ciudad
															ON aviso_venta.id_ciudad=cat_ciudad.idCiudad
															INNER JOIN cat_venta
															ON aviso_venta.id_cat_venta=cat_venta.idcat_venta 
															WHERE idCiudad = 1 and idcat_venta = 
															:id ORDER BY idaviso_venta DESC");
							$stmt->execute(array(":id"=>$_GET['venta-la-paz']));
							while($row=$stmt->fetch(PDO::FETCH_ASSOC))
							{
						?>
						<div class="list-item box">	
							<div class="block right">
								<p class="date"><span class="fa fa-clock-o"></span> <?php $date = $row['fecha_pub'];?>
									<?php echo "Publicado hace: ". $uaviso_venta->TimeAgo($date, date("Y-m-d H:i:s")); ?>
									</p>
								<p class="title"><?php echo $row['titulo']; ?></p>
								<p>
									<small>
										<span class="fa fa-map-marker"></span>
										<?php echo $row['ciudad']; ?>
									</small> 
									<small>
										 <span class="fa fa-calendar-check-o"></span>Aviso vigente hasta: 
										<label class="text-primary">
										<?php $fecha_estandar = $row['fecha_vigen']; ?>
										<?php echo $uaviso_venta->normaliza_date($fecha_estandar, date("Y-m-d")); ?></label>
									</small>
								 </p>				
								<p class="desc">
									<?php echo $row['descripcion']; ?>
								</p>

								<div class="codigo">
								<p class="text-right">
									<small>4ABG75<?php echo $row['idaviso_venta']; ?></small>
								</p>
								</div>	
								<div 
									data-control-type="star-rating" 
									class="jplist-star-rating"
									data-rating="4"
									data-total="1">
								</div>
							</div>
						</div>
						<?php
				     		}
				        ?>
					</div>			
			
					<div class="box jplist-no-results text-shadow align-center">
						<div class="alert alert-dismissible alert-success">
							<h3>No se encontraron <strong>coincidencias</strong>
							<span class="fa fa-frown-o fa-2x"></span></h3>
						</div>
					</div>
					<!-- ios button: show/hide panel -->
					<div class="jplist-ios-button">
						<i class="fa fa-sort"></i>
						jPList Actions
					</div>
					<!-- panel -->
					<div class="jplist-panel box panel-bottom">						
						<div 
							class="jplist-drop-down left" 
							data-control-type="items-per-page-drop-down" 
							data-control-name="paging" 
							data-control-action="paging"
							data-control-animate-to-top="true">			
							<ul>
								<li><span data-number="3"> 3 per page </span></li>
								<li><span data-number="5"> 5 per page </span></li>
								<li><span data-number="10" data-default="true"> 10 per page </span></li>
								<li><span data-number="all"> view all </span></li>
							</ul>
						</div>
						<div 
							class="jplist-drop-down left" 
							data-control-type="sort-drop-down" 
							data-control-name="sort" 
							data-control-action="sort"
							data-control-animate-to-top="true">				
							<ul>
								<li><span data-type="number" data-order="desc" data-path=".jplist-reviews-number" data-default="true">Most Reviewed</span></li>
								<li><span data-type="number" data-order="desc" data-path=".jplist-star-rating-percent">Top Rated</span></li>
								<li><span data-path=".title" data-order="asc" data-type="text">Title A-Z</span></li>
								<li><span data-path=".title" data-order="desc" data-type="text">Title Z-A</span></li>
								<li><span data-path=".desc" data-order="asc" data-type="text">Description A-Z</span></li>
								<li><span data-path=".desc" data-order="desc" data-type="text">Description Z-A</span></li>
								<li><span data-path=".like" data-order="asc" data-type="number">Likes asc</span></li>
								<li><span data-path=".like" data-order="desc" data-type="number">Likes desc</span></li>
								<li><span data-path=".date" data-order="asc" data-type="datetime">Date asc</span></li>
								<li><span data-path=".date" data-order="desc" data-type="datetime">Date desc</span></li>
							</ul>
						</div>
						<div 
							class="jplist-label" 
							data-type="{start} - {end} of {all}" 
							data-control-type="pagination-info" 
							data-control-name="paging" 
							data-control-action="paging">
						</div>			
						<!-- pagination -->
						<div 
							class="jplist-pagination" 
							data-control-type="pagination" 
							data-control-name="paging" 
							data-control-action="paging"
							data-control-animate-to-top="true">
						</div>			
					</div>		
				</div>			
			</div>		
		</div>
	<aside class="col-md-3">
	    <a href="#" class="thumbnail">
	      	<img data-src="holder.js/800x180/text:hello" alt="hello" src="media/images/gif/adsense.jpg" style="width:300px; height: 600px;">
	    </a>        
    </aside>
</section>
<?php include 'inc/footer.php'; ?>