<?php
if(isset($_POST['eliminar_reporte_empleo']))
{
	$idemp = $_POST['idempleo'];
	if($user_ads->del_rep_emp($idemp))
		{
			header("location:reportes.php?eliminar-aviso");
		}
		else
		{
			header("location:reportes.php?error");
		}
}
?>

<?php
if(isset($_POST['eliminar_reporte_venta']))
{
	$idvent = $_POST['idventa'];
	if($user_ads->del_rep_vent($idvent))
		{
			header("location:reportes.php?eliminar-aviso");
		}
		else
		{
			header("location:reportes.php?error");
		}
}
?>

<?php
if(isset($_POST['eliminar_reporte_servicios']))
{
	$idserv = $_POST['idservicio'];
	if($user_ads->del_rep_serv($idserv))
		{
			header("location:reportes.php?eliminar-aviso");
		}
		else
		{
			header("location:reportes.php?error");
		}
}
?>

<?php
if(isset($_POST['eliminar_reporte_compra']))
{
	$idcom = $_POST['idcompra'];
	if($user_ads->del_rep_com($idcom))
		{
			header("location:reportes.php?eliminar-aviso");
		}
		else
		{
			header("location:reportes.php?error");
		}
}
?>