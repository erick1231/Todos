<?php
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('index.php');
}
$stmt = $user_ads->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<?php
$stmt2 = $user_ads->runQuery("SELECT * FROM mensaje");
$stmt2->execute();
$row_code=$stmt2->fetch(PDO::FETCH_ASSOC);
extract($row_code);

if (isset($_POST['btn_enviar'])) 
	{
		$id = $_POST['idmensaje'];
		$mensaje = $_POST['mensaje'];

		if($user_ads->act_mensaje($id,$mensaje))
			{
			$msgEnviar = "<div class='alert alert-success'>
						<button type='button' class='close' data-dismiss='alert'>&times;</button>
						<strong>Se envió el mensaje.</strong>
						</div>";
						header('refresh:1;mensajes.php');
			}
		else
			{
			$msgError =  "<div class='alert alert-danger'>
						<strong>Error</strong> al enviar, intente mas tarde.
						</div>";
			}
	}
	if(isset($_POST['idmensaje']))
	{
		$id = $_POST['idmensaje'];
		extract($user_ads->id_act_mensaje($id));	
	}
?>

<?php include 'inc/header.php'; ?>
<div class="container">
    <div class="row">
    	<div class="col-md-4 col-md-offset-4 ">
       		<div class="login-panel panel panel-primary">
            	<div class="panel-heading">
                <h3 class="panel-title"><span class="fa fa-envelope"></span> Mensaje para usuarios</h3>
            	</div>
        		<div class="panel-body">  
        		<?php
				if(isset($msg)) { echo $msg; } ?>	
					<form role="form" id="" method="post" class="form-horizontal mitad">
						<?php if(isset($msgEnviar)){
							echo $msgEnviar;
							}elseif (isset($msgError)) {
							echo $msgError;
							}elseif (isset($msgEliminar)) {
								echo $msgEliminar;
							}
						?>
	                    <div class="form-group" hidden>
	                        <div class="col-sm-2">
	                            <input type="text" name="idmensaje" value="<?php echo $idmensaje;?>" class="form-control">
	                        </div>
	                    </div>
	                    <div class="form-group">
					      	<label for="textArea" class="col-md-3 control-label">Mensaje</label>
					      	<div class="col-md-8">
					        <textarea class="form-control" rows="3" name="mensaje" ><?php echo $mensaje; ?></textarea>
					      </div>
					    </div><br>
	                    <div class="form-group">
							<div class="col-md-12">
								<button type="submit" class="btn btn-success btn-block" name="btn_enviar"><span class="fa fa-envelope"></span> Enviar mensaje</button>
							</div>
						</div>
				    </form>
                </div>
            </div>
		</div>
  	</div>    
</div>
<?php include 'inc/footer.php'; ?>