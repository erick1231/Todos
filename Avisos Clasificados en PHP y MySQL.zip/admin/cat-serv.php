<?php 
session_start();
require_once 'include/class.user.php';
$user_servicio = new USER();
if(!$user_servicio->is_logged_in())
{
  $user_servicio->redirect('index.php');
}
$stmt = $user_servicio->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<?php 
if (isset($_POST['btn_nuevo_servicio']))
{
	$eNombre = (htmlentities($_POST['txtnombre'],ENT_QUOTES,"UTF-8"));
	$ePosicion = $_POST['txtposicion'];
	$eVisible = $_POST['radiovisible'];

	 $stmt = $user_servicio->runQuery("SELECT * FROM cat_servicio WHERE nombre=:eNombre");
    $stmt->execute(array(":eNombre"=>$eNombre));
    $rowservicio = $stmt->fetch(PDO::FETCH_ASSOC);

    if($stmt->rowCount() > 0)
    {
        $msg = "
            <div class='alert alert-danger'>
                <button class='close' data-dismiss='alert'>&times;</button>
                <strong>Disculpe! </strong>este dato ya existe.
            </div>";
    }
    else{

    	  if($user_servicio->reg_cat_servicio($eNombre,$ePosicion,$eVisible))
		{
			$msg="<div class='alert alert-success'>
                <button class='close' data-dismiss='alert'>&times;</button>
                <span class='icon-smile icon-2x'></span> Los datos se <strong>guardaron</strong> correctamente
             	</div>";
		}
	  else
	  {
	  		$msg="<div class='alert alert-danger'>
                <button class='close' data-dismiss='alert'>&times;</button>
                 <span class='icon-frown icon-2x'></span><strong> Error</strong> al guardar los datos
             	</div>";
	  }
    }
}
?>
<?php include 'inc/header.php'; ?>
<section class="main container">
	<div class="row">
		<section class="col-md-5">	
			<div class="bs-callout"> <h4><i class="fa fa-bullhorn fa-2x"></i> Categoría servicio</h4></div>
			<div class="bs-callout">
				<?php if(isset($msg)) echo $msg; ?>
			    <form role="form" method="post" class="form-horizontal mitad">
				    <div class="form-group">
				      <label class="col-md-2 control-label">Nombre</label>
				      <div class="col-md-6">
				        <input class="form-control" type="text" name="txtnombre">
				      </div>
				    </div>
				    <div class="form-group">
				      <label class="col-md-2 control-label">Posición</label>
				      <div class="col-md-3">
				        <input class="form-control" type="text" name="txtposicion">
				      </div>
				    </div>
					<div class="form-group">
					      <label class="col-md-2 control-label">Visible</label>
					      <div class="col-md-10">
					        <div class="radio">
					          <label>
					            <input name="radiovisible" value="1" checked="checked" type="radio">
					            Si
					          </label>
					        </div>
					        <div class="radio">
					          <label>
					            <input name="radiovisible" value="0" type="radio">
					            No
					          </label>
					        </div>
					      </div>
					</div>
				    <div class="form-group">
						<div class="col-md-6">
							<button type="submit" class="btn btn-success btn-block" name="btn_nuevo_servicio"><span class="icon-save"></span> Guardar</button>
						</div>

						<div class="col-md-6">
						<a href="panel.php" class="btn btn-warning btn-block" name="btn-pass"><span class="icon-stop"></span> Cancelar</a>
						</div>
					</div>
				</form>
			</div>
		</section>
		<section class="col-md-7">
			<div class="panel panel-default">
			  	<div class="panel-body">
				   <div class="table-responsive">
					   <table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
					  <thead>
					    <tr>
					      <th>Id</th>
					      <th>Nombre</th>
					      <th>Pos</th>
					      <th>Visible</th>
					      <th>Editar</th>
					      <th>Eliminar</th>
					    </tr>
					  </thead>
						  <tbody>
						  <?php 
							$stmt = $user_servicio->runQuery("SELECT * FROM cat_servicio ORDER BY posicion ASC");
							$stmt->execute();
							while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
							{
						   ?>
						    <tr>
						      <td><?php echo $row['idcat_servicio']; ?></td>
						      <td><?php echo $row['nombre']; ?></td>
						      <td><?php echo $row['posicion']; ?></td>
						      <td><?php echo $row['visible']; ?></td>
						      
							  <td>
				 				<a href="editar-cat-servicio.php?editar_id=<?php print($row['idcat_servicio']); ?>" class="btn btn-primary btn-block" ><span class="icon-edit"></span> Editar</a>
						      	</td>
							   <td aling="center">
							      <a href="eliminar-cat-servicio.php?delete_id=<?php print($row['idcat_servicio']); ?>" class="btn btn-danger btn-block" ><span class="icon-remove-sign"></span> Eliminar</a>
							   </td>
						    </tr>
						    <?php 
							}
						     ?>
						  </tbody>
						</table>
					</div>
			  	</div>
			</div>
		</section>
	</div>
</section>
<?php include 'inc/footer.php'; ?>