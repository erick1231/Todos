<?php 
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('index.php');
}
$stmt = $user_ads->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC); ?>

<?php
$get_idaviso_comp = $_GET['idaviso_compra'];			
$stmt = $user_ads->runQuery("SELECT * FROM aviso_compra WHERE idaviso_compra='$get_idaviso_comp'");
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

	if($row['visible']=='si') 
	{
		$sql = 'UPDATE aviso_compra SET visible=?
		WHERE idaviso_compra=?';
		$this_status = "no";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idaviso_comp));
		header("location: av-compra.php");
	}
	else
	{
		$sql = 'UPDATE aviso_compra SET visible=?
		WHERE idaviso_compra=?';
		$this_status = "si";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idaviso_comp));
		header("location: av-compra.php");
	} 
?>