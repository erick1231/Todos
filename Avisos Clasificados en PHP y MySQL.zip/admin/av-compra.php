<?php 
session_start();
require_once 'include/class.user.php';
$user_empleo = new USER();
if(!$user_empleo->is_logged_in())
{
  $user_empleo->redirect('index.php');
}
$stmt = $user_empleo->runQuery("SELECT * FROM centraluser WHERE userID=:uid LIMIT 1");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<?php include 'inc/header.php'; ?>
<section class="main container">
	<div class="row">
		<section class="col-md-12">
			<div class="bs-callout">
			<?php  
				$stmt = $user_empleo->runQuery("SELECT idaviso_compra, COUNT(*) 
												FROM aviso_compra");
				$stmt->execute();
				$row=$stmt->fetch(PDO::FETCH_ASSOC);
				$contar = $row['COUNT(*)'];
			?> 
				<h4><i class="fa fa-cart-arrow-down fa-2x"></i> Avisos clasificados de <strong>compra</strong>
					<span class="badge"><?php echo $contar; ?>
				</span>
				</h4>
			</div>
			<div class="panel panel-default">
			  	<div class="panel-body">
			  		<div class="table-responsive">
					   <table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
						  <thead>
						    <tr>
						      <th>id</th>
						      <th>Nombre</th>
						      <th>Ciudad</th>
						      <th>id comp</th>
						      <th>Compra</th>
						      <th>Título</th>
						      <th>Descripción</th>
						      <th style="color: #425F9B;">Fecha_pub</th>
						      <th style="color: #51A351;">Aprobado</th>
						      <th style="color: #D9534F;">Eliminar</th>
						      <th style="color: #31B0D5;">Acceso</th>
						    </tr>
						  </thead>
							  <tbody>
							  <?php 
								$stmt = $user_empleo->runQuery("SELECT usuarios.userID,usuarios.userNombre,usuarios.userAcceso,cat_ciudad.ciudad,cat_compra.idcat_compra
									 ,cat_compra.nombre,idaviso_compra,
									 titulo,descripcion,fecha_pub, aviso_compra.visible
									 FROM aviso_compra
									 
									INNER JOIN usuarios
									ON aviso_compra.id_usuario=usuarios.userID
									INNER JOIN cat_ciudad
									ON aviso_compra.id_ciudad=cat_ciudad.idCiudad
									INNER JOIN cat_compra
									ON aviso_compra.id_cat_compra=cat_compra.idcat_compra 
									ORDER BY fecha_pub DESC");
								$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
								while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
								{
							   ?>
							    <tr>
							      <td><?php echo $row['userID']; ?></td>
							      <td><?php echo $row['userNombre']; ?></td>
							      <td><?php echo $row['ciudad']; ?></td>
							      <td><?php echo $row['idcat_compra']; ?></td>
							      <td><?php echo $row['nombre']; ?></td>
							      <td><?php echo $row['titulo']; ?></td>
							      <td><?php echo $row['descripcion']; ?></td>
							      <td><?php echo $row['fecha_pub']; ?></td>
							      <script type="text/javascript">
							      	$('#example').datatable({responsive: true});
							      </script>
							       <?php if ($row['visible']=='si'): ?>
						      			<?php 
						      			echo "<td><a href='autorizar-aviso-compra.php?idaviso_compra=$row[idaviso_compra]'
									      			class='btn btn-success btn-block'>
													<span class='fa fa-check'></span>
						      							</a>
						      						</td>"; ?>
						      		<?php else:{
						      				echo "<td>
						      						<a href='autorizar-aviso-compra.php?idaviso_compra=$row[idaviso_compra]'
									      				class='btn btn-warning btn-block'>
														<span class='fa fa-stop-circle'></span>
						      						</a>
						      					</td>";
						      				} ?>
						      			
						      		<?php endif ?>
								   <td aling="center">
								      <a href="de-compra.php?delete_id_compra=<?php print($row['idaviso_compra']); ?>" class="btn btn-danger btn-block" ><span class="icon-remove-sign"></span> Eliminar</a>
								   </td>
								    <?php if ($row['userAcceso']=='Y'): ?>
						      			<?php 
						      			echo "<td>
							      				<a href='updatestatus.php?iduno=$row[userID]'
										      			class='btn btn-info btn-block'>
													<span class='fa fa-check'></span>
							      				</a>
						      				</td>"; ?>
									<?php else:{
						      		echo "<td>
						      				<a href='updatestatus.php?iduno=$row[userID]'
									      	class='btn btn-warning btn-block'>
											<span class='fa fa-lock'></span>
						      				</a>
						      			</td>";
						      			} ?>
									<?php endif ?>
							    </tr>
							    <?php 
								}
							     ?>
							  </tbody>
					   </table>
					</div>
			  	</div>
			</div>
		</section>
	</div>
</section>
<?php include 'inc/footer.php'; ?>