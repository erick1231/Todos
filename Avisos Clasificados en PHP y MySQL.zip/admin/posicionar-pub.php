<?php 
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('index.php');
}
$stmt = $user_ads->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<?php
$get_idpub = $_GET['idpublicidad'];			
$stmt = $user_ads->runQuery("SELECT * FROM publicidad WHERE idpub='$get_idpub'");
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);


	if($row['posicion']=='3') 
	{
		$sql = 'UPDATE publicidad SET posicion=?
		WHERE idpub=?';
		$this_status = "1";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idpub));
		header("location: pub.php");
	}
	elseif($row['posicion']=='2') 
	{
		$sql = 'UPDATE publicidad SET posicion=?
		WHERE idpub=?';
		$this_status = "3";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idpub));
		header("location: pub.php");
	}

	elseif($row['posicion']=='1') 

	{
		$sql = 'UPDATE publicidad SET posicion=?
		WHERE idpub=?';
		$this_status = "2";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idpub));
		header("location: pub.php");
	
	}
?>
