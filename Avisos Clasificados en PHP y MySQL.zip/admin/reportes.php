<?php 
session_start();
require_once 'include/class.user.php';
$user_report = new USER();
if(!$user_report->is_logged_in())
{
  $user_report->redirect('index.php');
}
$stmt = $user_report->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<?php
if(isset($_POST['eliminar_reporte_empleo']))
{
	$idemp = $_POST['idempleo'];
	if($user_report->del_rep_emp($idemp))
		{
			$msg = "<div class='alert alert-success'>
                	<button class='close' data-dismiss='alert'>&times;</button>
                	<span class='fa fa-smile-o fa-2x'></span><strong> El reporte se eliminó correctamente.</strong>
             		</div>";
		}
		else
		{
			$msg = "<div class='alert alert-danger'>
                	<button class='close' data-dismiss='alert'>&times;</button>
                	<span class='fa fa-frown-o fa-2x'></span><strong> Ups!</strong> hubo un problema al eliminar el reporte.
             		</div>";
		}
}
?>

<?php
if(isset($_POST['eliminar_reporte_venta']))
{
	$idvent = $_POST['idventa'];
	if($user_report->del_rep_vent($idvent))
		{
			$msg = "<div class='alert alert-success'>
                	<button class='close' data-dismiss='alert'>&times;</button>
                	<span class='fa fa-smile-o fa-2x'></span><strong> El reporte se eliminó correctamente.</strong>
             		</div>";
		}
		else
		{
			$msg = "<div class='alert alert-danger'>
                	<button class='close' data-dismiss='alert'>&times;</button>
                	<span class='fa fa-frown-o fa-2x'></span><strong> Ups!</strong> hubo un problema al eliminar el reporte.
             		</div>";
		}
}
?>
<?php
if(isset($_POST['eliminar_reporte_serv']))
{
	$idserv = $_POST['idserv'];
	if($user_report->del_rep_serv($idserv))
		{
			$msg = "<div class='alert alert-success'>
                	<button class='close' data-dismiss='alert'>&times;</button>
                	<span class='fa fa-smile-o fa-2x'></span><strong> El reporte se eliminó correctamente.</strong>
             		</div>";
		}
		else
		{
			$msg = "<div class='alert alert-danger'>
                	<button class='close' data-dismiss='alert'>&times;</button>
                	<span class='fa fa-frown-o fa-2x'></span><strong> Ups!</strong> hubo un problema al eliminar el reporte.
             		</div>";
		}
}
?>
<?php
if(isset($_POST['eliminar_reporte_com']))
{
	$idcom = $_POST['idcom'];
	if($user_report->del_rep_com($idcom))
		{
			$msg = "<div class='alert alert-success'>
                	<button class='close' data-dismiss='alert'>&times;</button>
                	<span class='fa fa-smile-o fa-2x'></span><strong> El reporte se eliminó correctamente.</strong>
             		</div>";
		}
		else
		{
			$msg = "<div class='alert alert-danger'>
                	<button class='close' data-dismiss='alert'>&times;</button>
                	<span class='fa fa-frown-o fa-2x'></span><strong> Ups!</strong> hubo un problema al eliminar el reporte.
             		</div>";
		}
}
?>

<?php include 'inc/header.php'; ?>
<section class="main container">
	<div class="row">
		<section class="col-md-12">
			<div class="bs-callout"> 
			<!-- <php  
				$stmt = $user_report->runQuery("SELECT idreporte_emp, COUNT(*) FROM reportes_empleo");
				$stmt->execute();
				$row=$stmt->fetch(PDO::FETCH_ASSOC);
				$contar = $row['COUNT(*)'];
			?> -->
				<h4><i class="fa fa-bell-o fa-2x"></i><strong> Reportes - empleo</strong>
					<!-- <span class="badge"><?php echo $contar; ?></span> -->
				</h4>
			</div>
			<?php if(isset($msg)){ echo $msg;} ?>
			<div class="panel panel-default">
			  	<div class="panel-body">
			  		<div class="table-responsive">
					   <table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
						  <thead>
						    <tr>
						      <th>Id</th>
						      <th>Id aviso</th>
						      <th>Permiso</th>
						      <th>Usuario</th>
						      <th>Título</th>
						      <th>Publicación</th>
						      <th>Motivo</th>
						      <th>Fecha de reporte</th>
						      <th>Eliminar reporte</th>
						      <th>Eliminar aviso</th>
						      <th>Bloquear</th>

						    </tr>
						  </thead>
							  <tbody>
							  <?php 
								$stmt = $user_report->runQuery("SELECT reportes_empleo.idreporte_emp,
										usuarios.userID,
										aviso_empleo.idaviso_empleo, 
										usuarios.userAcceso,
										usuarios.userNombre,
										aviso_empleo.titulo,
										aviso_empleo.descripcion, 
										reportes_empleo.motivo,
										reportes_empleo.fecha_pub 
										FROM reportes_empleo

										INNER JOIN usuarios
										ON reportes_empleo.id_usuario=usuarios.userID

										INNER JOIN aviso_empleo
										ON reportes_empleo.id_aviso=aviso_empleo.idaviso_empleo 

										ORDER BY idreporte_emp 
										DESC");

								$stmt->execute();
								while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
								{
							   ?>
							    <tr>
							
							      <td><?php echo $row['userID']; ?></td>
							      <td><?php echo $row['idaviso_empleo']; ?></td>
							      <td><?php echo $row['userAcceso']; ?></td>
							      <td><?php echo $row['userNombre']; ?></td>
							      <td><?php echo $row['titulo']; ?></td>
							      <td><?php echo $row['descripcion']; ?></td>
							      <td><?php echo $row['motivo']; ?></td>
							      <td><?php echo $row['fecha_pub']; ?></td>

								   	<td aling="center">
								      	<button data-toggle="modal" 
					 					data-target="#<?php echo $row['idreporte_emp'];?>" class="btn clas btn-danger btn-block" >
					 					<span class="fa fa-file"></span>
					 					</button>
								   	</td>
								   	<td aling="center">
								      	<a href="de-empleo.php?delete_id_emp=<?php print($row['idaviso_empleo']); ?>" class="btn btn-danger btn-block" ><span class="fa fa-trash"></span></a>
								   	</td>
								    <td>
							   			<a href="updatestatus.php?iduno=<?php print($row['userID']); ?>" class="btn btn-warning btn-block" ><span class="fa fa-lock"></span></a>
						      		</td>

							    </tr>

			<div class="modal fade" id="<?php echo $row['idreporte_emp'];?>" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          			<div class="modal-dialog modal-sm">
            			<div class="modal-content">
              				<div class="modal-header">
                				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                				<h4 class="modal-title" id="myModalLabel">Eliminar reporte</h4>
                				
              				</div>
              			<div class="modal-body">
				 			<form method="post" action="">
                   				<div class="alert alert-dismissible alert-info">
						  			<i class="fa fa-file"></i><strong> ¿Esta seguro de eliminar este reporte?</strong>
								</div>
								<div class="form-group" hidden="true">
			           				<div class="col-md-1">
							  			<input class="form-control" type="text" name="idempleo" value="<?php echo $row['idreporte_emp'];?>">
							  		</div>
							  	</div>
              			</div>
              				<div class="modal-footer">
                				<button class="btn btn-block btn-success btn-md" name="eliminar_reporte_empleo"><i class="fa fa-check-square"></i> Si
                				</button>
				 				<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> No
				 				</button>
							</form>
              				</div>
            			</div>
          			</div>
        		</div>

							    <?php 
								}
							     ?>
							  </tbody>
					   </table>
					</div>
			  	</div>
			</div>

			<div class="bs-callout"> 
				<h4><i class="fa fa-bell-o fa-2x"></i><strong> Reportes venta</strong>
				</h4>
			</div>
			<div class="panel panel-default">
			  	<div class="panel-body">
			  		<div class="table-responsive">
					   <table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
						  <thead>
						    <tr>
						      <th>Id</th>
						      <th>Id</th>
						      <th>Permiso</th>
						      <th>Usuario</th>
						      <th>Título</th>
						      <th>Publicación</th>
						      <th>Foto</th>
						      <th>Motivo</th>
						      <th>Fecha de reporte</th>
						      <th>Eliminar reporte</th>
						      <th>Eliminar aviso</th>
						      <th>Bloquear</th>
						    </tr>
						  </thead>
							  <tbody>
							  <?php 
								$stmt = $user_report->runQuery("SELECT reportes_venta.idreporte_vent,
										usuarios.userID,
										aviso_venta.idaviso_venta, 
										usuarios.userAcceso,
										usuarios.userNombre,
										aviso_venta.titulo,
										aviso_venta.descripcion,
										aviso_venta.foto, 
										reportes_venta.motivo,
										reportes_venta.fecha_pub 
										FROM reportes_venta

										INNER JOIN usuarios
										ON reportes_venta.id_usuario=usuarios.userID

										INNER JOIN aviso_venta
										ON reportes_venta.id_aviso=aviso_venta.idaviso_venta 

										ORDER BY idreporte_vent
										DESC");
								$stmt->execute();
								while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
								{
							   ?>
							    <tr>
							
							      <td><?php echo $row['userID']; ?></td>
							      <td><?php echo $row['idaviso_venta']; ?></td>
							      <td><?php echo $row['userAcceso']; ?></td>
							      <td><?php echo $row['userNombre']; ?></td>
							      <td><?php echo $row['titulo']; ?></td>
							      <td><?php echo $row['descripcion']; ?></td>
							      <td>
							      <img src="../media/fotos_images4/<?php echo $row['foto']; ?>" style='width:64px; height:64px'>
							      </td>
							      <td><?php echo $row['motivo']; ?></td>
							      <td><?php echo $row['fecha_pub']; ?></td>

								   	<td aling="center">
								      	<button data-toggle="modal" 
					 					data-target="#<?php echo $row['idreporte_vent'];?>" class="btn clas btn-danger btn-block" >
					 					<span class="fa fa-file"></span>
					 					</button>
								   	</td>
								   	<td aling="center">
								      	<a href="de-venta.php?delete_id_vent=<?php print($row['idaviso_venta']); ?>" class="btn btn-danger btn-block" ><span class="fa fa-trash"></span></a>
								   	</td>
								    <td>
							   			<a href="updatestatus.php?iduno=<?php print($row['userID']); ?>" class="btn btn-warning btn-block" ><span class="fa fa-lock"></span></a>
						      		</td>
							    </tr>

			<div class="modal fade" id="<?php echo $row['idreporte_vent'];?>" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          			<div class="modal-dialog modal-sm">
            			<div class="modal-content">
              				<div class="modal-header">
                				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                				<h4 class="modal-title" id="myModalLabel">Eliminar reporte</h4>
                				
              				</div>
              			<div class="modal-body">
				 			<form method="post" action="">
                   				<div class="alert alert-dismissible alert-info">
						  			<i class="fa fa-file"></i><strong> ¿Esta seguro de eliminar este reporte?</strong>
								</div>
								<div class="form-group" hidden="true">
			           				<div class="col-md-1">
							  			<input class="form-control" type="text" name="idventa" value="<?php echo $row['idreporte_vent'];?>">
							  		</div>
							  	</div>
              			</div>
              				<div class="modal-footer">
                				<button class="btn btn-block btn-success btn-md" name="eliminar_reporte_venta"><i class="fa fa-check-square"></i> Si
                				</button>
				 				<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> No
				 				</button>
							</form>
              				</div>
            			</div>
          			</div>
        		</div>
							    <?php 
									}
							    ?>
							  </tbody>
					   </table>
					</div>
			  	</div>
			</div>


			<div class="bs-callout"> 
				<h4><i class="fa fa-bell-o fa-2x"></i><strong> Reportes - Servicios</strong>
				</h4>
			</div>
			<div class="panel panel-default">
			  	<div class="panel-body">
			  		<div class="table-responsive">
					   <table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
						  <thead>
						    <tr>
						      <th>Id</th>
						      <th>Id</th>
						      <th>Permiso</th>
						      <th>Usuario</th>
						      <th>Título</th>
						      <th>Publicación</th>
						      <th>Motivo</th>
						      <th>Fecha de reporte</th>
						      <th>Eliminar reporte</th>
						      <th>Eliminar aviso</th>
						      <th>Bloquear</th>
						    </tr>
						  </thead>
							  <tbody>
				  		<?php 
								$stmt = $user_report->runQuery("SELECT reportes_servicio.idreporte_serv,
								usuarios.userID,
								aviso_servicio.idaviso_servicio, 
								usuarios.userAcceso, 
								usuarios.userNombre,
								aviso_servicio.titulo,
								aviso_servicio.descripcion, 
								reportes_servicio.motivo,
								reportes_servicio.fecha_pub 
								FROM reportes_servicio

								INNER JOIN usuarios
								ON reportes_servicio.id_usuario=usuarios.userID

								INNER JOIN aviso_servicio
								ON reportes_servicio.id_aviso=aviso_servicio.idaviso_servicio 

								ORDER BY idreporte_serv
								DESC");
																							
								$stmt->execute();
								while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
								{
							   ?>
							    <tr>
							
							      <td><?php echo $row['userID']; ?></td>
							      <td><?php echo $row['idaviso_servicio']; ?></td>
							      <td><?php echo $row['userAcceso']; ?></td>
							      <td><?php echo $row['userNombre']; ?></td>
							      <td><?php echo $row['titulo']; ?></td>
							      <td><?php echo $row['descripcion']; ?></td>
							      <td><?php echo $row['motivo']; ?></td>
							      <td><?php echo $row['fecha_pub']; ?></td>

								   <td aling="center">
								      	<button data-toggle="modal" 
					 					data-target="#<?php echo $row['idreporte_serv'];?>" class="btn clas btn-danger btn-block" >
					 					<span class="fa fa-file"></span>
					 					</button>
								   	</td>
								   	<td aling="center">
								      	<a href="de-servicio.php?delete_id_serv=<?php print($row['idaviso_servicio']); ?>" class="btn btn-danger btn-block" ><span class="fa fa-trash"></span></a>
								   	</td>
								    <td>
							   			<a href="updatestatus.php?iduno=<?php print($row['userID']); ?>" class="btn btn-warning btn-block" ><span class="fa fa-lock"></span></a>
						      		</td>
							    </tr>
			<div class="modal fade" id="<?php echo $row['idreporte_serv'];?>" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          			<div class="modal-dialog modal-sm">
            			<div class="modal-content">
              				<div class="modal-header">
                				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                				<h4 class="modal-title" id="myModalLabel">Eliminar reporte</h4>
                				
              				</div>
              			<div class="modal-body">
				 			<form method="post" action="">
                   				<div class="alert alert-dismissible alert-info">
						  			<i class="fa fa-file"></i><strong> ¿Esta seguro de eliminar este reporte?</strong>
								</div>
								<div class="form-group" hidden="true">
			           				<div class="col-md-1">
							  			<input class="form-control" type="text" name="idserv" value="<?php echo $row['idreporte_serv'];?>">
							  		</div>
							  	</div>
              			</div>
              				<div class="modal-footer">
                				<button class="btn btn-block btn-success btn-md" name="eliminar_reporte_serv"><i class="fa fa-check-square"></i> Si
                				</button>
				 				<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> No
				 				</button>
							</form>
              				</div>
            			</div>
          			</div>
        		</div>				    
							    <?php 
								}
							     ?>
							  </tbody>
					   </table>
					</div>
			  	</div>
			</div>

			<div class="bs-callout"> 
				<h4><i class="fa fa-bell-o fa-2x"></i><strong> Reportes - Compra</strong>
				</h4>
			</div>
			<div class="panel panel-default">
			  	<div class="panel-body">
			  		<div class="table-responsive">
					   <table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
						  <thead>
						    <tr>
						      <th>Id</th>
						      <th>Id</th>
						      <th>Permiso</th>
						      <th>Usuario</th>
						      <th>Título</th>
						      <th>Publicación</th>
						      <th>Motivo</th>
						      <th>Fecha de reporte</th>
						      <th>Eliminar reporte</th>
						      <th>Eliminar aviso</th>
						      <th>Bloquear</th>

						    </tr>
						  </thead>
							  <tbody>
							  <?php 
									$stmt = $user_report->runQuery("SELECT reportes_compra.idreporte_com,
									usuarios.userID,
									aviso_compra.idaviso_compra, 
									usuarios.userAcceso, 
									usuarios.userNombre,
									aviso_compra.titulo,
									aviso_compra.descripcion, 
									reportes_compra.motivo,
									reportes_compra.fecha_pub 
									FROM reportes_compra

									INNER JOIN usuarios
									ON reportes_compra.id_usuario=usuarios.userID

									INNER JOIN aviso_compra
									ON reportes_compra.id_aviso=aviso_compra.idaviso_compra 

									ORDER BY idreporte_com");
								$stmt->execute();
								while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
								{
							   ?>
							    <tr>
							      <td><?php echo $row['userID']; ?></td>
							      <td><?php echo $row['idaviso_compra']; ?></td>
							      <td><?php echo $row['userAcceso']; ?></td>
							      <td><?php echo $row['userNombre']; ?></td>
							      <td><?php echo $row['titulo']; ?></td>
							      <td><?php echo $row['descripcion']; ?></td>
							      <td><?php echo $row['motivo']; ?></td>
							      <td><?php echo $row['fecha_pub']; ?></td>

								   <td aling="center">
								      	<button data-toggle="modal" 
					 					data-target="#<?php echo $row['idreporte_com'];?>" class="btn clas btn-danger btn-block" >
					 					<span class="fa fa-file"></span>
					 					</button>
								   	</td>
								   	<td aling="center">
								      	<a href="de-compra.php?delete_id_compra=<?php print($row['idaviso_compra']); ?>" class="btn btn-danger btn-block" ><span class="fa fa-trash"></span></a>
								   	</td>
								    <td>
							   			<a href="updatestatus.php?iduno=<?php print($row['userID']); ?>" class="btn btn-warning btn-block" ><span class="fa fa-lock"></span></a>
						      		</td>
							    </tr>
			<div class="modal fade" id="<?php echo $row['idreporte_com'];?>" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          			<div class="modal-dialog modal-sm">
            			<div class="modal-content">
              				<div class="modal-header">
                				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                				<h4 class="modal-title" id="myModalLabel">Eliminar reporte</h4>
                				
              				</div>
              			<div class="modal-body">
				 			<form method="post" action="">
                   				<div class="alert alert-dismissible alert-info">
						  			<i class="fa fa-file"></i><strong> ¿Esta seguro de eliminar este reporte?</strong>
								</div>
								<div class="form-group" hidden="true">
			           				<div class="col-md-1">
							  			<input class="form-control" type="text" name="idcom" value="<?php echo $row['idreporte_com'];?>">
							  		</div>
							  	</div>
              			</div>
              				<div class="modal-footer">
                				<button class="btn btn-block btn-success btn-md" name="eliminar_reporte_com"><i class="fa fa-check-square"></i> Si
                				</button>
				 				<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> No
				 				</button>
							</form>
              				</div>
            			</div>
          			</div>
        		</div>
							    <?php 
								}
							     ?>
							  </tbody>
					   </table>
					</div>
			  	</div>
			</div>
		</section>
	</div>
</section>
<?php include 'inc/footer.php'; ?>
