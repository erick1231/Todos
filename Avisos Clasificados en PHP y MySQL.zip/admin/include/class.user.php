<?php
/**
 * file: class.user.php
 * @author anthoncode
 * @link https://anthoncode.com
 */
require_once '../admin/config/config.php';

class USER
{
	private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbconnection();
		$this->conn = $db;
		if (!$database->dbConnection()) {
    	header('location:../error-tecnico.html');
		}
	}

	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}

	public function lasdID()
	{
		$stmt = $this->conn->lastInsertID();
		return $stmt;
	}
	public function register($unombre,$email,$tele,$upass,$code)
	{
		try
		{
			$pass_cif =password_hash($upass, PASSWORD_DEFAULT); 
			$contra =$pass_cif;
			$stmt = $this->conn->prepare("INSERT INTO centraluser(userNombre,userEmailA,userTelefono,userContra,codeAct)
														VALUES(:user_nombre, :user_email,
														:user_telefono, :user_contra, :code_Act)");
			$stmt->bindparam(":user_nombre",$unombre);
			$stmt->bindparam(":user_email",$email);
			$stmt->bindparam(":user_telefono",$tele);
			$stmt->bindparam(":user_contra",$contra);
			$stmt->bindparam(":code_Act",$code);
			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	}
	public function getID($id)
	{
		$stmt = $this->conn->prepare("SELECT * FROM centraluser WHERE userID=:id");
		$stmt->execute(array(":id"=>$id));
		$editRow=$stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	}
	/*cat_empleo*/
	public function reg_cat_empleo($eNombre,$ePosicion,$eVisible)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO cat_empleo(nombre,posicion,visible) VALUES(:eNombre, :ePosicion, :eVisible)");
			$stmt->bindparam(":eNombre",$eNombre);
			$stmt->bindparam(":ePosicion",$ePosicion);
			$stmt->bindparam(":eVisible",$eVisible);
			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	}
	public function delete_empleo($id)
	{
	$stmt = $this->conn->prepare("DELETE FROM cat_empleo WHERE idcat_empleo=:id");
	$stmt->bindparam(":id",$id);
	$stmt->execute();
	return true;
	}

	public function editar_empleo($id,$enombre,$eposicion,$eVisible)
	{
		try
		{
			
		$stmt = $this->conn->prepare("UPDATE cat_empleo SET nombre=:enombre, posicion=:eposicion, visible=:eVisible WHERE idcat_empleo=:id");
		$stmt->bindparam(":enombre" ,$enombre);
		$stmt->bindparam(":eposicion" ,$eposicion);
		$stmt->bindparam(":eVisible" ,$eVisible);
		$stmt->bindparam(":id" ,$id);
		$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}

	public function getIDempleo($id)
	{
		$stmt = $this->conn->prepare("SELECT * FROM cat_empleo WHERE idcat_empleo=:id");
		$stmt->execute(array(":id"=>$id));
		$editRow=$stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	}
	/*fin empleo*/

	/*cat_venta*/
	public function reg_cat_venta($eNombre,$ePosicion,$eVisible)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO cat_venta (nombre,posicion,visible) VALUES(:eNombre, :ePosicion, :eVisible)");
			$stmt->bindparam(":eNombre",$eNombre);
			$stmt->bindparam(":ePosicion",$ePosicion);
			$stmt->bindparam(":eVisible",$eVisible);
			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	}
		
	public function editar_venta($id,$enombre,$eposicion,$eVisible)
	{
		try
		{
			
		$stmt = $this->conn->prepare("UPDATE cat_venta SET nombre=:enombre, posicion=:eposicion, visible=:eVisible WHERE idcat_venta=:id");
		$stmt->bindparam(":enombre" ,$enombre);
		$stmt->bindparam(":eposicion" ,$eposicion);
		$stmt->bindparam(":eVisible" ,$eVisible);
		$stmt->bindparam(":id" ,$id);
		$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}

	public function getIDventa($id)
	{
		$stmt = $this->conn->prepare("SELECT * FROM cat_venta WHERE idcat_venta=:id");
		$stmt->execute(array(":id"=>$id));
		$editRow=$stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	}
	public function delete_venta($id)
	{
	$stmt = $this->conn->prepare("DELETE FROM cat_venta WHERE idcat_venta=:id");
	$stmt->bindparam(":id",$id);
	$stmt->execute();
	return true;
	}
	/*fin venta*/

	/*cat_compra*/
	public function reg_cat_compra($eNombre,$ePosicion,$eVisible)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO cat_compra(nombre,posicion,visible) VALUES(:eNombre, :ePosicion, :eVisible)");
			$stmt->bindparam(":eNombre",$eNombre);
			$stmt->bindparam(":ePosicion",$ePosicion);
			$stmt->bindparam(":eVisible",$eVisible);
			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	}
	public function delete_compra($id)
	{
	$stmt = $this->conn->prepare("DELETE FROM cat_compra WHERE idcat_compra=:id");
	$stmt->bindparam(":id",$id);
	$stmt->execute();
	return true;
	}

	public function editar_compra($id,$enombre,$eposicion,$eVisible)
	{
		try
		{
			
		$stmt = $this->conn->prepare("UPDATE cat_compra SET nombre=:enombre, posicion=:eposicion, visible=:eVisible WHERE idcat_compra=:id");
		$stmt->bindparam(":enombre" ,$enombre);
		$stmt->bindparam(":eposicion" ,$eposicion);
		$stmt->bindparam(":eVisible" ,$eVisible);
		$stmt->bindparam(":id" ,$id);
		$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}

	public function getIDcompra($id)
	{
		$stmt = $this->conn->prepare("SELECT * FROM cat_compra WHERE idcat_compra=:id");
		$stmt->execute(array(":id"=>$id));
		$editRow=$stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	}
	/*fin compra*/

	/*cat_servicio*/
	public function reg_cat_servicio($eNombre,$ePosicion,$eVisible)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO cat_servicio(nombre,posicion,visible) VALUES(:eNombre, :ePosicion, :eVisible)");
			$stmt->bindparam(":eNombre",$eNombre);
			$stmt->bindparam(":ePosicion",$ePosicion);
			$stmt->bindparam(":eVisible",$eVisible);
			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	}
	public function delete_servicio($id)
	{
	$stmt = $this->conn->prepare("DELETE FROM cat_servicio WHERE idcat_servicio=:id");
	$stmt->bindparam(":id",$id);
	$stmt->execute();
	return true;
	}

	public function editar_servicio($id,$enombre,$eposicion,$eVisible)
	{
		try
		{
			
		$stmt = $this->conn->prepare("UPDATE cat_servicio SET nombre=:enombre, posicion=:eposicion, visible=:eVisible WHERE idcat_servicio=:id");
		$stmt->bindparam(":enombre" ,$enombre);
		$stmt->bindparam(":eposicion" ,$eposicion);
		$stmt->bindparam(":eVisible" ,$eVisible);
		$stmt->bindparam(":id" ,$id);
		$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}

	public function getIDservicio($id)
	{
		$stmt = $this->conn->prepare("SELECT * FROM cat_servicio WHERE idcat_servicio=:id");
		$stmt->execute(array(":id"=>$id));
		$editRow=$stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	}
	/*fin servicio*/


	public function uppass($id,$upassword)
	{
		try
		{
			$Upass_cif = password_hash($upassword, PASSWORD_DEFAULT); 
			$Ucontra = $Upass_cif;
			$stmt = $this->conn->prepare("UPDATE centraluser SET userContra=:Ucontra 
											WHERE userID=:id");
		$stmt->bindparam(":Ucontra",$Ucontra);
		$stmt->bindparam(":id",$id);
		$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}

	public function delete($id)
	{
		$stmt = $this->conn->prepare("DELETE FROM usuarios WHERE userID=:id");
		$stmt->bindparam(":id",$id);
		$stmt->execute();
		return true;
	}

	//borrar aviso venta
	public function delete_aviso_vent($id)
	{
	$stmt = $this->conn->prepare("DELETE FROM aviso_venta WHERE idaviso_venta=:id");
	$stmt->bindparam(":id",$id);
	$stmt->execute();
	return true;
	}
	//borrar aviso empleo
	public function delete_aviso_emp($id)
	{
	$stmt = $this->conn->prepare("DELETE FROM aviso_empleo WHERE idaviso_empleo=:id");
	$stmt->bindparam(":id",$id);
	$stmt->execute();
	return true;
	}
	//borrar aviso servicio
	public function delete_aviso_serv($id)
	{
	$stmt = $this->conn->prepare("DELETE FROM aviso_servicio WHERE idaviso_servicio=:id");
	$stmt->bindparam(":id",$id);
	$stmt->execute();
	return true;
	}
	//borrar aviso compra
	public function delete_aviso_comp($id)
	{
	$stmt = $this->conn->prepare("DELETE FROM aviso_compra WHERE idaviso_compra=:id");
	$stmt->bindparam(":id",$id);
	$stmt->execute();
	return true;
	}

	public function limpiarCorreo($dat_correo){
		$dat_correo = filter_var($dat_correo, FILTER_SANITIZE_EMAIL);
		return $dat_correo;
	}
	/*public function id_limpio($id){
		return (int)($id);
	}*/

	public function del_rep_emp($idemp){
		$stmt = $this->conn->prepare("DELETE FROM reportes_empleo WHERE idreporte_emp=:idemp");
		$stmt->bindparam(":idemp",$idemp);
		$stmt->execute();
		return true;
	}
	public function del_rep_vent($idvent){
		$stmt = $this->conn->prepare("DELETE FROM reportes_venta WHERE idreporte_vent=:idvent");
		$stmt->bindparam(":idvent",$idvent);
		$stmt->execute();
		return true;
	}
	public function del_rep_serv($idserv){
		$stmt = $this->conn->prepare("DELETE FROM reportes_servicio WHERE idreporte_serv=:idserv");
		$stmt->bindparam(":idserv",$idserv);
		$stmt->execute();
		return true;
	}
	public function del_rep_com($idcom){
		$stmt = $this->conn->prepare("DELETE FROM reportes_compra WHERE idreporte_com=:idcom");
		$stmt->bindparam(":idcom",$idcom);
		$stmt->execute();
		return true;
	}

	public function limpiarDatos($datos){
		$datos = filter_var($datos, FILTER_SANITIZE_STRING); //elimina etiquetas html
		$datos = trim($datos); //elimina espacios vacios
		$datos = htmlentities($datos,ENT_QUOTES,"UTF-8"); //caracteres latinos
		return $datos;
	}

	/*publicidad*/
	public function subir_pro_video($url,$eDescripcion,$visible,$posicion,$eFecha_pub)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO video_url(url,descripcion,
														visible,posicion,
														fecha_pub)
														VALUES (:url, :eDescripcion,
														 :visible, :posicion, :eFecha_pub)");
			$stmt->bindparam(":url",$url);
			$stmt->bindparam(":eDescripcion",$eDescripcion);
			$stmt->bindparam(":visible",$visible);			
			$stmt->bindparam(":posicion",$posicion);
			$stmt->bindparam(":eFecha_pub",$eFecha_pub);

			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	} 
	public function del_video($idvideo)
	{
	$stmt = $this->conn->prepare("DELETE FROM video_url WHERE idvideo_url=:idvideo");
	$stmt->bindparam(":idvideo",$idvideo);
	$stmt->execute();
	return true;
	}

	public function del_publi($idpubli)
	{
	$stmt = $this->conn->prepare("DELETE FROM publicidad WHERE idpub=:idpubli");
	$stmt->bindparam(":idpubli",$idpubli);
	$stmt->execute();
	return true;
	}
	public function act_codigo($id,$a_semana,$a_mes)
	{
		try
		{
			
		$stmt = $this->conn->prepare("UPDATE codigos SET codigo_semana=:a_semana, codigo_mes=:a_mes 
			WHERE idcodigo=:id");
		$stmt->bindparam(":a_semana" ,$a_semana);
		$stmt->bindparam(":a_mes" ,$a_mes);
		$stmt->bindparam(":id" ,$id);
		$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}
	public function id_act_codigo($id)
	{
		$stmt = $this->conn->prepare("SELECT * FROM codigos WHERE idcodigo=:id");
		$stmt->execute(array(":id"=>$id));
		$editRow=$stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	}

	public function act_mensaje($id,$mensaje)
	{
		try
		{
			
		$stmt = $this->conn->prepare("UPDATE mensaje SET mensaje=:mensaje WHERE idmensaje=:id");
		$stmt->bindparam(":mensaje" ,$mensaje);
		$stmt->bindparam(":id" ,$id);
		$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}
	public function id_act_mensaje($id)
	{
		$stmt = $this->conn->prepare("SELECT * FROM mensaje WHERE idmensaje=:id");
		$stmt->execute(array(":id"=>$id));
		$editRow=$stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	}

	public function normaliza_date_time($fecha_conv)
	{
		if(!empty($fecha_conv)){
			$test=$fecha_conv;
			echo date('d/m/Y H:i:s',strtotime($test));
		}
	}


	public function login($email,$upass)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT * FROM centraluser WHERE userEmailA=:email_id");
			$stmt->execute(array(":email_id"=>$email));
			$userRow=$stmt->fetch(PDO::FETCH_ASSOC);

			if($stmt->rowCount() == 1)
			{
				if($userRow['userEstado']=="Y")
				{
					if(password_verify($upass, $userRow['userContra']))
					{
						$_SESSION['userSessionA'] = $userRow['userID'];
						return true;
					}
					else
					{
						header("location: index.php?error");
						exit;
					}
				}
			else
			{
				header("location: index.php?inactive");
				exit;
			}
		}
		else
		{
			header("location: index.php?error");
			exit;
		}
	}
	catch(PDOException $ex)
	{
		echo $ex->getMessage();
	}
}
	public function is_logged_in()
	{
		if(isset($_SESSION['userSessionA']))
		{
			return true;
		}
	}

	public function redirect($url)
	{
		header("location: $url");
	}

	public function logout()
	{
		session_destroy();
		$_SESSION['userSessionA'] = false;
	}

	function send_mail($email,$message,$subject)
	{
	require_once('mailer/class.phpmailer.php');
		$mail = new PHPMailer();
		$mail->IsSMTP(); 
		$mail->SMTPDebug  = 0;                     
		$mail->SMTPAuth   = true;                  
		$mail->SMTPSecure = "ssl";                 
		$mail->Host       = "smtp.gmail.com";      
		$mail->Port       = 465;             
		$mail->AddAddress($email);
		$mail->Username = "beetleten@gmail.com";  
		$mail->Password = "unicosfile10";            
		$mail->SetFrom('beetleten@gmail.com','Coding Cage');
		$mail->AddReplyTo("your_gmail_id_here@gmail.com","Coding Cage");
		$mail->Subject    = $subject;
		$mail->MsgHTML($message);
		$mail->Send();

	}
}



?>
