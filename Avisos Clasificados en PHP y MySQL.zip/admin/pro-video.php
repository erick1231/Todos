<?php
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('login.php');
}
$stmt = $user_ads->runQuery("SELECT * FROM centraluser WHERE userID=:uid LIMIT 1");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<?php 
if (isset($_POST['btn_nuevo_video']))
{	
	$var_visible = 'no';
	$posicion = '1';
	$url = $_POST['txturl'];
	$eDescripcion = $user_ads->limpiarDatos($_POST['txtdesc']);
	$visible = $var_visible;
	$posicion = $posicion;
	$eFecha_pub = date('Y-m-d H:i:s');
	
	if (empty($url && $eDescripcion)) {
		$errorMSG = "Olvidaste un dato.";
    }
    else{

	$stmt = $user_ads->runQuery("SELECT * FROM video_url WHERE url=:url");
    $stmt->execute(array(":url"=>$url));
    $rowpublicidad = $stmt->fetch(PDO::FETCH_ASSOC);

	    if($stmt->rowCount() > 0)
	    {
	        $msg = "
	            <div class='alert alert-danger'>
	                <button class='close' data-dismiss='alert'>&times;</button>
	                <strong>Esta URL ya se subió.</strong>
	            </div>";
	    }
	    else{

	    	  if($user_ads->subir_pro_video($url,$eDescripcion,$visible,$posicion,$eFecha_pub))
			{
				$msg = "<div class='alert alert-success'>
		                <button class='close' data-dismiss='alert'>&times;</button>
		                <span class='fa fa-smile-o fa-2x'></span> El video se subio correctamente.
		             	</div>";
			}
		  else
		  	{
		  		$msg = "<div class='alert alert-danger'>
		                <button class='close' data-dismiss='alert'>&times;</button>
		                 <span class='fa fa-frown-o fa-2x'></span><strong> Ups!</strong> hubo un problema al enviar tus datos.
		             	</div>";
		  	}
	    }
	}
}
?>

<?php
if(isset($_POST['btn_eliminar_video']))
{
	$idvideo = $_POST['txtidvideo'];
	if($user_ads->del_video($idvideo))
		{
			$msg = "<div class='alert alert-success'>
                	<button class='close' data-dismiss='alert'>&times;</button>
                	<span class='fa fa-smile-o fa-2x'></span><strong> La dirección URL se eliminó correctamente.</strong>
             		</div>";
		}
		else
		{
			$msg = "<div class='alert alert-danger'>
                	<button class='close' data-dismiss='alert'>&times;</button>
                	<span class='fa fa-frown-o fa-2x'></span><strong> Ups!</strong> hubo un problema al eliminar la URL.
             		</div>";
		}
}
?>
<?php include 'inc/header.php'; ?>
<section class="main container">
	<div class="row">
		<section class="col-md-5">
            <div class="bs-call bs-call-green">
				<div class="panel-group" id="accordion1"> 
					<div class="panel panel-primary"> 
						<div class="panel-heading"> 
							<h4 class="panel-title"> 
							<a data-toggle="collapse" data-parent="#accordion1" href="#collapse1"> 
							<i class="fa fa-newspaper-o fa-2x"></i> Promoción de videos</a> 
							</h4> 
						</div>
						<div id="collapse1" class=""> 
							<div class="panel-body">
							<?php if(isset($msg)){echo $msg;}?>
								<form method="post" name="form_in">

									<div class="form-group">
										<label class="col-md-3">URL</label>
										<div class="col-md-8">
											<input type="text" name="txturl" class="form-control" />
											<script type="text/javascript">
												document.formu.inputmax.maxLength = 40;
											</script>
										</div>
									</div>

			                		<div class="form-group">
										<label class="col-md-3">Descripción</label>
										<div class="col-md-8">
											<input type="text" name="txtdesc" class="form-control" />
											<script type="text/javascript">
												document.formu.inputmax.maxLength = 40;
											</script>
										</div>
									</div>

								    <div class="form-group">
			              		        <div class="col-md-12">
			                            	<br><button type="submit" class="btn btn-success btn-block" name="btn_nuevo_video"><span class="fa fa-check"></span> Publicar</button>
			                            
			                                <a href="publicitar-en-california.php" class="btn btn-danger btn-block"><span class="fa fa-stop"></span> Cancelar</a>
			                            </div>

			                        </div>
								</form>
							</div> 
						</div>
					</div> 
				</div>
            </div>
        </section>
        <section class="col-md-7">
			<div class="panel panel-default">
			  <div class="panel-body">
				  <div class="table-responsive">
					   <table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
						  <thead>
						    <tr>
						      <th>Id</th>
						      <th>URL</th>
						      <th>Descripción</th>
						      <th style="color: #337AB7;">Posición</th>
						      <th>Posicionar</th>
						      <th style="color: #5CB85C;">Autorizar</th>
						      <th>Eliminar</th>
						    </tr>
						  </thead>
							  <tbody>
							  <?php 
								$stmt = $user_ads->runQuery("SELECT * FROM video_url ORDER BY idvideo_url DESC");
								$stmt->execute();
								while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
								{
							   ?>
							    <tr>
							      <td><?php echo $row['idvideo_url']; ?></td>
							      <td><?php echo $row['url']; ?></td>
							      <td><?php echo $row['descripcion']; ?></td>
							      <td><?php echo $row['posicion']; ?></td>
							      
							     <td>
				 					<a href="posicionar-video.php?idvideo=<?php print($row['idvideo_url']); ?>" class="btn btn-primary btn-block" ><span class="fa fa-arrow-circle-up"></span> Posicionar</a>
						      	 </td>
							      <?php if ($row['visible']=='si'): ?>
						      			<?php 
						      			echo "<td><a href='autorizar-video.php?idvideo=$row[idvideo_url]'
									      			class='btn btn-success btn-block'>
													<span class='fa fa-check'></span>
						      							</a>
						      						</td>"; ?>
						      		<?php else:{
						      						echo "<td>
						      								<a href='autorizar-video.php?idvideo=$row[idvideo_url]'
									      					class='btn btn-warning btn-block'>
															<span class='fa fa-stop-circle'></span>
						      								</a>
						      							 </td>";
						      						} ?>
						      			
						      		<?php endif ?>
							     <td aling="center">
							     	<button data-toggle="modal" 
					 					data-target="#<?php echo $row['idvideo_url'];?>" class="btn btn-danger btn-block">
					 					<i class="fa fa-trash"></i>
					 				</button>
							     </td>

							    </tr>
							    
				<div class="modal fade" id="<?php echo $row['idvideo_url'];?>" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          			<div class="modal-dialog modal-sm">
            			<div class="modal-content">
              				<div class="modal-header">
                				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                				<h4 class="modal-title" id="myModalLabel">Eliminar publicidad</h4>
                				
              				</div>
              			<div class="modal-body">
				 			<form method="post" action="">
                   				<div class="alert alert-dismissible alert-info">
						  			<i class="fa fa-link"></i><strong> ¿Esta seguro de eliminar esta URL?</strong>
								</div>
								<div class="form-group" hidden="true">
			           				<div class="col-md-1">
							  			<input class="form-control" type="text" name="txtidvideo" value="<?php echo $row['idvideo_url'];?>">
							  		</div>
							  	</div>
              			</div>
              				<div class="modal-footer">
                				<button class="btn btn-block btn-success btn-md" name="btn_eliminar_video"><i class="fa fa-check-square"></i> Si
                				</button>
				 				<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> No
				 				</button>
							</form>
              				</div>
            			</div>
          			</div>
        		</div>
							    <?php 
								}
							     ?>

							  </tbody>
					</table>
			  </div>
			  </div>
			</div>
		</section>
    </div>
</section>
<?php include 'inc/footer.php' ?>