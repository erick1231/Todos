<?php
/**
 * file: core.php
 * @author anthoncode
 * @link https://anthoncode.com
 */
define('HTML_DIR','http://localhost/4avisos');//para el correo http://www.4avisos.com
define('APP_TITTLE','4avisos');
define('APP_TITTLE_EMAIL','4avisos');//Para correo
define('APP_COPY','Copyright &copy; ' . date('Y',time()) . ' 4Avisos - Avisos clasificados California ');
define('RED_SOCIAL','http://www.facebook.com/anthoncode');
define('YOUTUBE', '#');

//define('SECURE', 'SSL');
//define('HOST', 'smtp.mailtrap.io');
//define('PORT', '465');
//define('USERNAME', 'df2369f4b01fbd'); //mailtrap
//define('PASS_MAIL', '0cde408b3e90b7');
//define('REPLY', 'anthoncode-a46ae6@inbox.mailtrap.io','4avisos');

?>