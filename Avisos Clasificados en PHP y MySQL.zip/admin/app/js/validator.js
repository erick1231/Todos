  $('#loginForm').bootstrapValidator({
         message: 'Este valor no es valido',
         feedbackIcons: {
             validating: 'glyphicon glyphicon-refresh'
         },
         fields: {
             txtcorreo: {    
                 validators: { 
                     notEmpty: {
                         message: 'Debes introducir un correo electrónico'
                     },
                     emailAddress: {
                         message: 'El correo electronico no es valido'
                     }
                 }
             },
             txtcontra: {
                 validators: {
                     notEmpty: {
                         message: 'Debes introducir una contraseña'
                     }
                 }   
             } 
         }
    });
     
    $('#registrationForm').bootstrapValidator({
         feedbackIcons: {
             valid: 'glyphicon glyphicon-ok',
             invalid: 'glyphicon glyphicon-remove',
     
             validating: 'glyphicon glyphicon-refresh'
         },

         fields: {

             txtnombre: {
                 validators: {
                     notEmpty: {
                         message: 'El nombre es requerido'
                     },
                 }
             },

             txtapellido: {
                 validators: {
                     notEmpty: {
                         message: 'El apellido es requerido'
                     },
                     regexp: {
                            regexp: /^[A-Z-a-ñ-z\s]+$/,
                            message:'El nombre debe contener texto'
                     }
                 }
             },
     
             txtcorreo: {    
                 validators: { 
                     notEmpty: {
                         message: 'El correo es requerido y no puede estar vacio'
                     },
                     emailAddress: {
                         message: 'El correo electronico no es valido'
                     }
                 }
             },
     
            /* txtcontra: {
     
                 validators: {
     
                     notEmpty: {
     
                         message: 'La contraseña es requerido y no puede ser vacio.'
     
                     },
     
                     stringLength: {
     
                         min: 8,
     
                         message: 'La contraseña debe contener al menos 8 caracteres'
     
                     }
     
                 }
     
             },
     */
             datetimepicker: {
                 validators: {
                     notEmpty: {
                         message: 'La fecha de nacimiento es requerida y no puede ser vacia'
                     },
                     date: {
                         format: 'YYYY-MM-DD',
                         message: 'La fecha de nacimiento no es valida'
                     }
                 }
             },

             terminos: {
                 validators: {
                     notEmpty: {
                         message: 'Debes aceptar los terminos para crear la cuenta'
                     }
                 }
             },
     
             txttelefono: {
                 message: 'El teléfono no es valido',
                 validators: {
                     notEmpty: {
                         message: 'El teléfono es requerido'
                     },
                     regexp: {
                         regexp: /^[0-9]+$/,
                         message: 'El teléfono debe contener números'
                     }
                 }
             },
     
             telefono_cel: {
                 message: 'El teléfono no es valido',
                 validators: {
                     regexp: {
                         regexp: /^[0-9]+$/,
                         message: 'El teléfono debe contener números'
                     }
                 }
             },



             txtcontra: {
                validators: {
                    notEmpty: {
                        message: 'la contraseña es obligatoria y no vacia'
                    },
                    identical: {
                        field: 'txtconfirmar',
                        message: 'La contraseña y su confirmacion no son la misma'
                    },

                }
            },

            txtconfirmar: {
                validators: {
                    notEmpty: {
                        message: 'la contraseña es obligatoria y no vacia'
                    },
                    identical: {
                        field: 'txtcontra',
                        message: 'La contraseña y su confirmacion no son la misma'
                    }
                }
            },

         }

    });

/*validacion de contraseña de perfil*/
 $('#validaperfil').bootstrapValidator({

    feedbackIcons: {
             valid: 'glyphicon glyphicon-ok',
             invalid: 'glyphicon glyphicon-remove',
     
             validating: 'glyphicon glyphicon-refresh'
         },

         fields: {

             userNombre: {
                 validators: {
                     notEmpty: {
                         message: 'El nombre es requerido'
                     },
                     regexp: {
                            regexp: /^[A-Z-a-ñ-z\s]+$/,
                            message:'El nombre debe contener texto'
                     }
                 }
             },

            userApell: {
                 validators: {
                     notEmpty: {
                         message: 'El apellido es requerido'
                     },
                     regexp: {
                            regexp: /^[A-Z-a-ñ-z\s]+$/,
                            message:'El nombre debe contener texto'
                     }
                 }
             },

            userTele: {
                 message: 'El teléfono no es valido',
                 validators: {
                     notEmpty: {
                         message: 'El teléfono es requerido'
                     },
                     regexp: {
                         regexp: /^[0-9]+$/,
                         message: 'El teléfono debe contener números'
                     }
                 }
             },
        }
            

 });
     
     