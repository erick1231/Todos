<?php
require_once 'include/class.user.php';
require ('config/core.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
<title>
</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>clasificados</title>
    <link href="app/css/bootstrap.min.css" rel="stylesheet">
    <link href="app/css/font-awesome.css" rel="stylesheet">
    <link href="app/css/font-awesome.min.css" type="text/css" rel="stylesheet" >
    <link rel="shortcut icon" href="../app/images/logo_4avisos.ico">
    <!-- social -->
    <link rel="stylesheet" type="text/css" href="app/css/bootstrap-social.css">
	<link rel="stylesheet" type="text/css" href="app/css/up-button.css">
	<link href="app/css/responsive.css" rel="stylesheet">
	<link href="app/css/panel.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="app/css/dataTables.bootstrap.css">
	<link rel="stylesheet" type="text/css" href="app/css/bootstrapValidator.min.css">   
	<link rel="stylesheet" type="text/css" href="app/css/fullcalendar/fullcalendar.css">
	<link rel="stylesheet" type="text/css" href="app/css/uploadimage/bootstrap-imageupload.min.css">
</head>
<body>
<header>
	<nav class="navbar navbar-default navbar-static-top">
		<div class="container">
			<div class="navbar-header">	
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<div class="logo">
					<a href="index.php">
						<img src="../app/images/4avisos-california-principal.png" alt="avisos clasificados California" />
					</a>
				</div>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav navbar-right">
					<?php
					 if(isset($_SESSION['userSessionA']))
						{
					?>
					<li><a href="panel.php"><i class="fa fa-home"></i> Inicio</a></li>	
						<li class="dropdown">
					        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="icon icon-th-list"> </span> Categorías <span class="caret"></span></a>
					          <ul class="dropdown-menu" role="menu">
					            <li><a href="cat-empleo.php"><span class="icon-briefcase"></span> Categoría empleo</a></li>
					            <li class="divider"></li>
					            <li><a href="cat-venta.php"><span class="fa fa-handshake-o"></span> Categoría venta</a></li>
					            <li class="divider"></li>
					            <li><a href="cat-compra.php"><span class="fa fa-cart-arrow-down"></span> Categoría compra</a></li>
					            <li class="divider"></li>
					            <li><a href="cat-serv.php"><span class="icon-bullhorn"></span> Categoría servicio</a></li>
					            <li class="divider"></li>
					            <li><a href="usuarios.php"><span class="fa fa-user-circle"></span> Usuarios</a></li>
					            <li class="divider"></li>
					          </ul>
					        </li>

						<li class="dropdown">
					          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="icon icon-th-list"> </span> Avisos <span class="caret"></span></a>
					        <ul class="dropdown-menu" role="menu">
					            <li><a href="av-empleo.php"><span class="icon-briefcase"></span> Aviso empleo</a></li>
					            <li class="divider"></li>
					            <li><a href="av-venta.php"><span class="fa fa-handshake-o"></span> Aviso venta</a></li>
					            <li class="divider"></li>
					            <li><a href="av-compra.php"><span class="fa fa-cart-arrow-down"></span> Aviso compra</a></li>
					            <li class="divider"></li>
					            <li><a href="av-servicio.php"><span class="icon-bullhorn"></span> Aviso servicio</a></li>
					            
					            <li class="divider"></li>
					            <li><a href="usuarios.php"><span class="fa fa-user-circle"></span> Usuarios</a></li>
					            <li class="divider"></li>
					        </ul>
					    </li>

						<li class="dropdown">
					          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="icon icon-th-list"> </span> Aplicaciones <span class="caret"></span></a>
					          <ul class="dropdown-menu" role="menu">
					            <li><a href="pub.php"><span class="fa fa-newspaper-o"></span> Publicidad</a></li>
					            <li class="divider"></li>
					            <li><a href="pro-video.php"><span class="fa fa-video-camera"></span> Promocionar video</a></li>
					            <li class="divider"></li>
					            <li><a href="codigos-act.php"><span class="fa fa-key"></span> Códigos de activación</a></li>
					            <li class="divider"></li>
					            <li><a href="mensajes.php"><span class="fa fa-bell"></span> Mensajes</a></li>
					            <li class="divider"></li>
					            <li><a href="reportes.php"><span class="fa fa-info"></span> Reportes</a></li>
					            <li class="divider"></li>
					          </ul>
					    </li>
					    <li><a href="<?php echo HTML_DIR; ?>" target="_blank"><i class="fa fa-globe"></i> Ver página</a></li>	
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
							 <?php echo $row['userEmailA'];?><span class="caret"></span>
							</a>
							<ul class="dropdown-menu">
								<li><a href="profile.php"><i class="icon-user"></i> Perfil</a></li>
								<li role="separator" class="divider"></li>
								<li><a href="logout.php"><i class="icon-chevron-right"></i> Salir</a></li>
							</ul>					
						</li>
					<?php 
						}
					?>
				</ul>
		    </div>	
		</div>
	</nav>
</header>
