<span class="ir-arriba fa fa-chevron-up"></span><br>
<br><br>
<footer id="footer">
	<div class="footer-widget">
		<div class="container">
		<br>
			<div class="row">
				<div class="col-md-3 col-sm-6 col-xs-6">
					<div class="footer-one">
						<ul class="list1">
							<h4 class="redesinfo">Siguenos en</h4>
            				<a type="button" target="_blank" href="<?php echo RED_SOCIAL; ?>" class="btn btn-primary" aria-label="Left Align">
						  		<span class="fa fa-facebook" aria-hidden="true"></span>
							</a>
							<a type="button" target="_blank" href="<?php echo YOUTUBE; ?>" class="btn btn-danger" aria-label="Left Align">
						  		<span class="fa fa-youtube" aria-hidden="true"></span>
							</a>
							<!-- <li><a href="#">Terms of Use</a></li>
							<li><a href="#">Terms of Use</a></li> -->
						</ul>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-6">
					<div class="footer-two">
						<ul class="list2">
							<h4>Servicios</h4>
							<li><a href="#">Regístrate</a></li>
							<li><a href="#">Publicar aviso</a></li>
							<li><a href="#">Acceder</a></li>
							<li><a href="#">Avisos clasificados</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-6">
					<div class="footer-tree">
						<ul class="list3">
							<h4>Información</h4>
							<li><a href="#">Acerca de 4avisos</a></li>
							<li><a href="#">Términos  y condiciones</a></li>
							<li><a href="#">Consejos de seguridad</a></li>
							<li><a href="#">Contacto</a></li>
						</ul>
					</div>
				</div>

				<div class="col-md-3 col-sm-6 col-xs-6">
					<div class="footer-four">
						<ul class="list4">
							<h4>Aplicaciones</h4>
							<li><a href="#">El clima en California</a></li>
							<li><a href="#">Ayuda</a></li>

						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footer-down">
		<div class="container">
			<div class="row">
				<p class="pull-left"><?php echo APP_COPY; ?></p>
				<p class="pull-right">Designed by <span><a href="https://anthoncode.com" target="_blank">Anthon Code</a></span></p>
			</div>
		</div>
	</div>
</footer>

	<script src="app/js/jquery.js"></script>
  	<script src="app/js/bootstrap.min.js"></script>
  	<script src="app/js/bootstrapValidator.js"></script>
  	<script src="app/js/validator.js"></script>
  	<script src="app/js/up-button.js"></script>
  	<script src="app/js/jquery.dataTables.js"></script>
  	<script src="app/js/dataTables.bootstrap.js"></script>
  	<script src="app/js/fullcalendar/moment.min.js"></script>
  	<script src="app/js/fullcalendar/fullcalendar.js"></script>
  	<script src="app/js/fullcalendar/es.js"></script>
  	<script type="text/javascript" src="app/js/uploadimage/bootstrap-imageupload.min.js"></script>
  	<script>
        var $imageupload = $('.imageupload');
        $imageupload.imageupload();
    </script>
  	<script>
	$(document).ready(function() {
		$('#calendar').fullCalendar({
			editable: true,
			language: 'es',
			eventLimit: true,
		});
	});
	</script>
	
  	<script src="app/js/moment.min.js"></script>
	<script type="text/javascript" language="javascript" class="init">
		$(document).ready(function() {
			$('#example').DataTable();
		} );
	</script>
</body>
</html>

	