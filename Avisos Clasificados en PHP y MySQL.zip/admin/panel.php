<?php
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('index.php');
}

$stmt = $user_ads->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<?php include 'inc/header.php'; ?>
<section class="main container">

<?php 
$stmt = $user_ads->runQuery('SELECT * FROM usuarios');
$stmt->execute();
$count = $stmt->rowcount();

$stmt = $user_ads->runQuery('SELECT * FROM cat_empleo');
$stmt->execute();
$count1 = $stmt->rowcount();

$stmt = $user_ads->runQuery('SELECT * FROM cat_venta');
$stmt->execute();
$count2 = $stmt->rowcount();

$stmt = $user_ads->runQuery('SELECT * FROM cat_compra');
$stmt->execute();
$count3 = $stmt->rowcount();

$stmt = $user_ads->runQuery('SELECT * FROM cat_servicio');
$stmt->execute();
$count4 = $stmt->rowcount();
/*avisos*/
$stmt = $user_ads->runQuery('SELECT * FROM aviso_empleo');
$stmt->execute();
$count5 = $stmt->rowcount();

$stmt = $user_ads->runQuery('SELECT * FROM aviso_venta');
$stmt->execute();
$count6 = $stmt->rowcount();

$stmt = $user_ads->runQuery('SELECT * FROM aviso_servicio');
$stmt->execute();
$count7 = $stmt->rowcount();

$stmt = $user_ads->runQuery('SELECT * FROM aviso_compra');
$stmt->execute();
$count8 = $stmt->rowcount();


$stmt = $user_ads->runQuery('SELECT ((SELECT COUNT(*) FROM reportes_empleo) 
                                    + (SELECT COUNT(*) FROM reportes_venta) 
                                    + (SELECT COUNT(*) FROM reportes_servicio)
                                    + (SELECT COUNT(*) FROM reportes_compra)) AS TOTAL');
$stmt->execute();
$row9 = $stmt->fetch(PDO::FETCH_ASSOC);
$contar = $row9['TOTAL'];



$stmt = $user_ads->runQuery('SELECT ((SELECT COUNT(*) FROM aviso_empleo) 
                                    + (SELECT COUNT(*) FROM aviso_venta) 
                                    + (SELECT COUNT(*) FROM aviso_servicio)
                                    + (SELECT COUNT(*) FROM aviso_compra)) AS TOTAL_AVISO');
$stmt->execute();
$rowtotal = $stmt->fetch(PDO::FETCH_ASSOC);
$contar_aviso = $rowtotal['TOTAL_AVISO'];



$stmt = $user_ads->runQuery('SELECT * FROM Publicidad');
$stmt->execute();
$count10 = $stmt->rowcount();

$stmt = $user_ads->runQuery('SELECT * FROM video_url');
$stmt->execute();
$count11 = $stmt->rowcount();

?>
    <div class="row">
        <section class="col-md-3">
            <div class="list-group">
                <a href="#" class="list-group-item active">Usuarios</a>
                <a href="usuarios.php" class="list-group-item">
                <span class="fa fa-user"></span> Todos los usuarios
                <span class="badge"><?php echo $count; ?></span></a>
        
                <a href="reportes.php" class="list-group-item">
                <span class="icon icon-info"></span> Reportes
                <?php 
                if ($contar > 0) {
                    echo "<span class='badge' style='background-color:#F0AD4E;'>$contar</span>";
                 } 
                ?>
               </a>
                <!-- avisos -->
                <a href="#" class="list-group-item active">Avisos</a>
                <a href="av-empleo.php" class="list-group-item">
                    <span class="fa fa-briefcase"></span> Aviso de empleos
                    <span class="badge">
                    <?php echo $count5; ?></span>
                </a>

                <a href="av-venta.php" class="list-group-item">
                    <span class="fa fa-handshake-o"></span> Aviso de venta
                    <span class="badge">
                    <?php echo $count6; ?></span>
                </a>
                <a href="av-servicio.php" class="list-group-item">
                    <span class="fa fa-bullhorn"></span> Aviso de servicio
                    <span class="badge">
                    <?php echo $count7; ?></span>
                </a>
                <a href="av-compra.php" class="list-group-item">
                    <span class="fa fa-cart-arrow-down"></span> Aviso de compra
                    <span class="badge">
                    <?php echo $count8; ?></span>
                </a>
                <!-- categorias -->
                <a href="#" class="list-group-item active">Categorías</a>
                <a href="cat-empleo.php" class="list-group-item">
                    <span class="fa fa-briefcase"></span> Categoría empleo
                    <span class="badge">
                    <?php echo $count1; ?></span>
                </a>
                <a href="cat-venta.php" class="list-group-item">
                    <span class="fa fa-handshake-o"></span> Categoría venta
                    <span class="badge"><?php echo $count2; ?></span>
                </a>
                <a href="cat-serv.php" class="list-group-item">
                    <span class="fa fa-bullhorn"></span> Categoría servicio
                    <span class="badge"><?php echo $count4; ?></span>
                </a> 
                <a href="cat-compra.php" class="list-group-item">
                    <span class="fa fa-cart-arrow-down"></span> Categoría compra
                    <span class="badge"><?php echo $count3; ?></span>
                </a>
                <a href="#" class="list-group-item active">Aplicaciones</a>
                <a href="pub.php" class="list-group-item">
                    <span class="fa fa-newspaper-o"></span> Publicidad
                    <span class="badge">
                    <?php echo $count10; ?></span>
                </a>
                <a href="pro-video.php" class="list-group-item">
                    <span class="fa fa-video-camera"></span> Videos promocionados
                    <span class="badge">
                    <?php echo $count11; ?></span>
                </a>
                <a href="codigos-act.php" class="list-group-item">
                    <span class="fa fa-key"></span> Códigos de activación 
                </a>
                <a href="mensajes.php" class="list-group-item">
                    <span class="fa fa-bell"></span> Mensajes
                </a>                
            </div>
        </section>

        <section class="col-md-9">
            <div class="row">
                <div class="col-md-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <span class="icon icon-user icon-4x"></span>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <h3><?php echo $count; ?></h3>
                                    <div>Usuarios</div>
                                </div>
                            </div>
                        </div>
                        <a href="usuarios.php">
                            <div class="panel-footer">
                                <span class="pull-left">Ver más detalles</span>
                                <span class="pull-right"><i class="icon-circle-arrow-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-file fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <h3><?php echo "$contar_aviso"; ?></h3>
                                    <div>Total de avisos</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <!-- <span class="pull-left">View Details</span> -->
                                <span class="pull-right"><i class="icon-circle-arrow-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-video-camera fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <h3><?php echo $count11; ?></h3>
                                    <div>Videos promocionados</div>
                                </div>
                            </div>
                        </div>
                        <a href="pro-video.php">
                            <div class="panel-footer">
                                <span class="pull-left">Ver más detalles</span>
                                <span class="pull-right"><i class="icon-circle-arrow-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>            
            </div>  
                 
                <div class="panel panel-default">
                      <div class="panel-body">
                        <div id='calendar'>
                        </div>
                      </div>
                </div>
        </section>
    </div>
</section> 
<?php include 'inc/footer.php'; ?>