<?php 
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('index.php');
}
$stmt = $user_ads->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC); ?>

<?php
$get_idaviso_empleo = $_GET['idaviso_empleo'];			
$stmt = $user_ads->runQuery("SELECT * FROM aviso_empleo WHERE idaviso_empleo='$get_idaviso_empleo'");
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);
	if($row['visible']=='si') 
	{
		$sql = 'UPDATE aviso_empleo SET visible=?
		WHERE idaviso_empleo=?';
		$this_status = "no";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idaviso_empleo));
		header("location: av-empleo.php");
	}
	else
	{
		$sql = 'UPDATE aviso_empleo SET visible=?
		WHERE idaviso_empleo=?';
		$this_status = "si";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idaviso_empleo));
		header("location: av-empleo.php");
	} 
?>