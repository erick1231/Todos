<?php 
session_start();
require_once 'include/class.user.php';
$reg_user = new USER();

if($reg_user->is_logged_in()!="")
{
    $reg_user->redirect('index.php');
}

if (isset($_POST['btn_signup']))
{
    $unombre = trim($_POST['txtnombre']);
    $email = trim($_POST['txtcorreo']);
    $tele = trim($_POST['txttelefono']);
    $upass = trim($_POST['txtcontra']);
    $code = md5(uniqid(rand()));

    $stmt = $reg_user->runQuery("SELECT * FROM centraluser WHERE userEmailA=:email_id");
    $stmt->execute(array(":email_id"=>$email));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if($stmt->rowCount() > 0)
    {
        $msg = "
            <div class='alert alert-danger'>
                <button class='close' data-dismiss='alert'>&times;</button>
                <strong>Disculpe! </strong>este correo electrónico ya esta registrado, por favor intente con otro.
            </div>";
    }

else
{
    if($reg_user->register($unombre,$email,$tele,$upass,$code))
    {
        $id = $reg_user->lasdID();
        $key = base64_encode($id);
        $id = $key;

        $message = "
                    Hola $unombre,
                    <br /><br />
                    bienvenido a pagina central<br />
                    Para completar su registro, haga clic en el enlace siguiente.
                                    
                    <br /><br />
                    <a href='http://localhost:8080/anuncios4/admin/verify.php?id=$id&code=$code'>Click Haqui para activar :)</a>
                    <br /><br />
                   gracias,";

    $subject = "confirme el registro";

    $reg_user->send_mail($email,$message,$subject);
    $msg = "
            <div class='alert alert-success'>
                <button class='close' data-dismiss='alert'>&times;</button>
                <strong>exito!</strong> Hemos enviado un correo electrónico al correo electrónico.
                 Haga clic en el enlace de confirmación en el correo electrónico para crear su cuenta.
             </div>
             ";
        }
        else
        {
            echo " disculpe, Query no pudo ejecutar...";
        }
    }
}
?>
<?php include 'inc/header.php'; ?>
    <div class="container">

        <div class="row">
            <div class="col-md-4 col-md-offset-4 ">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Crear una cuenta nueva</h3>
                    </div>
                <div class="panel-body">
                        <?php if(isset($msg)) echo $msg; ?>
				    <form role="form" id="registrationForm" method="post" class="form-horizontal mitad">
                        
                          <div class="form-group">
                                <label class="col-sm-4 control-label">Nombres</label>
                                    <div class="col-sm-8">
                                            <input type="text" name='txtnombre' class="form-control" maxlength="50">
                                    </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Correo</label>
                                    <div class="col-sm-8">
                                        <input type="email" name='txtcorreo' class="form-control" maxlength="60">
                                    </div>
                            </div>

							<div class="form-group">
                                <label class="col-sm-4 control-label">Teléfono</label>
                                    <div class="col-sm-8">
                                        <input type="text" name='txttelefono' class="form-control" maxlength="10">
                                    </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Contraseña</label>
                                    <div class="col-sm-8">
                                        <input type="password" name='txtcontra' class="form-control" maxlength="20">  <!--required=""-->
                                    </div>
                            </div>


                            <div class="form-group">
                                <label class="col-sm-4 control-label">Confirmar contraseña</label>
                                    <div class="col-sm-8">
                                        <input type="password" name="txtconfirmar" class="form-control" maxlength="20">
                                    </div>
                            </div>
                        
<!--                             <div class="form-group">
                                <label class="col-sm-4 control-label"></label>
                                    <div class="col-sm-8">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox" name="terminos"> Estoy de acuerdo con los <a href="#">terminos y condiciones</a>
                                            </label>
                                        </div>
                                    </div>
                            </div>
                         -->
              				<div class="form-group">
              		            <div class="col-sm-12">
                                <button  type="submit" class="btn btn-primary btn-block" name="btn_signup" value="registrar"><i class="glyphicon glyphicon-ok"></i> Crear cuenta</button>
                                </div>
                            </div>
                        </form>
                     <hr>
                </div>
            </div>
		</div>
  </div>
</div>



<br>	

		<?php include 'inc/footer.php'; ?>
    </body>
</html>
