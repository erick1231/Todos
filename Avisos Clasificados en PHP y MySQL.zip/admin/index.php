<?php 
session_start();
require_once 'include/class.user.php';
$user_login = new USER();
if($user_login->is_logged_in()!="")
{
  $user_login->redirect('panel.php');
}
if(isset($_POST['btn-login']))
{
  $email = $user_login->limpiarCorreo($_POST['txtcorreo']);
  $contra = trim($_POST['txtcontra']);

  if (empty($email)) {
        $msg = "<div class='alert alert-danger'>
                    <button class='close' data-dismiss='alert'>&times;</button>
                    <strong>Ingrese un correo</strong>    
                </div>";

    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = "<div class='alert alert-danger'>
                    <button class='close' data-dismiss='alert'>&times;</button>
                    <strong>Ingrese un correo valido</strong>    
                </div>";
    }elseif (empty($contra)) {
        $msg = "<div class='alert alert-danger'>
                    <button class='close' data-dismiss='alert'>&times;</button>
                    <strong>Ingrese una contraseña</strong>    
                </div>";
    }else
    {
      if($user_login->login($email,$contra))
      {
        $user_login->redirect('panel.php');
      }
    }
}
?>
<?php include 'inc/header.php'; ?>
<div class="container">
	<div class="row">
		<div class="col-md-4  col-md-offset-4 "><br>
				<div class="login-panel panel panel-default">
                  <div class="panel-heading">
                      <h3 class="panel-title"><i class="fa fa-lock"></i> Inicio de sesión</h3>
                  </div>

                  <div class="panel-body">
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="loginForm" method="post" autocomplete="off">
                     <?php if(isset($msg)) echo $msg; ?>
                      <?php
                      if (isset($_GET['error'])) 
                      {
                      ?>
                      <div class='alert alert-danger'>
                          <button class='close' data-dismiss='alert'>&times;</button>
                          <strong>Datos incorrectos</strong>    
                      </div>
                      <?php   
                      }
                      ?>
                       <?php
                           if(isset($_GET['inactive']))
                          {
                      ?>
                      <div class='alert alert-danger'>
                          <button class='close' data-dismiss='alert'>&times;</button>
                          <strong>Disculpe</strong> esta cuenta no esta activada revisa el enlace.   
                      </div>
                      <?php
                      }
                      ?>
                            <div class="form-group">
                                <div class="form-group has-feedback">
                                    <input class="form-control" placeholder="Correo electronico" name="txtcorreo" type="" required="" class="autodisable" value="">
                                    <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="form-group has-feedback">
                                    <input class="form-control" placeholder="Contraseña" name="txtcontra" type="password" required="" class="autodisable" value="**********">
                                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                                </div>
                            </div>

                            <div class="form-group">
                                <button  type="submit" class="btn btn-success btn-block" name="btn-login"><i class="fa fa-check"></i> Entrar</button>
                            </div>
                      </form>
                  </div>
            </div>
	   </div>
   </div>
</div><br>
<?php include 'inc/footer.php'; ?>
