<?php  
session_start();
require_once 'include/class.user.php';
$user_empleo = new USER();
if(!$user_empleo->is_logged_in())
{
  $user_empleo->redirect('index.php');
}
$stmt = $user_empleo->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);				
?>
<?php 
	if(isset($_POST['btn-borrar-av-venta']))
	{
		$id=$_GET['delete_id_vent'];
		$stmt_edit = $user_empleo->runQuery('SELECT foto FROM aviso_venta WHERE idaviso_venta =:idventa');
		$stmt_edit->execute(array(':idventa'=>$id));
		$delete_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
		unlink("../media/fotos_images4/".$delete_row['foto']);

		if($user_empleo->delete_aviso_vent($id))
		{
		 $msg="<div class='alert alert-success'>
	    	 	<strong><span class='icon-ok-sign icon-2x'></span></strong> Aviso eliminado correctamente. 
				</div>";
				header("refresh:1;av-venta.php");
		}
		else
		{
		$msg = "<div class='alert alert-danger'>
				<span class='icon-frown icon-2x'></span><strong> Error</strong> al eliminar los datos
				</div>";
		}
	}	
?>
<?php include 'inc/header.php'; ?>
<div class="container">
	<?php
	 if(isset($_GET['delete_id_vent']))
	 {
		?>
        <?php 
		$stmt = $user_empleo->runQuery("SELECT  usuarios.userID,
												idaviso_venta,
												usuarios.userNombre, 
												cat_ciudad.ciudad, 
												cat_venta.idcat_venta,
												cat_venta.nombre,
												idaviso_venta, 
												titulo,
												foto,
												descripcion, 
												fecha_pub
												FROM aviso_venta

												INNER JOIN usuarios
												ON aviso_venta.id_usuario=usuarios.userID
												INNER JOIN cat_ciudad
												ON aviso_venta.id_ciudad=cat_ciudad.idCiudad
												INNER JOIN cat_venta
												ON aviso_venta.id_cat_venta=cat_venta.idcat_venta 
												WHERE idaviso_venta=:id");

		$stmt->execute(array(":id"=>$_GET['delete_id_vent']));
		$stmt->execute();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);	
		?>
		<?php
     }
        ?>
		<?php
		if(isset($_GET['delete_id_vent']))
			{
		?>
    <div class="row">
    	<div class="col-md-4 col-md-offset-4 ">
       		<div class="login-panel panel panel-warning">
            	<div class="panel-heading">
                <h3 class="panel-title"><span class="fa fa-exclamation-triangle fa-2x"></span> Estas eliminando un aviso clasificado</h3>
            	</div>
        		<div class="panel-body">
        		<div class='alert alert-danger'>
					<i class="fa fa-search fa-2x"></i><strong> Verifica los datos antes de borrar</strong>
				</div> 
        		<?php if(isset($msg)) { echo $msg; } ?>	
					<form role="form" id="registrationForm" method="post" class="form-horizontal mitad">
	                     <div class="form-group">
	                        <label class="col-sm-4 control-label">Usuario</label>
	                        <div class="col-sm-8">
	                            <input type="text" value='<?php echo $row['userNombre']; ?>' class="form-control" maxlength="50" disabled>
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="col-sm-4 control-label">Ciudad</label>
	                        <div class="col-sm-8">
	                            <input type="text" value='<?php echo $row['ciudad']; ?>' class="form-control" maxlength="50" disabled>
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="col-sm-4 control-label">Venta</label>
	                        <div class="col-sm-8">
	                            <input type="text" value='<?php echo $row['nombre']; ?>' class="form-control" maxlength="50" disabled>
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="col-sm-4 control-label">Título</label>
	                        <div class="col-sm-8">
	                            <input type="text" value='<?php echo $row['titulo']; ?>' class="form-control" maxlength="50" disabled>
	                        </div>
	                    </div>
	                    <div class="form-group">
					    	<label class="col-sm-4 control-label">Foto</label>
					    	<div class="col-sm-8">
					    		<td>
							      <img src="../media/fotos_images4/<?php echo $row['foto']; ?>" style='width:85px; height:95px'>
							    </td>
							</div>
					    </div>
	                    <div class="form-group">
					      	<label for="textArea" class="col-md-4 control-label">Textarea</label>
					      	<div class="col-md-8">
					        <textarea disabled class="form-control" rows="3" id="textArea"><?php echo $row['descripcion']; ?></textarea>
					      	</div>
					    </div>
	      				<div class="form-group">
	      		            <div class="col-sm-6">
	                        <button  type="submit" class="btn btn-danger btn-block" name="btn-borrar-av-venta"><i class="fa fa-times-circle"></i> Eliminar</button>
	                        </div>
	                        <div class="col-sm-6">
	                        <a href="av-venta.php" class="btn btn-success btn-block" ><i class="fa fa-stop"></i> Cancelar</a>
	                        </div>
	                    </div>
				    </form>
			        <?php
					}
					?>
                </div>
            </div>
		</div>
  	</div>    
</div>
<?php include 'inc/footer.php'; ?>
