<?php  
session_start();
require_once 'include/class.user.php';
$user_compra = new USER();
if(!$user_compra->is_logged_in())
{
  $user_compra->redirect('index.php');
}
$stmt = $user_compra->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);	
?>
<?php 
	if(isset($_POST['btn-editar-compra']))
	{
		$id=$_GET['editar_id'];
		$enombre = $_POST['txtnombre'];
		$eposicion = $_POST['txtposicion'];
		$eVisible = $_POST['txtvisible'];

		if($user_compra->editar_compra($id,$enombre,$eposicion,$eVisible))
		{
		 $msg="<div class='alert alert-success'>
	    	 	<strong><span class='icon-ok-sign icon-2x'></span></strong> Datos actualizados correctamente. 
				</div>";
				header("refresh:1;cat-compra.php");
		}
		else
		{
		$msg = "<div class='alert alert-danger'>
				<span class='icon-frown icon-2x'></span><strong> Error</strong> al actualizar los datos
				</div>";
		}
	}	
	if(isset($_GET['editar_id']))
	{
		$id = $_GET['editar_id'];
		extract($user_compra->getIDcompra($id));	
	}
?>
<?php include 'inc/header.php'; ?>
<div class="container">
    <div class="row">
    	<div class="col-md-4 col-md-offset-4 ">
       		<div class="login-panel panel panel-primary">
            	<div class="panel-heading">
                <h3 class="panel-title"><span class="icon-exclamation-sign icon-2x"></span> ¿Estas seguro en editar este dato?</h3>
            	</div>
        		<div class="panel-body">  
        		<?php
				if(isset($msg)) { echo $msg; } ?>
				<!-- volver a la pagina despues de segun -->		
					<form role="form" id="registrationForm" method="post" class="form-horizontal mitad">
						<div class="form-group" hidden>
	                        <div class="col-sm-8">
							<input type="hidden" name="idcat_compra" value="<?php echo $idcat_compra; ?>" />
							</div>
	                    </div>
	                    <div class="form-group">
	                        <label class="col-sm-4 control-label">Nombre</label>
	                        <div class="col-sm-8">
	                            <input type="text" name="txtnombre" value="<?php echo $nombre; ?>" class="form-control" maxlength="50" >
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="col-sm-4 control-label">Posición</label>
	                        <div class="col-sm-8">
	                            <input type="text" name="txtposicion" value='<?php echo $posicion; ?>' class="form-control" maxlength="50">
	                        </div>
	                    </div>
		                 <div class="form-group">
						      <label class="col-md-4 control-label">Visible</label>
						      <div class="col-md-8">
						        <div class="radio">
						          <label>
						            <input name="txtvisible" value="1" type="radio" 
						           <?php if($visible == 1) { echo " checked"; } ?> > 
						            Si
						          </label>
						        </div>
						        <div class="radio">
						          <label>
						            <input name="txtvisible" value="0" type="radio" 
						            <?php if($visible == 0) { echo " checked"; } ?> >
						            No 
						          </label>
						        </div>
						      </div>
							</div>
	      				<div class="form-group">
	      		            <div class="col-sm-6">
	                        <button  type="submit" class="btn btn-success btn-block" name="btn-editar-compra"><i class="icon-check-sign"></i> Editar</button>
	                        </div>
	                        <div class="col-sm-6">
	                        <a href="cat-compra.php" class="btn btn-danger btn-block" ><i class="icon-stop"></i> Cancelar</a>
	                        </div>
	                    </div>
				    </form>
                </div>
            </div>
		</div>
  	</div>    
</div>
<?php include 'inc/footer.php'; ?>
