<?php  
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('index.php');
}
$stmt = $user_ads->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<?php  
$stmt2 = $user_ads->runQuery("SELECT * FROM codigos");
$stmt2->execute();
$row_code=$stmt2->fetch(PDO::FETCH_ASSOC);
extract($row_code);

if (isset($_POST['btn-act-codigo'])) 
	{
		$id = $_POST['idcodigo'];
		$a_semana = $user_ads->limpiarDatos($_POST['codigo_semana']);
		$a_mes = $user_ads->limpiarDatos($_POST['codigo_mes']);

		if (empty($a_semana && $a_mes)) {
			$msgDato =  "<div class='alert alert-danger'>
							<strong>Olvidaste un dato</strong>
						</div>";
	    }
	    else{

		if($user_ads->act_codigo($id,$a_semana,$a_mes))
			{
			$msgCode = "<div class='alert alert-success'>
						<button type='button' class='close' data-dismiss='alert'>&times;</button>
						Los<strong> datos</strong> se actualizaron correctamente
						</div>";
						header('refresh:1;codigos-act.php');
			}
		else
			{
			$msgDos =  "<div class='alert alert-danger'>
						<strong>Error</strong> al actualizar los datos, intente mas tarde
						</div>";
			}
		}

	}
	if(isset($_POST['idcodigo']))
	{
		$id = $_POST['idcodigo'];
		extract($user_ads->id_act_codigo($id));	
	}
?>
<?php include 'inc/header.php'; ?>
<div class="container">
    <div class="row">
    	<div class="col-md-4 col-md-offset-4 ">
       		<div class="login-panel panel panel-primary">
            	<div class="panel-heading">
                <h3 class="panel-title"><span class="fa fa-key"></span> Códigos para activar publicidad</h3>
            	</div>
        		<div class="panel-body">  
        		<?php
				if(isset($msg)) { echo $msg; } ?>	
					<form role="form" id="" method="post" class="form-horizontal mitad">
						<?php if(isset($msgDato)){
							echo $msgDato;
							}elseif(isset($msgCode)){
								echo $msgCode;
							}elseif (isset($msgDos)) {
								echo $msgDos;
							}
						?>	
	                    <div class="form-group" hidden="">
	                        <div class="col-sm-8">
	                            <input type="text" name="idcodigo" value="<?php echo $idcodigo; ?>" class="form-control">
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="col-sm-4 control-label">Semana</label>
	                        <div class="col-sm-8">
	                            <input type="text" name="codigo_semana" value="<?php echo $codigo_semana; ?>" class="form-control" maxlength="50" >
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="col-sm-4 control-label">Mes</label>
	                        <div class="col-sm-8">
	                            <input type="text" name="codigo_mes" value="<?php echo $codigo_mes; ?>" class="form-control" maxlength="50" >
	                        </div>
	                    </div><br>
	                    <div class="form-group">
					        <div class="col-md-12">
					        <button type="submit" name="btn-act-codigo" class="btn btn-primary btn-block">
					        <i class="fa fa-check"></i>Actualizar datos</button>
					        </div>
				        </div>
				    </form>
                </div>
            </div>
		</div>
  	</div>    
</div>
<?php include 'inc/footer.php'; ?>
