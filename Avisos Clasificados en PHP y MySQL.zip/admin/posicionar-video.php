<?php 
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('index.php');
}
$stmt = $user_ads->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<?php
$get_idvideo = $_GET['idvideo'];			
$stmt = $user_ads->runQuery("SELECT * FROM video_url WHERE idvideo_url='$get_idvideo'");
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

	if($row['posicion']=='10') 

	{
		$sql = 'UPDATE video_url SET posicion=?
		WHERE idvideo_url=?';
		$this_status = "1";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idvideo));
		header("location: pro-video.php");
	
	}
	elseif($row['posicion']=='9') 

	{
		$sql = 'UPDATE video_url SET posicion=?
		WHERE idvideo_url=?';
		$this_status = "10";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idvideo));
		header("location: pro-video.php");
	
	}
	elseif($row['posicion']=='8') 

	{
		$sql = 'UPDATE video_url SET posicion=?
		WHERE idvideo_url=?';
		$this_status = "9";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idvideo));
		header("location: pro-video.php");
	
	}
	elseif($row['posicion']=='7') 

	{
		$sql = 'UPDATE video_url SET posicion=?
		WHERE idvideo_url=?';
		$this_status = "8";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idvideo));
		header("location: pro-video.php");
	
	}
	elseif($row['posicion']=='6') 

	{
		$sql = 'UPDATE video_url SET posicion=?
		WHERE idvideo_url=?';
		$this_status = "7";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idvideo));
		header("location: pro-video.php");
	
	}
	elseif($row['posicion']=='5') 

	{
		$sql = 'UPDATE video_url SET posicion=?
		WHERE idvideo_url=?';
		$this_status = "6";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idvideo));
		header("location: pro-video.php");
	
	}
	elseif($row['posicion']=='4') 

	{
		$sql = 'UPDATE video_url SET posicion=?
		WHERE idvideo_url=?';
		$this_status = "5";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idvideo));
		header("location: pro-video.php");
	
	}
	elseif($row['posicion']=='3') 
	{
		$sql = 'UPDATE video_url SET posicion=?
		WHERE idvideo_url=?';
		$this_status = "4";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idvideo));
		header("location: pro-video.php");
	}
	elseif($row['posicion']=='2') 
	{
		$sql = 'UPDATE video_url SET posicion=?
		WHERE idvideo_url=?';
		$this_status = "3";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idvideo));
		header("location: pro-video.php");
	}

	elseif($row['posicion']=='1') 

	{
		$sql = 'UPDATE video_url SET posicion=?
		WHERE idvideo_url=?';
		$this_status = "2";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idvideo));
		header("location: pro-video.php");
	
	}
?>
