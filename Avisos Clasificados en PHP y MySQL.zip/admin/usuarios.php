<?php  
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('index.php');
}
$stmt = $user_ads->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);				
?>
<?php include 'inc/header.php'; ?>
<section class="main container">
	<div class="row">		
		<?php 
			$stmt = $user_ads->runQuery('SELECT * FROM usuarios');
			$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
			$count = $stmt->rowcount();
	 	?>
		<div class="panel panel-default">
			<div class="panel-body">
					<!-- <div class="col-md-12"> -->
				<h4>Usuarios <span class="badge"><?php echo $count; ?></span></h4>
					<!-- </div> -->
					<!-- <div class="col-md-3"> 
			   	 			<input type="text" class="form-control" placeholder="Buscar">
		  			</div> -->
			</div>
		</div>
	</div>

	<div class="row">
		<div class="panel panel-default">
			<div class="panel-body">
				<div class="table-responsive">
				<table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
				  <thead>
				    <tr>
				      <th>Id</th>
				      <th>Nombre</th>
				      <th>Apellido</th>
				      <th>Teléfono</th>
				      <th>Email</th>
				      <!-- <th>Contraseña</th> -->
					  <!-- <th>Cuenta activa</th> -->
				      <th>Fecha</th>
				      <!-- <th>Código</th> -->
				      <th style="color: #D9534F;">Eliminar</th>
				      <th style="color: #449D44;">Accesso</th>
				      <th style="color: #337AB7;">Cuenta</th>
				    </tr>
				  </thead>
					  <tbody>
					  <?php 
						$stmt = $user_ads->runQuery("SELECT * FROM usuarios ORDER BY userID DESC");
						$stmt->execute();
						while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
						{
					   ?>
					    <tr>
					      <td><?php echo $row['userID']; ?></td>
					      <td><?php echo $row['userNombre']; ?></td>
					      <td><?php echo $row['userApell']; ?></td>
					      <td><?php echo $row['userTele']; ?></td>
					      <td><?php echo $row['userEmail']; ?></td>
					     <!--  <td><php echo $row['userContra']; ></td> -->
					      <!-- <td><php echo $row['userEstado']; ?></td> -->
					      <td><?php echo $row['fechaIn'] ?></td>
					      <td aling="center">
					      <a href="delete.php?delete_id=<?php print($row['userID']); ?>" class="btn btn-danger btn-block" ><span class="icon-remove-sign"></span></a>
					      </td>

					    <?php if ($row['userAcceso']=='Y'): ?>
						      			<?php 
						      			echo "<td>
							      				<a href='updatestatus.php?iduno=$row[userID]'
										      			class='btn btn-success btn-block'>
													<span class='fa fa-check'></span>
							      				</a>
						      				</td>"; ?>
						<?php else:{
						      		echo "<td>
						      				<a href='updatestatus.php?iduno=$row[userID]'
									      	class='btn btn-warning btn-block'>
											<span class='fa fa-lock'></span>
						      				</a>
						      			</td>";
						      			} ?>
						      			
						<?php endif ?>

						<?php if ($row['userEstado']=='Y'): ?>
						      			<?php 
						      			echo "<td>
							      				<a href='#'
										      			class='btn btn-primary btn-block'>
													<span class='fa fa-smile-o'></span>
							      				</a>
						      				</td>"; ?>
						<?php else:{
						      		echo "<td>
						      				<a href='#'
									      	class='btn btn-warning btn-block'>
											<span class='fa fa-times-circle'></span>
						      				</a>
						      			</td>";
						      			} ?>
						      			
						<?php endif ?>

					    </tr>
					    <?php 
							}
					    ?>
					  </tbody>
				  </table>
				</div>
			</div>			
		</div>
	</div>
</section>
<?php include 'inc/footer.php'; ?>

