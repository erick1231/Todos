<?php  
session_start();
require_once 'include/class.user.php';
$user_empleo = new USER();
if(!$user_empleo->is_logged_in())
{
  $user_empleo->redirect('index.php');
}
$stmt = $user_empleo->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);				
?>
<?php 
	if(isset($_POST['btn-borrar-empleo']))
	{
		$id=$_GET['delete_id'];
		if($user_empleo->delete_empleo($id))
		{
		 $msg="<div class='alert alert-success'>
	    	 	<strong><span class='icon-ok-sign icon-2x'></span></strong> Datos eliminados correctamente 
				</div>";
				header("refresh:1;cat-empleo.php");
		}
		else
		{
		$msg = "<div class='alert alert-danger'>
				<span class='icon-frown icon-2x'></span><strong> Error</strong> al eliminar los datos
				</div>";
		}
	}	
?>
<?php include 'inc/header.php'; ?>
<div class="container">
	<?php
	 if(isset($_GET['delete_id']))
	 {
		?>
        <?php 
		$stmt = $user_empleo->runQuery("SELECT * FROM cat_empleo WHERE idcat_empleo=:id");
		$stmt->execute(array(":id"=>$_GET['delete_id']));
		$stmt->execute();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);	
		?>
		<?php
     }
        ?>
		<?php
		if(isset($_GET['delete_id']))
			{
		?>
    <div class="row">
    	<div class="col-md-4 col-md-offset-4 ">
       		<div class="login-panel panel panel-warning">
            	<div class="panel-heading">
                <h3 class="panel-title"><span class="icon-exclamation-sign icon-2x"></span> ¿Estas seguro en eliminar este dato?</h3>
            	</div>
        		<div class="panel-body"> 
        		<div class="alert alert-dismissible alert-info">
				  	<strong>Para eliminar una categoría debes tomar en cuenta su relación con otras subcategorías.</strong>
				</div> 
        		<?php if(isset($msg)) { echo $msg; } ?>	
					<form role="form" id="registrationForm" method="post" class="form-horizontal mitad">
						<div class="form-group" hidden>
	                        <div class="col-sm-8">
							<input type="hidden" name="userID" value="<?php echo $row['userID']; ?>" />
							</div>
	                    </div>
	                    <div class="form-group">
	                        <label class="col-sm-4 control-label">Nombre</label>
	                        <div class="col-sm-8">
	                            <input type="text" value='<?php echo $row['nombre']; ?>' class="form-control" maxlength="50" disabled>
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="col-sm-4 control-label">Posición</label>
	                        <div class="col-sm-8">
	                            <input type="text" value='<?php echo $row['posicion']; ?>' class="form-control" maxlength="50" disabled>
	                        </div>
	                    </div>
	      				<div class="form-group">
	      		            <div class="col-sm-6">
	                        <button  type="submit" class="btn btn-danger btn-block" name="btn-borrar-empleo"><i class="icon-remove-circle"></i> Eliminar</button>
	                        </div>
	                        <div class="col-sm-6">
	                        <a href="cat-empleo.php" class="btn btn-success btn-block" ><i class="icon-stop"></i> Cancelar</a>
	                        </div>
	                    </div>
				    </form>
			        <?php
					}
					?>
                </div>
            </div>
		</div>
  	</div>    
</div>
<?php include 'inc/footer.php'; ?>
