<?php 
session_start();
require_once 'include/class.user.php';
$user_report = new USER();
if(!$user_report->is_logged_in())
{
  $user_report->redirect('index.php');
}
$stmt = $user_report->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<?php
if(isset($_POST['btn_eliminar_publicidad']))
{
	$idpubli = $_POST['txtidpub'];
	$stmt_edit = $user_report->runQuery('SELECT imagen FROM publicidad WHERE idpub =:idpub');
	$stmt_edit->execute(array(':idpub'=>$idpubli));
	$delete_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	unlink("../media/images_pub/".$delete_row['imagen']);

	if($user_report->del_publi($idpubli))
		{
			$msg = "<div class='alert alert-success'>
                	<button class='close' data-dismiss='alert'>&times;</button>
                	<span class='fa fa-smile-o fa-2x'></span><strong> La publicidad se eliminó correctamente.</strong>
             		</div>";
		}
		else
		{
			$msg = "<div class='alert alert-danger'>
                	<button class='close' data-dismiss='alert'>&times;</button>
                	<span class='fa fa-frown-o fa-2x'></span><strong> Ups!</strong> hubo un problema al eliminar la publicidad.
             		</div>";
		}
}
?>
<?php include 'inc/header.php'; ?>
<section class="main container">
	<div class="row">
		<section class="col-md-12">
			<div class="bs-callout"> 
				<h4><i class="fa fa-newspaper-o fa-2x"></i><strong> Publicidad</strong></h4>
				<!-- <a href="nueva-pub.php" class="btn btn-success"> <i class="fa fa-clone"></i> Nueva publicidad</a> -->
			</div>
			
			<div class="panel panel-default">
			  	<div class="panel-body">
			  	<?php if(isset($msg)){ echo $msg;} ?>
			  		<div class="table-responsive">
					   <table id="example" cellspacing="0" width="100%" class="table table-striped  table-responsive">
						  <thead>
						    <tr>
						      <th>Idpub</th>
						      <th>Idus</th>
						      <th>Usuario</th>
						      <th>Ciudad</th>
						      <th>Descripción</th>
						      <th>Imagen</th>
							  <th>Duración</th>
						      <th style="color: #337AB7;">Posición</th>
						      <th>Fecha_pub</th>
						      <th style="color: #337AB7;">Posicionar</th>
						      <th>Autorizar</th>
						      <th>Eliminar</th>
						    </tr>
						  </thead>
							  <tbody>
							  <?php 
								$stmt = $user_report->runQuery("SELECT idpub,
																usuarios.userID,
																usuarios.userNombre,
																idciudad,
																descripcion,imagen,
																duracion,posicion,
																visible,publicidad.fecha_pub
																FROM publicidad

																INNER JOIN usuarios
																ON publicidad.idusuario=usuarios.userID

																ORDER BY idpub
																DESC");

								$stmt->execute();
								while($row=$stmt->fetch(PDO::FETCH_ASSOC))	
								{
							   ?>
							    <tr>
									  <td><?php echo $row['idpub']; ?></td>
								      <td><?php echo $row['userID']; ?></td>
								      <td><?php echo $row['userNombre']; ?></td>								   
								      <td><?php echo $row['idciudad']; ?></td>
								      <td><?php echo $row['descripcion']; ?></td>
								      <td>
								      	<img src="../media/images_pub/<?php echo $row['imagen']; ?>"
									    style='width:130px; height:64px;'>
									    </td>
									  </td>
								      <td><?php echo $row['duracion']; ?></td>
								      <td><?php echo $row['posicion']; ?></td>		     
								      <td><?php echo $row['fecha_pub']; ?></td>

								    <td>
							   			<a href="posicionar-pub.php?idpublicidad=<?php print($row['idpub']); ?>" class="btn btn-primary btn-block" ><span class="fa fa-arrow-circle-up"></span></a>
						      		</td>
						      		<?php if ($row['visible']=='si'): ?>
						      			<?php 
						      			echo "<td><a href='autorizar-pub.php?idpublicidad=$row[idpub]'
									      			class='btn btn-success btn-block'>
													<span class='fa fa-check'></span>
						      							</a>
						      						</td>"; ?>
						      		<?php else:{
						      						echo "<td>
						      								<a href='autorizar-pub.php?idpublicidad=$row[idpub]'
									      					class='btn btn-warning btn-block'>
															<span class='fa fa-stop-circle'></span>
						      								</a>
						      							 </td>";
						      						} ?>
						      			
						      		<?php endif ?>
						      		<td aling="center">
							     		<button data-toggle="modal" 
					 					data-target="#<?php echo $row['idpub'];?>" class="btn btn-danger btn-block">
					 					<i class="fa fa-trash"></i>
					 				</button>
							     	</td>

							    </tr>

			<div class="modal fade" id="<?php echo $row['idpub'];?>" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          			<div class="modal-dialog modal-sm">
            			<div class="modal-content">
              				<div class="modal-header">
                				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                				<h4 class="modal-title" id="myModalLabel">Eliminar publicidad</h4>
                				
              				</div>
              			<div class="modal-body">
				 			<form method="post" action="">
                   				<div class="alert alert-dismissible alert-info">
						  			<i class="fa fa-file"></i><strong> ¿Esta seguro de eliminar este publicidad?</strong>
								</div>
								<div class="form-group" hidden="true">
			           				<div class="col-md-1">
							  			<input class="form-control" type="text" name="txtidpub" value="<?php echo $row['idpub'];?>">
							  		</div>
							  	</div>
              			</div>
              				<div class="modal-footer">
                				<button class="btn btn-block btn-success btn-md" name="btn_eliminar_publicidad"><i class="fa fa-check-square"></i> Si
                				</button>
				 				<button type="button" class="btn btn-block btn-danger btn-md" data-dismiss="modal"><i class="fa fa-stop"></i> No
				 				</button>
							</form>
              				</div>
            			</div>
          			</div>
        		</div>
							    <?php 
								}
							     ?>
							  </tbody>
					   </table>
					</div>
			  	</div>
			</div>
		</section>
	</div>
</section>
<?php include 'inc/footer.php'; ?>
