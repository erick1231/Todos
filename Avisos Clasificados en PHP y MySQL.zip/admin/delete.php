<?php  
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('index.php');
}

$stmt = $user_ads->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);				
?>
<?php 
	if(isset($_POST['btn_borrar']))
	{
		$id=$_GET['delete_id'];
		$user_ads->delete($id);
		 $msg="<div class='alert alert-success'>
	    	 	<span class='fa fa-check-circle fa-2x'></span><strong> Los datos se borraron correctamente.</strong>
				</div>";
		header("refresh:2;usuarios.php");
	}
	
?>

<?php include 'inc/header.php'; ?>
<div class="container">
<!-- mensajes de estado -->
	<?php
	 	if(isset($_GET['delete_id']))
	 {
	?>
        <?php 
		$stmt = $user_ads->runQuery("SELECT * FROM usuarios WHERE userID=:id");
		$stmt->execute(array(":id"=>$_GET['delete_id']));
		$stmt->execute();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);	
		?>
		<?php
     }
        ?>
		<?php
			if(isset($_GET['delete_id']))
			{
		?>
    <div class="row">
    	<div class="col-md-4 col-md-offset-4 ">
       		<div class="login-panel panel panel-warning">
            	<div class="panel-heading">
                <h3 class="panel-title"><span class="icon-exclamation-sign icon-2x"></span> Estas borrando usuarios</h3>
            	</div>
        		<div class="panel-body">
                <div class='alert alert-danger'>
                    <i class="fa fa-search fa-2x"></i><strong> Verifica los datos antes de borrar</strong>
                </div>  
        		<?php if(isset($msg)) { echo $msg; } ?>
				<form role="form" id="registrationForm" method="post" class="form-horizontal mitad">
					<div class="form-group" hidden>
                        <div class="col-sm-8">
						<input type="hidden" name="userID" value="<?php echo $row['userID']; ?>" />
						</div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Nombres</label>
                        <div class="col-sm-8">
                            <input type="text" value='<?php echo $row['userNombre']; ?>' class="form-control" maxlength="50" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Apellido</label>
                        <div class="col-sm-8">
                            <input type="text" value='<?php echo $row['userApell']; ?>' class="form-control" maxlength="50" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Teléfono</label>
                        <div class="col-sm-8">
                            <input type="text" value='<?php echo $row['userTele']; ?>' class="form-control" maxlength="50" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Email</label>
                        <div class="col-sm-8">
                            <input type="text" value='<?php echo $row['userEmail']; ?>' class="form-control" maxlength="50" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Fecha</label>
                        <div class="col-sm-8">
                            <input type="text" value='<?php echo $row['fechaIn'] ?>' class="form-control" maxlength="50" disabled>
                        </div>
                    </div>
      				<div class="form-group">
      		            <div class="col-sm-6">
                        <button  type="submit" class="btn btn-danger btn-block" name="btn_borrar"><i class="icon-remove-circle"></i> Eliminar</button>
                        </div>
                        <div class="col-sm-6">
                        <a href="usuarios.php" class="btn btn-success btn-block" ><i class="icon-stop"></i> Cancelar</a>
                        </div>
                    </div>
			    </form>
			        <?php
						}
					else
						{
					?>
					  	<a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; Back to index</a>
					<?php
						}
					?>
                     <hr>
                </div>
            </div>
		</div>
  	</div>   
</div>
<?php include 'inc/footer.php'; ?>
