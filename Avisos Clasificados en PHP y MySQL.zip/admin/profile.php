<?php
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('index.php');
}

$stmt = $user_ads->runQuery("SELECT * FROM centraluser WHERE userID=:id LIMIT 1");
$stmt->execute(array(":id"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
extract($row);

if(isset($_POST['btn-pass']))
{
	$id = $_POST['userID'];
	$upassword = $_POST['txtcontra'];

	if ($user_ads->uppass($id,$upassword))
		{

			$msg = "<div class='alert alert-success'>
					<button type='button' class='close' data-dismiss='alert'>&times;</button>
					La<strong> contraseña</strong> se actualizó correctamente.
				</div>";
		}
	else
		{
			$msg =  "<div class='alert alert-danger'>
				<strong>Error</strong> al actualizar la contraseña, intente mas tarde.
				</div>";
		}
 }
if(isset($_POST['userID']))
{
	$id = $_POST['userID'];
	extract($user_ads->getID($id));	
}
?>
<?php include 'inc/header.php';?>
<section class="main container">
	<div class="row">
		<section class="col-md-4  col-md-offset-4">
		<div class="panel panel-info">
			<div class="panel-heading">
				<h3 class="panel-title"><i class="fa fa-key"></i> Nueva contraseña</h3>
			</div>
			<div class="panel-body">
				<form role="form" id="registrationForm" method="post" class="form-horizontal mitad" ><?php
					if(isset($msg))
						{
						echo $msg;
						}
					?>
		 			<?php
                    	if (isset($_GET['error'])) 
                    	{
                    ?>
	                        <div class='alert alert-danger'>
	                            <button class='close' data-dismiss='alert'>&times;</button>
	                            <strong>Datos incorrectos</strong>    
	                        </div>
                    <?php    
                        }
                    ?>
					<div class="form-group" hidden>
						<label class="col-md-4 control-label">id</label>
							<div class="col-md-8">
								<input type="" name="userID" class="form-control" maxlength="50" value="<?php echo $userID; ?>" />
							</div>
					</div>
					<div class="form-group">
						<label class="col-md-4 control-label">Contraseña</label>
						<div class="col-md-8">
							<input type="text" name="txtcontra"  class="form-control" maxlength="50">
						</div>	
					</div>
					<div class="form-group">
						<label class="col-md-4 control-label">Confirmar contraseña</label>
						<div class="col-md-8">
							<input type="text" name="txtconfirmar" class="form-control" maxlength="50">
						</div>	
					</div>
					<div class="form-group">
						<div class="col-md-12">
							<button type="submit" class="btn btn-primary btn-block" name="btn-pass"><i class="fa fa-check"></i> Actualizar contraseña</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		</section>
	</div>
</section>
<?php include 'inc/footer.php'; ?>
