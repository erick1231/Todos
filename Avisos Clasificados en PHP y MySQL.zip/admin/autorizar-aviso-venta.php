<?php 
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('index.php');
}
$stmt = $user_ads->runQuery("SELECT * FROM centraluser WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSessionA']));
$row = $stmt->fetch(PDO::FETCH_ASSOC); ?>

<?php
$get_idaviso_venta = $_GET['idaviso_venta'];			
$stmt = $user_ads->runQuery("SELECT * FROM aviso_venta WHERE idaviso_venta='$get_idaviso_venta'");
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);
	if($row['visible']=='si') 
	{
		$sql = 'UPDATE aviso_venta SET visible=?
		WHERE idaviso_venta=?';
		$this_status = "no";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idaviso_venta));
		header("location: av-venta.php");
	}
	else
	{
		$sql = 'UPDATE aviso_venta SET visible=?
		WHERE idaviso_venta=?';
		$this_status = "si";
		$q = $user_ads->runQuery($sql);
		$q->execute(array($this_status, $get_idaviso_venta));
		header("location: av-venta.php");
	} 
?>

