<?php
/**
 * file: class.user.php
 * @author anthoncode
 * @link https://anthoncode.com
 */

require_once 'admin/config/config.php';

class USER
{
	private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbconnection();
		$this->conn = $db;
		if (!$database->dbConnection()) {
    	header('location:error-tecnico.html');
		}
	}

	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}

	public function lasdID()
	{
		$stmt = $this->conn->lastInsertID();
		return $stmt;
	}
	public function register($unombre,$apell,$tele,$email,$upass,$code,$fecha)
	{
		try
		{
			$pass_cif =password_hash($upass, PASSWORD_DEFAULT); 
			$contra =$pass_cif;
			$stmt = $this->conn->prepare("INSERT INTO usuarios(userNombre,userApell,userTele,userEmail,userContra,codeAct,fechaIn)
														VALUES(:user_nombre, :user_apell, :user_telefono, :user_email, :user_contra, :code_Act, :fecha_in)");
			$stmt->bindparam(":user_nombre",$unombre);
			$stmt->bindparam(":user_apell",$apell);
			$stmt->bindparam(":user_telefono",$tele);
			$stmt->bindparam(":user_email",$email);
			$stmt->bindparam(":user_contra",$contra);
			$stmt->bindparam(":code_Act",$code);
			$stmt->bindparam(":fecha_in",$fecha);

			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	}


	public function getID($id)
	{
		$stmt = $this->conn->prepare("SELECT * FROM usuarios WHERE userID=:id");
		$stmt->execute(array(":id"=>$id));
		$editRow=$stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	}

	public function update($id,$Unombre,$Uapellido,$Utelefono)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE usuarios SET userNombre=:Unombre,
												userApell=:Uapellido,
												userTele=:Utelefono WHERE userID=:id");
		$stmt->bindparam(":Unombre",$Unombre);
		$stmt->bindparam(":Uapellido",$Uapellido);
		$stmt->bindparam(":Utelefono",$Utelefono);
		$stmt->bindparam(":id",$id);
		$stmt->execute();


			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}

/*uppass esta dirigido para perfil.php actualizar contraseña*/
public function uppass($id,$upassword)
	{
		try
		{
			$Upass_cif = password_hash($upassword, PASSWORD_DEFAULT); 
			$Ucontra = $Upass_cif;
			$stmt = $this->conn->prepare("UPDATE usuarios SET userContra=:Ucontra 
											WHERE userID=:id");
		$stmt->bindparam(":Ucontra",$Ucontra);
		$stmt->bindparam(":id",$id);
		$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}

	/*publicar aviso empleo*/
	public function publicar_aviso_empleo($id_usuario,$id_ciudad,$id_categoria,$eTitulo,$eDescripcion,$eFecha_pub,$eFecha_vigencia,$visible)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO aviso_empleo(id_usuario,id_ciudad,
														id_categoria,titulo,descripcion,
														fecha_pub,fecha_vigen,visible)
														VALUES(:id_usuario, :id_ciudad, :id_categoria, :eTitulo, :eDescripcion, :eFecha_pub, :eFecha_vigencia, :visible)");
			$stmt->bindparam(":id_usuario",$id_usuario);
			$stmt->bindparam(":id_ciudad",$id_ciudad);
			$stmt->bindparam(":id_categoria",$id_categoria);
			$stmt->bindparam(":eTitulo",$eTitulo);
			$stmt->bindparam(":eDescripcion",$eDescripcion);
			$stmt->bindparam(":eFecha_pub",$eFecha_pub);
			$stmt->bindparam(":eFecha_vigencia",$eFecha_vigencia);
			$stmt->bindparam(":visible",$visible);

			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	}
	
	/*publicar aviso venta*/
	public function publicar_aviso_venta($id_usuario,$id_ciudad,$id_cat_venta,$eTitulo,
		$eDescripcion,$imgFoto,$ePrecio,$eFecha_pub,$visible)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO aviso_venta(id_usuario,id_ciudad,
														id_cat_venta,titulo,descripcion,foto,precio,
														fecha_pub,visible)
														VALUES(:id_usuario, :id_ciudad, :id_cat_venta, :eTitulo, :eDescripcion, :imgFoto, :ePrecio, :eFecha_pub, :visible)");
			$stmt->bindparam(":id_usuario",$id_usuario);
			$stmt->bindparam(":id_ciudad",$id_ciudad);
			$stmt->bindparam(":id_cat_venta",$id_cat_venta);
			$stmt->bindparam(":eTitulo",$eTitulo);
			$stmt->bindparam(":eDescripcion",$eDescripcion);
			$stmt->bindparam(":imgFoto",$imgFoto);
			$stmt->bindparam(":ePrecio",$ePrecio);
			$stmt->bindparam(":eFecha_pub",$eFecha_pub);
			$stmt->bindparam(":visible",$visible);
			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	}
	/*publicar aviso servicio*/
	public function publicar_aviso_servicio($id_usuario,$id_ciudad,$id_cat_serv,$eTitulo,$eDescripcion,$eFecha_pub,$visible)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO aviso_servicio(id_usuario,id_ciudad,
														id_cat_serv,titulo,descripcion,
														fecha_pub,visible)
														VALUES(:id_usuario, :id_ciudad, :id_cat_serv, :eTitulo, :eDescripcion, :eFecha_pub, :visible)");
			$stmt->bindparam(":id_usuario",$id_usuario);
			$stmt->bindparam(":id_ciudad",$id_ciudad);
			$stmt->bindparam(":id_cat_serv",$id_cat_serv);
			$stmt->bindparam(":eTitulo",$eTitulo);
			$stmt->bindparam(":eDescripcion",$eDescripcion);
			$stmt->bindparam(":eFecha_pub",$eFecha_pub);
			$stmt->bindparam(":visible",$visible);

			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	}
	/*publicar aviso compra*/
	public function publicar_aviso_compra($id_usuario,$id_ciudad,$id_cat_compra,$eTitulo,$eDescripcion,$eFecha_pub,$visible)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO aviso_compra(id_usuario,id_ciudad,
														id_cat_compra,titulo,descripcion,
														fecha_pub,visible)
														VALUES(:id_usuario, :id_ciudad, :id_cat_compra, :eTitulo, :eDescripcion, :eFecha_pub, :visible)");
			$stmt->bindparam(":id_usuario",$id_usuario);
			$stmt->bindparam(":id_ciudad",$id_ciudad);
			$stmt->bindparam(":id_cat_compra",$id_cat_compra);
			$stmt->bindparam(":eTitulo",$eTitulo);
			$stmt->bindparam(":eDescripcion",$eDescripcion);
			$stmt->bindparam(":eFecha_pub",$eFecha_pub);
			$stmt->bindparam(":visible",$visible);

			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	}
	//mis avisos avisos de usuario
	//actualizar aviso empleo
	public function act_av_emp($idemp,$ciudad,$empleo,$titulo,$descripcion,$fecha_pub,$fecha_vigen)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE aviso_empleo SET id_ciudad=:ciudad,
												id_categoria=:empleo,
												titulo=:titulo,
												descripcion=:descripcion,
												fecha_pub=:fecha_pub,
												fecha_vigen=:fecha_vigen
												WHERE idaviso_empleo=:idemp");
		$stmt->bindparam(":ciudad",$ciudad);
		$stmt->bindparam(":empleo",$empleo);
		$stmt->bindparam(":titulo",$titulo);
		$stmt->bindparam(":descripcion",$descripcion);
		$stmt->bindparam(":fecha_pub",$fecha_pub);
		$stmt->bindparam(":fecha_vigen",$fecha_vigen);
		$stmt->bindparam(":idemp",$idemp);
		$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}
	//eliminar aviso empleo
	public function del_av_emp($idemp)
	{
		$stmt = $this->conn->prepare("DELETE FROM aviso_empleo WHERE idaviso_empleo=:idemp");
		$stmt->bindparam(":idemp",$idemp);
		$stmt->execute();
		return true;
	} 
	//actualizar aviso venta
	public function act_av_vent($idvent,$ciudad,$venta,$titulo,$descripcion,$imgFoto,$fecha_pub)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE aviso_venta SET id_ciudad=:ciudad,
												id_cat_venta=:venta,
												titulo=:titulo,
												descripcion=:descripcion,
												foto=:imgFoto,
												fecha_pub=:fecha_pub
												WHERE idaviso_venta=:idvent");
		$stmt->bindparam(":ciudad",$ciudad);
		$stmt->bindparam(":venta",$venta);
		$stmt->bindparam(":titulo",$titulo);
		$stmt->bindparam(":descripcion",$descripcion);
		$stmt->bindparam(":imgFoto",$imgFoto);
		$stmt->bindparam(":fecha_pub",$fecha_pub);
		$stmt->bindparam(":idvent",$idvent);
		$stmt->execute();
		
		return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}
	//eliminar aviso venta
	public function del_av_vent($idvent)
	{
		$stmt = $this->conn->prepare("DELETE FROM aviso_venta WHERE idaviso_venta=:idvent");
		$stmt->bindparam(":idvent",$idvent);
		$stmt->execute();
		return true;
	} 
	//editar aviso servicio
	public function act_av_serv($idserv,$ciudad,$servicio,$titulo,$descripcion,$fecha_pub)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE aviso_servicio SET id_ciudad=:ciudad,
												id_cat_serv=:servicio,
												titulo=:titulo,
												descripcion=:descripcion,
												fecha_pub=:fecha_pub
												WHERE idaviso_servicio=:idserv");
		$stmt->bindparam(":ciudad",$ciudad);
		$stmt->bindparam(":servicio",$servicio);
		$stmt->bindparam(":titulo",$titulo);
		$stmt->bindparam(":descripcion",$descripcion);
		$stmt->bindparam(":fecha_pub",$fecha_pub);
		$stmt->bindparam(":idserv",$idserv);
		$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}
	//eliminar aviso servicio
	public function del_av_serv($idserv)
	{
		$stmt = $this->conn->prepare("DELETE FROM aviso_servicio WHERE idaviso_servicio=:idserv");
		$stmt->bindparam(":idserv",$idserv);
		$stmt->execute();
		return true;
	} 



	//editar aviso compra
	public function act_av_compra($idcomp,$ciudad,$compra,$titulo,$descripcion,$fecha_pub)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE aviso_compra SET id_ciudad=:ciudad,
												id_cat_compra=:compra,
												titulo=:titulo,
												descripcion=:descripcion,
												fecha_pub=:fecha_pub
												WHERE idaviso_compra=:idcomp");
		$stmt->bindparam(":ciudad",$ciudad);
		$stmt->bindparam(":compra",$compra);
		$stmt->bindparam(":titulo",$titulo);
		$stmt->bindparam(":descripcion",$descripcion);
		$stmt->bindparam(":fecha_pub",$fecha_pub);
		$stmt->bindparam(":idcomp",$idcomp);
		$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
			return false;
		}
	}
	//eliminar aviso compra
	public function del_av_compra($idcomp)
	{
		$stmt = $this->conn->prepare("DELETE FROM aviso_compra WHERE idaviso_compra=:idcomp");
		$stmt->bindparam(":idcomp",$idcomp);
		$stmt->execute();
		return true;
	} 

	//promocionar videos
	public function promocionar_video($url_video,$descripcion,$visible,$posicion,$fecha_pub)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO video_url(url,
														descripcion,visible,posicion,
														fecha_pub)
														VALUES (:url_video, :descripcion, 
														:visible, :posicion, :fecha_pub)");
			$stmt->bindparam(":url_video",$url_video);
			$stmt->bindparam(":descripcion",$descripcion);
			$stmt->bindparam(":visible",$visible);
			$stmt->bindparam(":posicion",$posicion);
			$stmt->bindparam(":fecha_pub",$fecha_pub);
			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	}

	/*publicidad*/
	public function subir_publicidad($id_usuario,$id_ciudad,$eDescripcion,$imgFoto,$duracion,$visible,$posicion,$eFecha_pub)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO publicidad(idusuario,
														idciudad,descripcion,
														imagen,duracion,
														visible,posicion,fecha_pub)
														VALUES (:id_usuario, :id_ciudad, 
														:eDescripcion, :imgFoto, :duracion, 
														:visible, :posicion, :eFecha_pub)");
			$stmt->bindparam(":id_usuario",$id_usuario);
			$stmt->bindparam(":id_ciudad",$id_ciudad);
			$stmt->bindparam(":eDescripcion",$eDescripcion);
			$stmt->bindparam(":imgFoto",$imgFoto);
			$stmt->bindparam(":duracion",$duracion);
			$stmt->bindparam(":visible",$visible);			
			$stmt->bindparam(":posicion",$posicion);
			$stmt->bindparam(":eFecha_pub",$eFecha_pub);

			$stmt->execute();
			return $stmt;		
		}
		catch(PDOException $ex)
		{
		echo $ex->getMessage();
		}
	} 


	public function limpiarDatos($datos){
		$datos = filter_var($datos, FILTER_SANITIZE_STRING); //elimina etiquetas html
		$datos = trim($datos); //elimina espacios vacios
		//$datos = htmlentities($datos,ENT_QUOTES,"UTF-8"); //caracteres latinos
		return $datos;
	}

	public function limpiarCorreo($dat_correo){
		$dat_correo = filter_var($dat_correo, FILTER_SANITIZE_EMAIL);
		return $dat_correo;
	}

	/*calcula tiempo de transcurrido de la publicacion*/
	public function obtener_aviso_empleo($idaviso_empleo)
	{
		$stmt = $this->conn->prepare("SELECT * FROM aviso_empleo WHERE idaviso_empleo=:id");
		$stmt->execute(array(":id"=>$id));
    	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	}
	/*para que funcione la fecha de publicacion: cambiar php.ini la zona horaria
	o asignar zona horaria mediante php*/
	public function TimeAgo ($oldTime, $newTime) {
	$timeCalc = strtotime($newTime) - strtotime($oldTime);
	if ($timeCalc >= (60*60*24*30*12*2)){
    $timeCalc = intval($timeCalc/60/60/24/30/12) . " años";
    }else if ($timeCalc >= (60*60*24*30*12)){
        $timeCalc = intval($timeCalc/60/60/24/30/12) . " año";
    }else if ($timeCalc >= (60*60*24*30*2)){
        $timeCalc = intval($timeCalc/60/60/24/30) . " meses";
    }else if ($timeCalc >= (60*60*24*30)){
        $timeCalc = intval($timeCalc/60/60/24/30) . " mes";
    }else if ($timeCalc >= (60*60*24*2)){
        $timeCalc = intval($timeCalc/60/60/24) . " dias";
    }else if ($timeCalc >= (60*60*24)){
        $timeCalc = " 1 dia";
    }else if ($timeCalc >= (60*60*2)){
        $timeCalc = intval($timeCalc/60/60) . " horas";
    }else if ($timeCalc >= (60*60)){
        $timeCalc = intval($timeCalc/60/60) . " hora";
    }else if ($timeCalc >= 60*2){
        $timeCalc = intval($timeCalc/60) . " minutos";
    }else if ($timeCalc >= 60){
        $timeCalc = intval($timeCalc/60) . " minuto";
    }else if ($timeCalc > 0){
        $timeCalc .= " segundos";
    }
	return $timeCalc;
	}

	/*convierte la fecha 2000-02-01 a 01-02-2000 y viceversa*/
	public function normaliza_date($fecha_conv)
	{
		if(!empty($fecha_conv)){
			$var = explode('/', str_replace('-','/', $fecha_conv));
			return
			"$var[2]/$var[1]/$var[0]";
		}
	}

	public function normaliza_date_time($fecha_conv)
	{
		if(!empty($fecha_conv)){
			$test=$fecha_conv;
			echo date('d/m/Y H:i:s',strtotime($test));
		}
	}

	public function reportar_aviso_empleo($id_usuario,$id_de_aviso,$motivo,$fecha_pub){
			{
			try
			{
				$stmt = $this->conn->prepare("INSERT INTO reportes_empleo(id_usuario,id_aviso,motivo,fecha_pub)
															VALUES(:id_usuario, :id_de_aviso, :motivo, :fecha_pub)");
				
				$stmt->bindparam(":id_usuario",$id_usuario);
				$stmt->bindparam(":id_de_aviso",$id_de_aviso);
				$stmt->bindparam(":motivo",$motivo);
				$stmt->bindparam(":fecha_pub",$fecha_pub);
				$stmt->execute();
				return $stmt;	
			}
			catch(PDOException $ex)
			{
			echo $ex->getMessage();
			}
		}
	}

	public function reportar_aviso_venta($id_usuario,$id_de_aviso,$motivo,$fecha_pub){
			{
			try
			{
				$stmt = $this->conn->prepare("INSERT INTO reportes_venta(id_usuario,id_aviso,motivo,fecha_pub)
															VALUES(:id_usuario, :id_de_aviso, :motivo, :fecha_pub)");
				
				$stmt->bindparam(":id_usuario",$id_usuario);
				$stmt->bindparam(":id_de_aviso",$id_de_aviso);
				$stmt->bindparam(":motivo",$motivo);
				$stmt->bindparam(":fecha_pub",$fecha_pub);
				$stmt->execute();
				return $stmt;	
			}
			catch(PDOException $ex)
			{
			echo $ex->getMessage();
			}
		}
	}

	public function reportar_aviso_servicio($id_usuario,$id_de_aviso,$motivo,$fecha_pub){
			{
			try
			{
				$stmt = $this->conn->prepare("INSERT INTO reportes_servicio(id_usuario,id_aviso,motivo,fecha_pub)
															VALUES(:id_usuario, :id_de_aviso, :motivo, :fecha_pub)");
				
				$stmt->bindparam(":id_usuario",$id_usuario);
				$stmt->bindparam(":id_de_aviso",$id_de_aviso);
				$stmt->bindparam(":motivo",$motivo);
				$stmt->bindparam(":fecha_pub",$fecha_pub);
				$stmt->execute();
				return $stmt;	
			}
			catch(PDOException $ex)
			{
			echo $ex->getMessage();
			}
		}
	}

	public function reportar_aviso_compra($id_usuario,$id_de_aviso,$motivo,$fecha_pub){
			{
			try
			{
				$stmt = $this->conn->prepare("INSERT INTO reportes_compra(id_usuario,id_aviso,motivo,fecha_pub)
															VALUES(:id_usuario, :id_de_aviso, :motivo, :fecha_pub)");
				
				$stmt->bindparam(":id_usuario",$id_usuario);
				$stmt->bindparam(":id_de_aviso",$id_de_aviso);
				$stmt->bindparam(":motivo",$motivo);
				$stmt->bindparam(":fecha_pub",$fecha_pub);
				$stmt->execute();
				return $stmt;	
			}
			catch(PDOException $ex)
			{
			echo $ex->getMessage();
			}
		}
	}

	public function login($email,$upass)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT * FROM usuarios WHERE userEmail=:email_id");
			$stmt->execute(array(":email_id"=>$email));
			$userRow=$stmt->fetch(PDO::FETCH_ASSOC);

			if($stmt->rowCount() == 1)
			{
				if($userRow['userEstado']=="Y")/*C*/
					{
						if($userRow['userAcceso']=="Y")/*B*/
							{
								if(password_verify($upass, $userRow['userContra']))/*A*/
								{
									$_SESSION['userSession'] = $userRow['userID'];
									return true;
								}
								else
								{
									header("location: login.php?error");
									exit;
								}/*A*/
							}

						else
						{
							header("location: login.php?accesodenegado");
							exit;
						}/*B*/
					}

				else
				{
					header("location: login.php?inactive");
					exit;
				}	/*C*/		
			}

		else
		{
			header("location: login.php?error");
			exit;
		}/*D*/
	}
	catch(PDOException $ex)
	{
		echo $ex->getMessage();
	}
}
	public function is_logged_in()
	{
		if(isset($_SESSION['userSession']))
		{
			return true;
		}
	}

	public function redirect($url)
	{
		header("location: $url");
	}

	public function logout()
	{
		session_destroy();
		$_SESSION['userSession'] = false;
	}

	//EMAIL*************************************
	function send_mail($email,$message,$subject)
	{
	require_once('mailer/class.phpmailer.php');
		$mail = new PHPMailer();
		$mail->IsSMTP(); 
		$mail->SMTPDebug  = 0;                     
		$mail->SMTPAuth   = true;                  
		$mail->SMTPSecure = "SSL";                 
		$mail->Host       = "smtp.mailtrap.io";      
		$mail->Port       = 465;             
		$mail->AddAddress($email);
		$mail->Username = "df2369f4b01fbd";  
		$mail->Password = "0cde408b3e90b7";            
		$mail->SetFrom("anthoncode-a46ae6@inbox.mailtrap.io","4avisos");
		$mail->AddReplyTo("anthoncode-a46ae6@inbox.mailtrap.io","4avisos");
		$mail->CharSet = "UTF-8";
		$mail->Subject = $subject;
		$mail->MsgHTML($message);
		$mail->Send();

	}
	//*******************************************
}

?>
