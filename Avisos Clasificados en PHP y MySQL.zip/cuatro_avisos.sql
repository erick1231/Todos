-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.14-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando estructura para tabla cuatro_avisos.aviso_compra
CREATE TABLE IF NOT EXISTS `aviso_compra` (
  `idaviso_compra` bigint(255) NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(255) DEFAULT NULL,
  `id_ciudad` bigint(255) DEFAULT NULL,
  `id_cat_compra` bigint(255) DEFAULT NULL,
  `titulo` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_pub` datetime DEFAULT NULL,
  `visible` varchar(2) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idaviso_compra`),
  KEY `usuario_en_compra_idx` (`id_usuario`),
  KEY `ciudad_en_compra_idx` (`id_ciudad`),
  KEY `cat_comp_en_compra_idx` (`id_cat_compra`),
  CONSTRAINT `cat_comp_en_compra` FOREIGN KEY (`id_cat_compra`) REFERENCES `cat_compra` (`idcat_compra`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `ciudad_en_compra` FOREIGN KEY (`id_ciudad`) REFERENCES `cat_ciudad` (`idCiudad`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `usuario_en_compra` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`userID`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.aviso_compra: ~9 rows (aproximadamente)
/*!40000 ALTER TABLE `aviso_compra` DISABLE KEYS */;
INSERT INTO `aviso_compra` (`idaviso_compra`, `id_usuario`, `id_ciudad`, `id_cat_compra`, `titulo`, `descripcion`, `fecha_pub`, `visible`) VALUES
	(2, 37, 2, 8, 'Compro historietas', 'Deben estar en buen estado por favor contactame al numero: 4234234242', '2017-08-23 16:19:33', 'si'),
	(3, 37, 2, 7, 'compro los libos de la real academia', 'si cuentas con estos libros contactate conmigo al 45454644654', '2017-07-09 00:00:00', 'si'),
	(4, 37, 3, 10, 'vendo audifonos de colección', 'si alquien cuenta con estos audifonos llamar al 4546544', '2017-07-09 00:00:00', 'si'),
	(5, 37, 3, 11, 'compro celulares', 'Si tienes un celular lo compro mi num es: 32423423 estoy disponible solo los sabado', '2017-07-09 00:00:00', 'si'),
	(6, 37, 4, 6, 'compro las mejores motos de coleccion', 'contactarse al 7879879779', '2017-07-09 00:00:00', 'si'),
	(7, 37, 5, 1, 'busco los libros de elvis', 'si tienes todos los discos llamar al 1748798779', '2017-07-09 00:00:00', 'si'),
	(8, 37, 6, 5, 'compro 3 sillas', 'las sillas deben estar en buen estado mejor si es de madera original llamar al siguiente numero:8798798797898', '2017-07-09 00:00:00', 'si'),
	(9, 37, 7, 2, 'compro una vagoneta ', 'contactarse al siguiente numero: 67987987446', '2017-07-09 00:00:00', 'si'),
	(11, 37, 1, 1, 'las mejores motos', 'compro solo las mejores motos: 7878789781111					        ', '2017-08-07 13:53:48', 'si');
/*!40000 ALTER TABLE `aviso_compra` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.aviso_empleo
CREATE TABLE IF NOT EXISTS `aviso_empleo` (
  `idaviso_empleo` bigint(255) NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(255) DEFAULT NULL,
  `id_ciudad` bigint(255) DEFAULT NULL,
  `id_categoria` bigint(255) DEFAULT NULL,
  `titulo` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_pub` datetime DEFAULT NULL,
  `fecha_vigen` date DEFAULT NULL,
  `visible` varchar(2) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idaviso_empleo`),
  KEY `usuario_en_empleo_idx` (`id_usuario`),
  KEY `ciudad_en_empleo_idx` (`id_ciudad`),
  KEY `empleo_en_avempleo_idx` (`id_categoria`),
  CONSTRAINT `ciudad_en_avempleo` FOREIGN KEY (`id_ciudad`) REFERENCES `cat_ciudad` (`idCiudad`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `empleo_en_avempleo` FOREIGN KEY (`id_categoria`) REFERENCES `cat_empleo` (`idcat_empleo`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `usuario_en_avempleo` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`userID`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.aviso_empleo: ~25 rows (aproximadamente)
/*!40000 ALTER TABLE `aviso_empleo` DISABLE KEYS */;
INSERT INTO `aviso_empleo` (`idaviso_empleo`, `id_usuario`, `id_ciudad`, `id_categoria`, `titulo`, `descripcion`, `fecha_pub`, `fecha_vigen`, `visible`) VALUES
	(5, 37, 4, 33, 'necesito ingeniero en alimentos', 'En la ficha Insertar, incluyen elementos dise&ntilde;ados para coordinar con la apariencia general del documento. Puede utilizar estas galer&iacute;as para insertar tablas, encabezados, pies de p&aacute;gina, listas, portadas y otros bloques de creaci&oacute;n del documento. Cuando crea im&aacute;genes, organigramas o diagramas, llamar al 7987978798', '2017-08-23 16:44:00', '2017-08-23', 'si'),
	(6, 37, 2, 34, 'Necesito guitarrista', 'para el conservatorio de musica llamar al 7473845787578', '2017-07-09 03:00:00', '2017-07-04', 'si'),
	(8, 37, 3, 25, 'Necesito profesores de secundaria', 'para mas informacion sobre este trabajo llamar a los siguientes numeros, recoradar que el solicitante debe tener los documentos al dia par amas informacion llamar al 7878978798779', '2017-07-09 03:00:00', '2017-07-06', 'si'),
	(9, 37, 4, 23, 'Necesito choferes para carga', 'los interesados deben contar con la licencia de condicir para mas informacion contactarse con mario bross', '2017-07-09 04:00:00', '2017-07-14', 'si'),
	(10, 37, 6, 26, 'Se necesita reparador de refrigerador ', 'por favor llamar al siguinete numero: 548798656', '2017-07-09 06:00:00', '2017-07-29', 'si'),
	(11, 37, 7, 40, 'traductores de italiano', 'los interesados deben dominar el idioma para mas informacion llamar al siguinete numero 45464654645', '2017-07-09 11:00:00', '2017-09-15', 'si'),
	(12, 37, 8, 41, 'niñera para cuidar niños', 'para mas informacion llamar a los siguientes numeros, las intersadas deben tener 4 aÃ±os de experiencia llamar a los siguientes numeros: 454654544 y al 789779878', '2017-07-09 10:00:00', '2017-08-17', 'si'),
	(13, 37, 9, 33, 'ingenieros industriales ', 'para la ciudad de pasadena los intersados deben presentar sus documentos al siguiente correo:\r\nlasempresasgrandes@gmail.com o contactarse al suiguiente numero: 87987987987 y llamar sol en horarios ', '2017-07-09 07:00:00', '2017-08-29', 'si'),
	(15, 37, 3, 35, 'Se necesita diseñador grafico', 'llamar al5345435', '2017-07-09 03:01:00', '2017-07-27', 'si'),
	(16, 37, 2, 22, 'se necesita electricista ', 'para mas informacion llamar al 84455454', '2017-07-08 23:58:00', '2017-10-11', 'si'),
	(17, 37, 1, 27, 'necesito chef', 'para el Ã¡rea de gastronomia llamar al 122123113', '2017-08-19 15:49:37', '2017-08-16', 'si'),
	(18, 37, 5, 36, 'profecional en el area de publicidad', 'para mas informacion llamar al siguinete numero 33543534534543', '2017-07-08 21:00:00', '2017-07-08', 'si'),
	(19, 37, 1, 29, 'necesitamos pintores', 'calle las aguilas 232356', '2017-07-14 07:00:00', '2017-07-29', 'si'),
	(20, 37, 1, 29, 'super pintores', 'llamar al 4234235425', '2017-07-14 09:00:00', '2017-07-23', 'si'),
	(21, 37, 1, 27, 'el mejor chef que exista ', 'llamar al 75675675675', '2017-07-14 04:01:00', '2017-08-25', 'si'),
	(23, 37, 1, 29, 'veloz pinotor veloz', 'venir a la calle caballo loco', '2017-07-16 02:00:00', '2017-07-29', 'si'),
	(24, 37, 1, 33, 'aqui ing', 'necesito ingenieros', '2017-07-16 03:00:00', '2017-07-28', 'si'),
	(25, 37, 1, 21, 'Urgente plomero', 'necesito plomero de maxima experiencia para reparar daÃ±os colosales de gigantes tuberias buscamos a 5 personas de esa capacidad para realizar dicho trabajo para mas informacion contcatrase a los sigu', '2017-07-17 02:00:00', '2017-07-23', 'si'),
	(26, 37, 1, 29, 'pinta pinta ', 'se necesita a los mejores pintores del mundo para pintar la monaliza en una pared de 500km * 200 km para mas informacion vitar la pagina web elpintorloco.com, todos los pintores deben contar con sus s', '2017-07-17 02:00:00', '2017-07-23', 'si'),
	(27, 37, 1, 29, 'pintor volador', 'necesito un pintor volador que sepa pintar en el aire a 5000 metros sobre el nivel del mar.', '2017-07-18 04:24:04', '2017-07-29', 'si'),
	(28, 37, 1, 29, 'pintor de fama', 'requiero pintor famoso llamar al 45464464646546', '2017-07-18 09:25:05', '2017-07-30', 'si'),
	(29, 37, 1, 29, 'brocha rapida ', 'pintor que pinte en minutos llamar al 46546445 este pintor debe tener la capacidad de pintar 3 paredes en 45 segundos no es broma, traer sus propias brochas para realziar estos pintados.', '2017-07-19 12:00:00', '2017-07-29', 'si'),
	(31, 37, 1, 27, 'chef master', 'necesitamos el mejor chef llamar al 454545445', '2017-07-25 17:55:06', '2017-07-27', 'si'),
	(65, 42, 7, 21, 'plomero para trabajar', 'busco plomero para trinidad mas informaciob al 43534534', '2017-10-06 16:43:51', '2017-10-06', 'si');
/*!40000 ALTER TABLE `aviso_empleo` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.aviso_servicio
CREATE TABLE IF NOT EXISTS `aviso_servicio` (
  `idaviso_servicio` bigint(255) NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(255) DEFAULT NULL,
  `id_ciudad` bigint(255) DEFAULT NULL,
  `id_cat_serv` bigint(255) DEFAULT NULL,
  `titulo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_pub` datetime DEFAULT NULL,
  `visible` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idaviso_servicio`),
  KEY `usuario_en_serv_idx` (`id_usuario`),
  KEY `ciudad_en_serv_idx` (`id_ciudad`),
  KEY `cat_serv_en_serv_idx` (`id_cat_serv`),
  CONSTRAINT `cat_serv_en_serv` FOREIGN KEY (`id_cat_serv`) REFERENCES `cat_servicio` (`idcat_servicio`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `ciudad_en_serv` FOREIGN KEY (`id_ciudad`) REFERENCES `cat_ciudad` (`idCiudad`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `usuario_en_serv` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`userID`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Volcando datos para la tabla cuatro_avisos.aviso_servicio: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `aviso_servicio` DISABLE KEYS */;
INSERT INTO `aviso_servicio` (`idaviso_servicio`, `id_usuario`, `id_ciudad`, `id_cat_serv`, `titulo`, `descripcion`, `fecha_pub`, `visible`) VALUES
	(3, 37, 9, 1, 'golpeadores profecionales', 'golpeamos a quien usted quiera con silencia y mucha discreción', '2017-10-02 14:17:13', 'si'),
	(4, 37, 9, 9, 'fuegos artificalees', 'llamar al 42342342', '2017-10-01 18:08:12', 'si'),
	(5, 41, 8, 11, 'necesito obreros', 'llamar al 535636', '2017-10-06 11:28:31', 'si'),
	(6, 42, 7, 17, 'catamos villancicos', 'todo un repertorio completo llame ya', '2017-10-06 16:45:45', 'si');
/*!40000 ALTER TABLE `aviso_servicio` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.aviso_venta
CREATE TABLE IF NOT EXISTS `aviso_venta` (
  `idaviso_venta` bigint(255) NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(255) DEFAULT NULL,
  `id_ciudad` bigint(255) DEFAULT NULL,
  `id_cat_venta` bigint(255) DEFAULT NULL,
  `titulo` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `descripcion` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `foto` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `precio` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_pub` datetime DEFAULT NULL,
  `visible` varchar(2) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idaviso_venta`),
  KEY `usuario_en_venta_idx` (`id_usuario`),
  KEY `ciudad_en_venta_idx` (`id_ciudad`),
  KEY `catventa_ne_venta_idx` (`id_cat_venta`),
  CONSTRAINT `catventa_en_venta` FOREIGN KEY (`id_cat_venta`) REFERENCES `cat_venta` (`idcat_venta`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `ciudad_en_venta` FOREIGN KEY (`id_ciudad`) REFERENCES `cat_ciudad` (`idCiudad`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `usuario_en_venta` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`userID`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.aviso_venta: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `aviso_venta` DISABLE KEYS */;
INSERT INTO `aviso_venta` (`idaviso_venta`, `id_usuario`, `id_ciudad`, `id_cat_venta`, `titulo`, `descripcion`, `foto`, `precio`, `fecha_pub`, `visible`) VALUES
	(6, 37, 1, 19, 'Vendo mi Note 10 en buen estado', 'Nuevo en caja con sus accesorios, interesados contactarse conmigo al número: 53645435433', '56434741773.jpg', '$ 300', '2021-09-06 16:17:21', 'si'),
	(7, 37, 1, 17, 'Apple MacBook casi nuevo', 'Vendo Apple MacBook con detalle, puede ver la imágenes en el post. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. U', '98629277879.jpg', '$ 800', '2021-09-06 17:14:58', 'si'),
	(8, 37, 1, 9, 'Guitarra Taylor en buen estado', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut al', '98581804855.jpg', '$ 300', '2021-09-06 17:16:26', 'si'),
	(9, 37, 1, 9, 'Bicicleta Clásica', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut al', '23153241772.jpg', '$ 250', '2021-09-06 17:17:30', 'si'),
	(10, 37, 1, 15, 'Zapato clásico', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut', '4274300146.jpg', '$ 400', '2021-09-06 17:19:10', 'si');
/*!40000 ALTER TABLE `aviso_venta` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.cat_ciudad
CREATE TABLE IF NOT EXISTS `cat_ciudad` (
  `idCiudad` bigint(255) NOT NULL AUTO_INCREMENT,
  `ciudad` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idCiudad`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla cuatro_avisos.cat_ciudad: ~9 rows (aproximadamente)
/*!40000 ALTER TABLE `cat_ciudad` DISABLE KEYS */;
INSERT INTO `cat_ciudad` (`idCiudad`, `ciudad`) VALUES
	(1, 'Los Ángeles'),
	(2, 'San Francisco'),
	(3, 'Mountain View'),
	(4, 'Sacramento'),
	(5, 'San josé'),
	(6, 'Long Beach'),
	(7, 'Fresno'),
	(8, 'Pasadena'),
	(9, 'San Diego');
/*!40000 ALTER TABLE `cat_ciudad` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.cat_compra
CREATE TABLE IF NOT EXISTS `cat_compra` (
  `idcat_compra` bigint(255) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `posicion` int(3) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`idcat_compra`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.cat_compra: ~11 rows (aproximadamente)
/*!40000 ALTER TABLE `cat_compra` DISABLE KEYS */;
INSERT INTO `cat_compra` (`idcat_compra`, `nombre`, `posicion`, `visible`) VALUES
	(1, 'Arte y coleccionistas', 6, 1),
	(2, 'Vehiculos', 4, 1),
	(3, 'Departamentos', 2, 1),
	(4, 'Otros', 1, 1),
	(5, 'Inmuebles', 3, 1),
	(6, 'Motos', 5, 1),
	(7, 'Libros', 7, 1),
	(8, 'Animales - Mascotas', 8, 1),
	(9, 'Instrumentos musicales', 9, 1),
	(10, 'TecnologÃ­a y otros', 10, 1),
	(11, 'Herraminetas', 11, 1);
/*!40000 ALTER TABLE `cat_compra` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.cat_empleo
CREATE TABLE IF NOT EXISTS `cat_empleo` (
  `idcat_empleo` bigint(255) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `posicion` int(3) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`idcat_empleo`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.cat_empleo: ~42 rows (aproximadamente)
/*!40000 ALTER TABLE `cat_empleo` DISABLE KEYS */;
INSERT INTO `cat_empleo` (`idcat_empleo`, `nombre`, `posicion`, `visible`) VALUES
	(21, 'Plomero', 7, 1),
	(22, 'Electricista', 6, 1),
	(23, 'Choferes - Conductores', 5, 1),
	(25, 'Educación', 2, 1),
	(26, 'Oferta laboral multiple', 1, 1),
	(27, 'Chef', 3, 1),
	(28, 'Albañiles - Contratistas', 8, 1),
	(29, 'Pintores', 9, 1),
	(30, 'Mecánicos', 10, 1),
	(31, 'Topógrafos', 11, 1),
	(32, 'Arquitectos', 12, 1),
	(33, 'IngenierÃ­a', 13, 1),
	(34, 'Artistas - Música', 14, 1),
	(35, 'Diseño y multimedia', 15, 1),
	(36, 'Marketing', 18, 1),
	(37, 'Entretenimiento', 19, 1),
	(38, 'Medicina y salud', 20, 1),
	(39, 'Traductores', 21, 1),
	(40, 'Secretaria', 22, 1),
	(41, 'Guarderia', 17, 1),
	(42, 'Administración y oficina', 24, 1),
	(43, 'Agricultura y Campo', 23, 1),
	(44, 'Atención al cliente', 25, 1),
	(45, 'Banca y finanzas', 26, 1),
	(46, 'Científico e investigación', 27, 1),
	(47, 'Cocina y reposteria', 28, 1),
	(48, 'Contabilidad y economía', 29, 1),
	(49, 'Industria alimentaria', 30, 1),
	(50, 'Industria mineria', 31, 1),
	(51, 'Industria textil', 32, 1),
	(52, 'Informá¡tica', 33, 1),
	(53, 'Inmobiliario', 34, 1),
	(54, 'Internet', 35, 1),
	(55, 'Legal y asesorí­a', 36, 1),
	(56, 'Logí­stica y almacen', 37, 1),
	(57, 'Moda y belleza', 38, 1),
	(58, 'Recursos humanos', 39, 1),
	(59, 'Telecomunicaciones', 40, 1),
	(60, 'Turismo y hotelerí­a', 41, 1),
	(61, 'Técnico', 42, 1),
	(62, 'Pasantía', 16, 1),
	(63, 'Sector publico', 43, 1);
/*!40000 ALTER TABLE `cat_empleo` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.cat_servicio
CREATE TABLE IF NOT EXISTS `cat_servicio` (
  `idcat_servicio` bigint(255) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `posicion` int(3) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`idcat_servicio`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.cat_servicio: ~19 rows (aproximadamente)
/*!40000 ALTER TABLE `cat_servicio` DISABLE KEYS */;
INSERT INTO `cat_servicio` (`idcat_servicio`, `nombre`, `posicion`, `visible`) VALUES
	(1, 'Plomero', 10, 0),
	(2, 'Guardia', 11, 1),
	(3, 'Floristas', 12, 0),
	(4, 'Otros servicios', 1, 1),
	(5, 'Cursos', 2, 1),
	(6, 'Entretenimiento', 3, 1),
	(7, 'Evento y fiestas', 4, 1),
	(8, 'Prestamos', 5, 1),
	(9, 'Telecomunicaciones', 6, 1),
	(10, 'Conjuntos musicales', 7, 1),
	(11, 'ConstrucciÃ³n', 8, 1),
	(12, 'Marketing', 9, 1),
	(13, 'T&eacute;cnico', 13, 1),
	(14, 'Arquitectura', 14, 1),
	(15, 'Educaci&oacute;n y formaci&oacute;n', 15, 1),
	(16, 'Alba&ntilde;il', 16, 1),
	(17, 'Dise&ntilde;o y multimedia', 17, 1),
	(18, 'Moda y belleza', 18, 1),
	(19, 'Legal y asesor&iacute;a', 19, 1);
/*!40000 ALTER TABLE `cat_servicio` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.cat_venta
CREATE TABLE IF NOT EXISTS `cat_venta` (
  `idcat_venta` bigint(255) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `posicion` int(3) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`idcat_venta`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.cat_venta: ~19 rows (aproximadamente)
/*!40000 ALTER TABLE `cat_venta` DISABLE KEYS */;
INSERT INTO `cat_venta` (`idcat_venta`, `nombre`, `posicion`, `visible`) VALUES
	(4, 'Deparatamentos', 1, 1),
	(7, 'Animales - Mascotas', 6, 1),
	(8, 'Deporte', 7, 1),
	(9, 'Instrumentos musicales', 8, 1),
	(11, 'Maquinaria', 14, 1),
	(12, 'Herraminetas', 15, 1),
	(13, 'Inmuebles', 2, 1),
	(14, 'Motos', 4, 1),
	(15, 'Moda', 5, 1),
	(16, 'Arte y Coleccion', 9, 1),
	(17, 'Computadoras', 10, 1),
	(18, 'video juegos', 11, 1),
	(19, 'Celulares', 12, 1),
	(20, 'TecnologÃ­ay otros', 13, 1),
	(21, 'Enseres del hogar', 16, 1),
	(22, 'Viaje turismo', 17, 1),
	(23, 'Salud y belleza', 18, 1),
	(24, 'Vehiculos', 3, 1),
	(25, 'Otros', 19, 1);
/*!40000 ALTER TABLE `cat_venta` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.centraluser
CREATE TABLE IF NOT EXISTS `centraluser` (
  `userID` bigint(255) NOT NULL AUTO_INCREMENT,
  `userNombre` varchar(50) CHARACTER SET latin1 NOT NULL,
  `userEmailA` varchar(60) CHARACTER SET latin1 NOT NULL,
  `userTelefono` varchar(10) CHARACTER SET latin1 NOT NULL,
  `userContra` varchar(100) CHARACTER SET latin1 NOT NULL,
  `userEstado` enum('Y','N') CHARACTER SET latin1 NOT NULL DEFAULT 'N',
  `codeAct` varchar(50) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`userID`),
  UNIQUE KEY `userEmail` (`userEmailA`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.centraluser: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `centraluser` DISABLE KEYS */;
INSERT INTO `centraluser` (`userID`, `userNombre`, `userEmailA`, `userTelefono`, `userContra`, `userEstado`, `codeAct`) VALUES
	(7, 'admin', 'admin@admin.com', '', '$2y$10$w54r3wqBC5Pv4KL8SQTRsOdfIDkMn/SsjfP3pqH0unK50UYhgntUq', 'Y', '2e70a7610d3f507448572caa7e9fa37a');
/*!40000 ALTER TABLE `centraluser` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.codigos
CREATE TABLE IF NOT EXISTS `codigos` (
  `idcodigo` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_semana` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `codigo_mes` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idcodigo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.codigos: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `codigos` DISABLE KEYS */;
INSERT INTO `codigos` (`idcodigo`, `codigo_semana`, `codigo_mes`) VALUES
	(1, 'SEMANA123', 'MES123');
/*!40000 ALTER TABLE `codigos` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.codigo_pro
CREATE TABLE IF NOT EXISTS `codigo_pro` (
  `idcode` int(11) NOT NULL AUTO_INCREMENT,
  `duracion` varchar(50) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `codigo` varchar(50) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`idcode`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.codigo_pro: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `codigo_pro` DISABLE KEYS */;
INSERT INTO `codigo_pro` (`idcode`, `duracion`, `codigo`) VALUES
	(1, '1 semana', 'ABCD123'),
	(2, '2 semanas', 'QWEQW'),
	(3, '3 semanas', 'YTYEW3');
/*!40000 ALTER TABLE `codigo_pro` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.dias_pub
CREATE TABLE IF NOT EXISTS `dias_pub` (
  `iddias_pub` int(11) NOT NULL AUTO_INCREMENT,
  `dias` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `duracion` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`iddias_pub`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.dias_pub: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `dias_pub` DISABLE KEYS */;
INSERT INTO `dias_pub` (`iddias_pub`, `dias`, `duracion`) VALUES
	(1, '1 dia', '172800'),
	(2, '2 dias', '345600'),
	(3, '3 dias', '691200'),
	(4, '4 dias', NULL),
	(5, '5 dias', NULL),
	(6, '6 dias', NULL),
	(7, '7 dias', NULL);
/*!40000 ALTER TABLE `dias_pub` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.mensaje
CREATE TABLE IF NOT EXISTS `mensaje` (
  `idmensaje` int(11) NOT NULL AUTO_INCREMENT,
  `mensaje` varchar(200) COLLATE utf8_spanish_ci DEFAULT '0',
  PRIMARY KEY (`idmensaje`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.mensaje: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `mensaje` DISABLE KEYS */;
INSERT INTO `mensaje` (`idmensaje`, `mensaje`) VALUES
	(7, 'Hola queridos usuarios, recuerden renovar sus anuncios');
/*!40000 ALTER TABLE `mensaje` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.publicidad
CREATE TABLE IF NOT EXISTS `publicidad` (
  `idpub` int(11) NOT NULL AUTO_INCREMENT,
  `idusuario` bigint(255) DEFAULT NULL,
  `idciudad` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `descripcion` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `imagen` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `duracion` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `visible` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `posicion` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_pub` datetime DEFAULT NULL,
  PRIMARY KEY (`idpub`),
  KEY `u_idx` (`idusuario`),
  CONSTRAINT `usuario_en_publicidad` FOREIGN KEY (`idusuario`) REFERENCES `usuarios` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.publicidad: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `publicidad` DISABLE KEYS */;
INSERT INTO `publicidad` (`idpub`, `idusuario`, `idciudad`, `descripcion`, `imagen`, `duracion`, `visible`, `posicion`, `fecha_pub`) VALUES
	(5, 37, 'San Francisco', 'Liquidaci&oacute;n de camisas de verano', '82205353294.jpg', '1 semana', 'si', '2', '2021-09-05 00:59:08');
/*!40000 ALTER TABLE `publicidad` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.reportes_compra
CREATE TABLE IF NOT EXISTS `reportes_compra` (
  `idreporte_com` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(20) DEFAULT NULL,
  `id_aviso` bigint(20) DEFAULT NULL,
  `motivo` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_pub` datetime DEFAULT NULL,
  PRIMARY KEY (`idreporte_com`),
  KEY `usuario_reporte_compra` (`id_usuario`),
  KEY `aviso_reporte_compra` (`id_aviso`),
  CONSTRAINT `aviso_reporte_compra` FOREIGN KEY (`id_aviso`) REFERENCES `aviso_compra` (`idaviso_compra`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `usuario_reporte_compra` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.reportes_compra: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `reportes_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportes_compra` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.reportes_empleo
CREATE TABLE IF NOT EXISTS `reportes_empleo` (
  `idreporte_emp` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(20) DEFAULT NULL,
  `id_aviso` bigint(20) DEFAULT NULL,
  `motivo` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_pub` datetime DEFAULT NULL,
  PRIMARY KEY (`idreporte_emp`),
  KEY `usuario_idx` (`id_usuario`),
  KEY `aviso_emp_en_reporte_idx` (`id_aviso`),
  CONSTRAINT `aviso_reporte_empleo` FOREIGN KEY (`id_aviso`) REFERENCES `aviso_empleo` (`idaviso_empleo`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `usuario_reporte` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.reportes_empleo: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `reportes_empleo` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportes_empleo` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.reportes_servicio
CREATE TABLE IF NOT EXISTS `reportes_servicio` (
  `idreporte_serv` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(20) DEFAULT NULL,
  `id_aviso` bigint(20) DEFAULT NULL,
  `motivo` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_pub` datetime DEFAULT NULL,
  PRIMARY KEY (`idreporte_serv`),
  KEY `usuario_reporte_servicio` (`id_usuario`),
  KEY `aviso_reporte_servicio` (`id_aviso`),
  CONSTRAINT `aviso_reporte_servicio` FOREIGN KEY (`id_aviso`) REFERENCES `aviso_servicio` (`idaviso_servicio`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `usuario_reporte_servicio` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.reportes_servicio: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `reportes_servicio` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportes_servicio` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.reportes_venta
CREATE TABLE IF NOT EXISTS `reportes_venta` (
  `idreporte_vent` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(20) DEFAULT NULL,
  `id_aviso` bigint(20) DEFAULT NULL,
  `motivo` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_pub` datetime DEFAULT NULL,
  PRIMARY KEY (`idreporte_vent`),
  KEY `usuario_reporte_idx` (`id_usuario`),
  KEY `aviso_reporte_venta_idx` (`id_aviso`),
  CONSTRAINT `aviso_reporte_venta` FOREIGN KEY (`id_aviso`) REFERENCES `aviso_venta` (`idaviso_venta`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `usuario_reporte_venta` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.reportes_venta: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `reportes_venta` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportes_venta` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `userID` bigint(255) NOT NULL AUTO_INCREMENT,
  `userNombre` varchar(50) CHARACTER SET latin1 NOT NULL,
  `userApell` varchar(50) CHARACTER SET latin1 NOT NULL,
  `userTele` varchar(10) CHARACTER SET latin1 NOT NULL DEFAULT 'N',
  `userEmail` varchar(60) CHARACTER SET latin1 NOT NULL,
  `userContra` varchar(100) CHARACTER SET latin1 NOT NULL,
  `userEstado` enum('Y','N') CHARACTER SET latin1 NOT NULL DEFAULT 'N',
  `userAcceso` enum('Y','N') CHARACTER SET latin1 NOT NULL DEFAULT 'Y',
  `codeAct` varchar(100) CHARACTER SET latin1 NOT NULL,
  `fechaIn` date DEFAULT NULL,
  PRIMARY KEY (`userID`),
  UNIQUE KEY `userEmail` (`userEmail`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.usuarios: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`userID`, `userNombre`, `userApell`, `userTele`, `userEmail`, `userContra`, `userEstado`, `userAcceso`, `codeAct`, `fechaIn`) VALUES
	(37, 'pepe', 'pepinosse', '45648798', 'pepe@pepe.com', '$2y$10$dX5Eo6TXCV/to0cBk1o1xurNictBJUhdF6hoJC8PHD.vxUvhOSIk6', 'Y', 'Y', '5b470493cbbfac09f1e9a8e245fe141d', '2017-05-23'),
	(40, 'alfa', 'status', '46546645', 'alfa@gmail.com', '$2y$10$VMZCUT0bGyiOVIplLpOby.MCnRonNwRIzP/BW2e4JvzW2H2WDvzae', 'Y', 'N', '53c7565a5108ce9870f5b5012e9f8f31', '2017-10-06'),
	(41, 'beta', 'status bet', '789798', 'beta@gmail.com', '$2y$10$X5Hx5vJmaAMJwiQEcEYIr.vyDr07Z8c8VoFJUf5uf5dC8qFtELWUe', 'Y', 'Y', '6d690ce8c6594d4fda543e97aa9e93de', '2017-10-06'),
	(42, 'peta', 'status pet', '5345356475', 'peta@hotmail.com', '$2y$10$jurQ.G4..LubA5atKlnwD.lRdasuNqGIuvmDVjV8RrY6mpwM8P/q2', 'Y', 'Y', 'e12cc7a7f3d55786a641c286ff98e20c', '2017-10-06'),
	(43, 'user', 'pex', '8988686', 'user@user.com', '$2y$10$w54r3wqBC5Pv4KL8SQTRsOdfIDkMn/SsjfP3pqH0unK50UYhgntUq', 'Y', 'Y', '7b15105ecfc784e080bddfe8a9298f80', '2021-05-30');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;

-- Volcando estructura para tabla cuatro_avisos.video_url
CREATE TABLE IF NOT EXISTS `video_url` (
  `idvideo_url` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `visible` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `posicion` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_pub` datetime NOT NULL,
  PRIMARY KEY (`idvideo_url`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla cuatro_avisos.video_url: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `video_url` DISABLE KEYS */;
INSERT INTO `video_url` (`idvideo_url`, `url`, `descripcion`, `visible`, `posicion`, `fecha_pub`) VALUES
	(1, 'https://www.youtube.com/watch?v=UjCzD7FAmIs', 'pewdiepie', 'si', '1', '0000-00-00 00:00:00'),
	(3, 'https://www.youtube.com/watch?v=FuXNumBwDOM', 'Taylor Swift', 'si', '4', '0000-00-00 00:00:00'),
	(4, 'https://www.youtube.com/watch?v=FG9M0aEpJGE', 'Good Life', 'si', '1', '0000-00-00 00:00:00'),
	(5, 'https://www.youtube.com/watch?v=N3XlyT4Ums8', 'Alicia Keys', 'si', '2', '0000-00-00 00:00:00'),
	(8, 'https://www.youtube.com/watch?v=fn3KWM1kuAw', 'Boston', 'si', '1', '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `video_url` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
