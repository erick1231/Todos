<?php 
session_start();
require_once 'include/class.user.php';
$user_home = new USER();

if($user_home->is_logged_in()){

$stmt = $user_home->runQuery("SELECT * FROM usuarios WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSession']));    
$row = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<?php include "inc/header.php" ; ?>
<section class="main container">
	<div class="row">
		<!-- hora en California -->
		<section class="col-md-3">
			<div class="row">
				<div class="panel panel-default">
					<div class="panel-body">
						<div style="text-align:center;width:250px;padding:1em 0;"> <!-- 400 -->
							<h2>
							<a style="text-decoration:none;" href="http://www.zeitverschiebung.net/es/country/bo">
							<!-- <span style="color:gray;">Hora actual en</span> -->
							<!-- <br />
							California -->
							</a>
							</h2>
							<iframe src="https://www.zeitverschiebung.net/clock-widget-iframe-v2?language=es&timezone=America%2FLa_Paz" width="100%" height="150" frameborder="0" seamless><!-- 150 -->
							</iframe> 
							<small style="color:gray;">&copy; <a href="http://www.zeitverschiebung.net/es/" style="color: gray;">Diferencia horaria</a></small> 
						</div>
					</div>
				</div>
<!-- 				<div>
				<a href="#" class="btn btn-default btn-block "><span class="icon-camera icon-2x"></span> Escanear código QR</a>
				<a href="#" class="btn btn-default btn-block "><span class="icon-youtube icon-2x"></span> Descarga tus videos</a>
				</div> -->
			</div>
		</section>

	</div>	
</section>

	
	</div>
</section>
<?php include 'inc/footer.php'; ?>
