<?php
session_start();
require_once 'include/class.user.php';
$user_ads = new USER();
if(!$user_ads->is_logged_in())
{
  $user_ads->redirect('login.php');
}
//extract($_SESSION);
$stmt = $user_ads->runQuery("SELECT * FROM usuarios WHERE userID=:id LIMIT 1");
$stmt->execute(array(":id"=>$_SESSION['userSession']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<?php
$errores = ''; 
//actualizar aviso empleo 
if (isset($_POST['actualizar_aviso_empleo']))
{
	$idemp = $_POST['idempleo'];
	$ciudad = $_POST['ciudad'];
	$empleo = $_POST['empleo'];
	$titulo = $user_ads->limpiarDatos($_POST['titulo']);
	$descripcion = $user_ads->limpiarDatos($_POST['descripcion']);
	$fecha_pub = date('Y-m-d H:i:s');
	$fecha_vigen= $_POST['fechavigencia'];

	if (empty($titulo && $descripcion && $fecha_vigen)) {
			header("location:mis-avisos.php?datos");
	}
	else{

	if($user_ads->act_av_emp($idemp,$ciudad,$empleo,$titulo,$descripcion,$fecha_pub,$fecha_vigen))
		{
			header("location:mis-avisos.php?actualizacion-correcta");
		}
		else
		{
			header("location:mis-avisos.php?error");
		}
	}
}
?>
<?php 
//eliminar aviso empleo 
if(isset($_POST['eliminar_aviso_empleo']))
{
	$idemp = $_POST['idempleo'];
	if($user_ads->del_av_emp($idemp))
		{
			header("location:mis-avisos.php?eliminar-aviso");
		}
		else
		{
			header("location:mis-avisos.php?error");
		}
}
?>
<?php 
//actualizar aviso venta
if (isset($_POST['actualizar_aviso_venta']))
{
	$idvent = $_POST['idventa'];
	$ciudad = $_POST['ciudad'];
	$venta =  $_POST['venta'];
	$titulo = $user_ads->limpiarDatos($_POST['titulo']);
	$descripcion = $user_ads->limpiarDatos($_POST['descripcion']);

	$imgFoto = $_FILES['foto_imagen']['name'];
	$tmp_dir = $_FILES['foto_imagen']['tmp_name'];
	$imgSize = $_FILES['foto_imagen']['size'];
	$fecha_pub = date('Y-m-d H:i:s');

	$stmt_edit = $user_ads->runQuery('SELECT foto FROM aviso_venta WHERE idaviso_venta =:idventa');
	$stmt_edit->execute(array(':idventa'=>$idvent));
	$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	//edit_row es la ubicacion exacta de la imagen
	/*	extract($edit_row);*/
	if (empty($titulo && $descripcion)) {
			header("location:mis-avisos.php?datos");
	}
	else{

	if($imgFoto)
	{
		$upload_dir = 'media/fotos_images4/'; //ubicacion de fotos
		$imgExt = strtolower(pathinfo($imgFoto,PATHINFO_EXTENSION));
		$imgFoto = rand(1000,100000000000).".".$imgExt; //renombra la foto 12 numeros
		unlink($upload_dir.$edit_row['foto']);
		move_uploaded_file($tmp_dir,$upload_dir.$imgFoto); 
	}
	else
	{
		$imgFoto = $edit_row['foto'];
	}
	if($user_ads->act_av_vent($idvent,$ciudad,$venta,$titulo,$descripcion,$imgFoto,$fecha_pub,$fecha_vigen))
		{
			header("location:mis-avisos.php?actualizacion-correcta");
		}
		else
		{
			header("location:mis-avisos.php?error");
		}
	}	
}
?>

?>
<?php 
//eliminar aviso venta
if(isset($_POST['eliminar_aviso_venta']))
{
	$idvent = $_POST['idventa'];

	$stmt_edit = $user_ads->runQuery('SELECT foto FROM aviso_venta WHERE idaviso_venta =:idventa');
	$stmt_edit->execute(array(':idventa'=>$idvent));
	$delete_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	unlink("media/fotos_images4/".$delete_row['foto']);
	if($user_ads->del_av_vent($idvent))
		{
			header("location:mis-avisos.php?eliminar-aviso");
		}
		else
		{
			header("location:mis-avisos.php?error");
		}
}
?>

<?php 
//actualizar aviso servicio 
if (isset($_POST['actualizar_aviso_servicio']))
{
	$idserv = $_POST['idservi'];
	$ciudad = $_POST['ciudad'];
	$servicio = $_POST['servicio'];
	$titulo = $user_ads->limpiarDatos($_POST['titulo']);
	$descripcion = $user_ads->limpiarDatos($_POST['descripcion']);
	$fecha_pub = date('Y-m-d H:i:s');

	if (empty($titulo && $descripcion)) {
			header("location:mis-avisos.php?datos");
	}
	else{
	
	if($user_ads->act_av_serv($idserv,$ciudad,$servicio,$titulo,$descripcion,$fecha_pub))
		{
			header("location:mis-avisos.php?actualizacion-correcta");
		}
		else
		{
			header("location:mis-avisos.php?error");
		}
	}
}
?>
<?php 
//eliminar aviso servicio
if(isset($_POST['eliminar_aviso_servicio']))
{
	$idserv = $_POST['idservi'];
	if($user_ads->del_av_serv($idserv))
		{
			header("location:mis-avisos.php?eliminar-aviso");
		}
		else
		{
			header("location:mis-avisos.php?error");
		}
}
?>
<?php 
//actualizar aviso compra 
if (isset($_POST['actualizar_aviso_compra']))
{
	$idcomp = $_POST['idcomp'];
	$ciudad = $_POST['ciudad'];
	$compra = $_POST['compra'];
	$titulo = $user_ads->limpiarDatos($_POST['titulo']);
	$descripcion = $user_ads->limpiarDatos($_POST['descripcion']);
	$fecha_pub = date('Y-m-d H:i:s');

	if (empty($titulo && $descripcion)) {
			header("location:mis-avisos.php?datos");
	}
	else{
	
	if($user_ads->act_av_compra($idcomp,$ciudad,$compra,$titulo,$descripcion,$fecha_pub))
		{
			header("location:mis-avisos.php?actualizacion-correcta");
		}
		else
		{
			header("location:mis-avisos.php?error");
		}
	}
}
?>
<?php 
//eliminar aviso compra
if(isset($_POST['eliminar_aviso_compra']))
{
	$idcomp = $_POST['idcomp'];
	if($user_ads->del_av_compra($idcomp))
		{
			header("location:mis-avisos.php?eliminar-aviso");
		}
		else
		{
			header("location:mis-avisos.php?error");
		}
}
?>