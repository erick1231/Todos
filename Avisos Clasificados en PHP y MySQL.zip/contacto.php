<?php 
session_start();
require_once 'include/class.user.php';
require_once 'mailer/class.phpmailer.php';
$user_home = new USER();
if($user_home->is_logged_in()){
$stmt = $user_home->runQuery("SELECT * FROM usuarios WHERE userID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSession']));    
$row = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<?php  
if (isset($_POST['btn_enviar_mensaje'])) {

    $nombre = $_POST['nombre'];
    $email = $_POST['correo'];
    $message = $_POST['mensaje'];

        $mail = new PHPMailer();
        $mail->IsSMTP();          
        $mail->SMTPDebug  = 0;           
        $mail->SMTPAuth   = true;                  
        $mail->SMTPSecure = "SSL";                 
        $mail->Host       = "mail.4avisos.com";      
        $mail->Port       = 26;             
        
        $mail->Username = "clasificados@4avisos.com";  
        $mail->Password = "UnicosFileMaster@@";            
        $mail->SetFrom("clasificados@4avisos.com","4avisos");
        $mail->AddReplyTo("clasificados@4avisos.com","4avisos");
        $mail->AddAddress('clasificados@4avisos.com', 'Company Administration');
        $mail->CharSet = "UTF-8";
        //$mail->Subject = 'Contact us email from ' . $nombre . ' concerning ';
        $mail->Body = $nombre . " has contacted us from the website leaving the following information: \n nombre: " . $nombre . "\correo: " . $email . "\n\n" . $message;


    /*require_once('mailer/class.phpmailer.php');
    $mail = new PHPMailer();
    $mail->IsSMTP();          
    $mail->SMTPDebug  = 0;           
    $mail->SMTPAuth   = true;                  
    $mail->SMTPSecure = "SSL";                 
    $mail->Host       = "mail.4avisos.com";      
    $mail->Port       = 26;             
    
    $mail->Username = "clasificados@4avisos.com";  
    $mail->Password = "UnicosFileMaster@@";            
    $mail->SetFrom("clasificados@4avisos.com","4avisos");
    $mail->AddReplyTo("clasificados@4avisos.com","4avisos");
    $mail->CharSet = "UTF-8";

   // $mail->From = "4avisos@4avisos.com";
    $mail->SetFrom("clasificados@4avisos.com","4avisos");
    $mail->To = "avisos@avance2.hostwara.com";  
    $mail->AddAddress($_POST['correo']);
    $mail->Subject = 'Enviado desde la web 4avisos';
    $mail->Body = "nombre: $nombre\n correo: $email\n message:\n $message";*/


    if (empty($nombre && $email && $message)) {
        $errorMSG = "Olvidaste un dato";
    }
    else{
            if ($mail->send() == true) {
                $msg = "<div class='alert alert-success'>
                            <button class='close' data-dismiss='alert'>&times;</button>
                            <span class='fa fa-envelope fa-2x'></span><strong> Tu mensaje se envió correctamente.</strong>
                        </div>";
                        //header('refresh:2;index.php');
            }
            else{
                $msg = "<div class='alert alert-danger'>
                            <button class='close' data-dismiss='alert'>&times;</button>
                            <span class='fa fa-frown-o fa-2x'></span><strong> Inténtalo más tarde.</strong>
                        </div>";
                        //header('refresh:2;index.php');
            }
        }
}
?>
<?php include 'inc/header.php'; ?>
 <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4 ">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-envelope"></i> Contacto</h3>
                    </div>
                <div class="panel-body">
                        <?php if(isset($msg)){
                            echo $msg;          
                        } 
                        ?>
				    <form role="form" id="contacto" method="post" class="form-horizontal mitad" autocomplete="off">
                          <div class="form-group">
                                <label class="col-sm-4 control-label">Nombre</label>
                                <div class="col-sm-8">
                                        <input type="text" value="" name='nombre' class="form-control" maxlength="50">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label">Correo</label>
                                <div class="col-sm-8">
                                    <input type="email" value="" name='correo' class="form-control" maxlength="60">
                                </div>
                            </div>
                            <div class="form-group">
					      		<label for="textArea" class="col-md-4 control-label">Mensaje</label>
				      			<div class="col-md-8">
					        		<textarea id="inputmax2" class="form-control" rows="3" name="mensaje" ></textarea>
					        		<script type="text/javascript">
									document.formu.inputmax2.maxLength = 500;
									</script>
				      			</div>
					    	</div>
              				<div class="form-group">
              		            <div class="col-sm-12">
                                <button  type="submit" class="btn btn-primary btn-block" name="btn_enviar_mensaje" value="registrar"><i class="fa fa-envelope"></i> Enviar</button>
                                </div>
                            </div>
                     </form>
                </div>
            </div>
		</div>
  </div>
</div>
<?php include 'inc/footer.php'; ?>	   